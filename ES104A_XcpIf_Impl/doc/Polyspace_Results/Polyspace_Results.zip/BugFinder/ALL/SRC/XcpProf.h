/* This file contains only the definitions XcpIf requires to run QAC and Polyspace. */

/***** From xcp_par.h ***************************************************************/
#define XcpEventChannel_2ms_DAQ_2            0u

/***** From v_def.h *****************************************************************/
typedef unsigned char  vuint8;
typedef unsigned short vuint16;
typedef unsigned long  vuint32;

/***** From XcpProf.h ***************************************************************/
#define XCP_CMD_OK                  1
#define XCP_MEMORY_FAR /* left blank */
#define MTABYTEPTR vuint8 XCP_MEMORY_FAR *
#define BYTEPTR vuint8 *

/* Value should be modified to test all sizes - See MDD for more details */
#define kXcpDaqTimestampSize                 DAQ_TIMESTAMP_WORD 

#if ( kXcpDaqTimestampSize == DAQ_TIMESTAMP_BYTE )
  typedef vuint8 XcpDaqTimestampType;
  #define XcpDaqTimestampSize 1
#elif ( kXcpDaqTimestampSize == DAQ_TIMESTAMP_WORD )
  typedef vuint16 XcpDaqTimestampType;
  #define XcpDaqTimestampSize 2
#elif ( kXcpDaqTimestampSize == DAQ_TIMESTAMP_DWORD )
  typedef vuint32 XcpDaqTimestampType;
  #define XcpDaqTimestampSize 4
#else
  #error "kXcpDaqTimestampSize not defined. Please define a valid timestamp type!"
#endif


extern vuint8 XcpEvent( vuint8 event );
extern FUNC(vuint8, CDD_XcpIf_CODE) ApplXcpCalibrationWrite(MTABYTEPTR addr, vuint8 size, const BYTEPTR data);
extern vuint8 ApplXcpCalibrationRead(uint8 addr[], vuint8 size, uint8 data[]);
extern XcpDaqTimestampType ApplXcpGetTimestamp( void );
extern MTABYTEPTR ApplXcpGetPointer( vuint8 addr_ext, vuint32 addr );
