/* This file contains only the definitions XcpIf requires to run QAC and Polyspace. */

void Call_ApplXcpWrCmn(MTABYTEPTR os_arg_addr, vuint8 os_arg_size, const BYTEPTR os_arg_data);
