/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *          File:  CDD_XcpIf.c
 *     SW-C Type:  CDD_XcpIf
 *  Generated at:  Wed Jun 17 14:01:56 2015
 *
 *     Generator:  MICROSAR RTE Generator Version 4.3.0
 *                 RTE Core Version 1.3.0
 *       License:  Unlimited license CBD1400351 (THE ECU PRODUCT "STEERING SYSTEMS", THE ECU SUPPLIER "NEXTEER", THE VEHICLE MANUFACTURER "GENERAL MOTORS CORPORATION") for Nexteer Automotive Corporation
 *
 *   Description:  C-Code implementation template for SW-C <CDD_XcpIf>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
/**********************************************************************************************************************
* Copyright 2015 Nexteer 
* Nexteer Confidential
*
* Module File Name:   CDD_XcpIf.c
* Module Description: Source file for XCP Interface ES 104A
* Project           : CBD 
* Author            : Kevin Smith
***********************************************************************************************************************
* Version Control:
* %version:          1 %
* %derived_by:       cz7lt6 %
*----------------------------------------------------------------------------------------------------------------------
* Date      Rev      Author         Change Description                                                           SCR #
* -------   -------  --------  ---------------------------------------------------------------------------     --------
* 06/16/15  1        KJS       Initial Version                                                                 EA4#851
**********************************************************************************************************************/

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

#include "Rte_CDD_XcpIf.h"


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
#include "CDD_XcpIf.h"
#include "CDD_NxtrTi.h"
#include "Os.h"

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


#define CDD_XcpIf_START_SEC_CODE
#include "CDD_XcpIf_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Xcp2msDaq
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 2ms
 *
 *********************************************************************************************************************/

FUNC(void, CDD_XcpIf_CODE) Xcp2msDaq(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Xcp2msDaq
 *********************************************************************************************************************/
    (void)XcpEvent( XcpEventChannel_2ms_DAQ_2 );
    return;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CDD_XcpIf_STOP_SEC_CODE
#include "CDD_XcpIf_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
 
/**********************************************************************************************************************
* Name:         ApplXcpGetTimestamp
*
* Description:  Returns the current timestamp.
*
* Inputs:       N/A
*
* Outputs:      XcpDaqTimestampType - Timestamp value based on XcpDaqTimestampType format
*
* Usage Notes:  XCP Callout
**********************************************************************************************************************/
FUNC(XcpDaqTimestampType, CDD_XcpIf_CODE) ApplXcpGetTimestamp(void)
{
    VAR(uint32, AUTOMATIC) Timestamp_Cnt_T_u32;
    
    GetRefTmr1MicroSec32bit_Oper( &Timestamp_Cnt_T_u32 );

    return( (XcpDaqTimestampType)Timestamp_Cnt_T_u32 );
}

/**********************************************************************************************************************
* Name:         ApplXcpGetPointer
*
* Description:  This function converts a memory address from XCP format (32-bit address plus 8-bit address
*               extension) to a C style pointer. An MCS like CANape usually reads this memory addresses from
*               the ASAP2 database or from a linker map file.
*               The address extension may be used to distinguish different address spaces or memory types. In
*               most cases, the address extension is not used and may be ignored.
*               This function is used for memory transfers like DOWNLOAD and UPLOAD.
*
* Inputs:       addr_ext - 8-bit address extension
*               addr - 32-bit address
*
* Outputs:      RtnAddr - Return pointer to the address specified by the parameters
*
* Usage Notes:  XCP Callout
**********************************************************************************************************************/
FUNC(MTABYTEPTR, CDD_XcpIf_CODE) ApplXcpGetPointer( vuint8 addr_ext, vuint32 addr )
{
    VAR(uint32, AUTOMATIC) RtnAddr_Cnt_T_u32;
    RtnAddr_Cnt_T_u32 = addr;

    return ((MTABYTEPTR)RtnAddr_Cnt_T_u32);
}

/**********************************************************************************************************************
* Name:         ApplXcpCalibrationWrite
*
* Description:  This function transfers data sent by the XCP user to the address set by the MTA.
*
* Inputs:       addr - Starting address of the destination of the data being sent via the XCP user.
*               size - Number of bytes to write.
*               data - Starting address of the data buffer of the data sent via XCP.
*
* Outputs:      XCP_CMD_OK - Hard coded to always return positive results.
*
* Usage Notes:  XCP Callout
**********************************************************************************************************************/
FUNC(vuint8, CDD_XcpIf_CODE) ApplXcpCalibrationWrite(MTABYTEPTR addr, vuint8 size, const BYTEPTR data)
{
    /* Call the common application write function as a trusted function. This is a temp solution until
    targeted for a bench level test build. */
    Call_ApplXcpWrCmn(addr, size, data);

    /* TODO: Determine if any error checking needs to be done */
    return ((vuint8)XCP_CMD_OK);
}

/**********************************************************************************************************************
* Name:         ApplXcpWrCmn
*
* Description:  Common function to move the data from the source to the destination for XCP Write Commands
*
* Inputs:       addr - Destination starting address.
*               size - Number of bytes to write.
*               data - Source starting address.
*
* Outputs:      N/A
*
* Usage Notes:  XCP Callout, currently declared as a trusted function. 
**********************************************************************************************************************/
FUNC(void, CDD_XcpIf_CODE) ApplXcpWrCmn(uint8 addr[], vuint8 size, const uint8 data[])
{
    VAR(uint8, AUTOMATIC) Idx_Cnt_T_u8;

    for (Idx_Cnt_T_u8 = 0U; Idx_Cnt_T_u8 < size; Idx_Cnt_T_u8++)
    {
        addr[Idx_Cnt_T_u8] = data[Idx_Cnt_T_u8];
    }

    return;
}


/**********************************************************************************************************************
* Name:         ApplXcpCalibrationRead
*
* Description:  This function transfers data requested by the XCP user from the address set by the MTA.
*
* Inputs:       addr - Starting address of the data to be read.
*               size - Number of bytes to read.
*               data - Destination address of the data
*
* Outputs:      XCP_CMD_OK - Hard coded to always return positive results.
*
* Usage Notes:  XCP Callout
**********************************************************************************************************************/
FUNC(vuint8, CDD_XcpIf_CODE) ApplXcpCalibrationRead(uint8 addr[], vuint8 size, uint8 data[])
{
    VAR(uint8, AUTOMATIC) Idx_Cnt_T_u8;
    
    for (Idx_Cnt_T_u8 = 0U; Idx_Cnt_T_u8 < size; Idx_Cnt_T_u8++)
    {
        data[Idx_Cnt_T_u8] = addr[Idx_Cnt_T_u8];
    }

    return((vuint8)XCP_CMD_OK);
}


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
