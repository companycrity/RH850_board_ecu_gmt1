
#ifndef FLTINJ_H
#define FLTINJ_H

#define FLTINJ_HYSCMP_HYSCMPCMD         (12U)

#endif
