/* Header file for contract folder of CM620A */

#ifndef CDD_MOTAG0MEAS_CFG_H    /* Multiple include preventer */
#define CDD_MOTAG0MEAS_CFG_H

#include "Rte_CDD_MotAg0Meas.h"

#define MOTAG0MEAS_MOTAG0PRTCLFLTNTCNR_CNT_ENUM                 NTCNR_0X083 


#endif
