
#ifndef FLTINJ_H
#define FLTINJ_H

#define FLTINJENA  STD_ON /* FLTINJENA is defined as STD_ON in contract folder to let the compiler check the function call */
/* Fault Injection Assist Command */

#define FLTINJ_HWAG0MEAS_HWAG0  33U
#define FLTINJ_HWAG0MEAS_TESTOK 34U

#endif
