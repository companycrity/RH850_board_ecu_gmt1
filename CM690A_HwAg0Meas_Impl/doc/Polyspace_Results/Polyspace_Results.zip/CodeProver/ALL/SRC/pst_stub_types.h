typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__VOID __PST__g__15(void);
typedef __PST__FLOAT32 *__PST__g__17;
typedef __PST__VOID __PST__g__16(__PST__g__17);
typedef __PST__UINT8 *__PST__g__19;
typedef __PST__VOID __PST__g__18(__PST__g__19);
typedef __PST__VOID __PST__g__20(__PST__FLOAT32);
typedef long double __PST__FLOAT96;
typedef __PST__FLOAT96 __PST__g__21(void);
typedef __PST__g__11 *__PST__g__24;
typedef volatile __PST__FLOAT96 __PST__g__25;
typedef __PST__SINT8 *__PST__g__27;
typedef volatile __PST__g__27 __PST__g__26;
typedef const struct Rte_CDS_HwAg0Meas __PST__g__30;
typedef __PST__g__30 *__PST__g__29;
typedef const __PST__g__29 __PST__g__28;
typedef struct __PST__g__33 *__PST__g__32;
typedef __PST__UINT32 *__PST__g__35;
typedef __PST__UINT16 *__PST__g__36;
struct Rte_CDS_HwAg0Meas
  {
    __PST__g__19 Pim_HwAg0InitStepSeqNrCmpl;
    __PST__g__32 Pim_HwAg0Offs;
    __PST__g__17 Pim_HwAg0PrevHwAg0;
    __PST__g__19 Pim_HwAg0PrevRollCnt;
    __PST__g__19 Pim_HwAg0PrevStepSeqNr;
    __PST__g__35 Pim_HwAg0RawDataAvlStrtTi;
    __PST__g__19 Pim_HwAg0Snsr0ComStsErrCntr;
    __PST__g__19 Pim_HwAg0Snsr0IdErrCntr;
    __PST__g__19 Pim_HwAg0Snsr0IntSnsrErrCntr;
    __PST__g__19 Pim_HwAg0Snsr0NoMsgErrCntr;
    __PST__g__19 Pim_HwAg0Snsr1ComStsErrCntr;
    __PST__g__19 Pim_HwAg0Snsr1IdErrCntr;
    __PST__g__19 Pim_HwAg0Snsr1IntSnsrErrCntr;
    __PST__g__19 Pim_HwAg0Snsr1NoMsgErrCntr;
    __PST__g__19 Pim_HwAg0SnsrTrigNr;
    __PST__g__17 Pim_PrevHwAg0;
    __PST__g__19 Pim_PrevHwAg0Qlfr;
    __PST__g__36 Pim_PrevHwAg0Snsr0Raw;
    __PST__g__19 Pim_PrevHwAg0Snsr0TestOk;
    __PST__g__36 Pim_PrevHwAg0Snsr1Raw;
    __PST__g__19 Pim_PrevHwAg0Snsr1TestOk;
    __PST__g__17 Pim_dHwAg0MeasSnsr0Abs;
    __PST__g__35 Pim_dHwAg0MeasSnsr0CS;
    __PST__g__35 Pim_dHwAg0MeasSnsr0FRXD;
    __PST__g__17 Pim_dHwAg0MeasSnsr0Rel;
    __PST__g__17 Pim_dHwAg0MeasSnsr1Abs;
    __PST__g__35 Pim_dHwAg0MeasSnsr1CS;
    __PST__g__35 Pim_dHwAg0MeasSnsr1FRXD;
    __PST__g__17 Pim_dHwAg0MeasSnsr1Rel;
  };
typedef __PST__SINT8 __PST__g__34[3];
struct __PST__g__33
  {
    __PST__FLOAT32 OffsTrim;
    __PST__UINT8 OffsTrimPrfmdSts;
    __PST__g__34 __pst_unused_field___pstfiller;
  };
typedef __PST__SINT32 __PST__g__229[1];
union __PST__g__39
  {
    __PST__g__229 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef __PST__SINT8 __PST__g__227[4];
typedef __PST__SINT8 __PST__g__228[8];
union __PST__g__47
  {
    __PST__g__229 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__52
  {
    __PST__g__229 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__56
  {
    __PST__g__229 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
struct __PST__g__60
  {
    __PST__UINT32 OMC : 3;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
union __PST__g__59
  {
    struct __PST__g__60 BIT;
    __PST__UINT32 __pst_unused_field_1;
  };
union __PST__g__62
  {
    __PST__g__229 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
struct __PST__g__68
  {
    const __PST__UINT32 OMS : 3;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__68 __PST__g__67;
union __PST__g__66
  {
    __PST__g__67 BIT;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__66 __PST__g__65;
struct __PST__g__73
  {
    const __PST__UINT32 FRS : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    const __PST__UINT32 __pst_unused_field_2 : 1;
    const __PST__UINT32 __pst_unused_field_3 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    const __PST__UINT32 __pst_unused_field_6 : 1;
    const __PST__UINT32 NRS : 1;
    const __PST__UINT32 __pst_unused_field_8 : 1;
    const __PST__UINT32 __pst_unused_field_9 : 1;
    const __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 21;
  };
typedef const struct __PST__g__73 __PST__g__72;
union __PST__g__71
  {
    __PST__g__72 BIT;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__71 __PST__g__70;
struct __PST__g__76
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 NRC : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
union __PST__g__75
  {
    struct __PST__g__76 BIT;
    __PST__UINT32 UINT32;
  };
struct __PST__g__109
  {
    const __PST__UINT32 __pst_unused_field_0 : 24;
    const __PST__UINT32 __pst_unused_field_1 : 4;
    const __PST__UINT32 __pst_unused_field_2 : 2;
    const __PST__UINT32 FND : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
  };
typedef const struct __PST__g__109 __PST__g__108;
union __PST__g__107
  {
    __PST__g__108 BIT;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__107 __PST__g__106;
struct __PST__g__38
  {
    union __PST__g__39 TSPC;
    __PST__g__227 __pst_unused_field_1;
    __PST__g__228 __pst_unused_field_2;
    union __PST__g__47 _CC;
    union __PST__g__52 BRP;
    union __PST__g__56 IDE;
    union __PST__g__59 MDC;
    union __PST__g__62 SPCT;
    __PST__g__65 MST;
    __PST__g__70 CS;
    union __PST__g__75 CSC;
    __PST__g__227 __pst_unused_field_11;
    __PST__g__227 __pst_unused_field_12;
    __PST__g__227 __pst_unused_field_13;
    __PST__g__227 __pst_unused_field_14;
    __PST__g__227 __pst_unused_field_15;
    __PST__g__106 FRXD;
  };
typedef volatile struct __PST__g__38 __PST__g__37;
struct __PST__g__40
  {
    __PST__UINT32 __pst_unused_field_0 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 15;
  };
union __PST__g__44
  {
    __PST__g__229 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__45
  {
    __PST__UINT32 __pst_unused_field_0 : 32;
  };
typedef __PST__UINT8 __PST__g__46[8];
struct __PST__g__48
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 3;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 19;
  };
struct __PST__g__53
  {
    __PST__UINT32 __pst_unused_field_0 : 5;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 3;
    __PST__UINT32 __pst_unused_field_2 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_4 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_6 : 4;
    __PST__UINT32 __pst_unused_field_pstnonamef4 : 4;
  };
struct __PST__g__57
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 21;
  };
struct __PST__g__63
  {
    __PST__UINT32 __pst_unused_field_0 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 25;
  };
union __PST__g__78
  {
    __PST__g__229 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__78 __PST__g__77;
struct __PST__g__80
  {
    const __PST__UINT32 __pst_unused_field_0 : 32;
  };
typedef const struct __PST__g__80 __PST__g__79;
typedef const __PST__UINT32 __PST__g__81;
union __PST__g__83
  {
    __PST__g__229 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__83 __PST__g__82;
struct __PST__g__85
  {
    const __PST__UINT32 __pst_unused_field_0 : 20;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 3;
    const __PST__UINT32 __pst_unused_field_3 : 6;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
  };
typedef const struct __PST__g__85 __PST__g__84;
union __PST__g__91
  {
    __PST__g__229 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__91 __PST__g__90;
struct __PST__g__93
  {
    const __PST__UINT32 __pst_unused_field_0 : 17;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 15;
  };
typedef const struct __PST__g__93 __PST__g__92;
union __PST__g__97
  {
    __PST__g__229 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__97 __PST__g__96;
struct __PST__g__99
  {
    const __PST__UINT32 __pst_unused_field_0 : 21;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 11;
  };
typedef const struct __PST__g__99 __PST__g__98;
union __PST__g__103
  {
    __PST__g__229 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__103 __PST__g__102;
struct __PST__g__105
  {
    const __PST__UINT32 __pst_unused_field_0 : 32;
  };
typedef const struct __PST__g__105 __PST__g__104;
typedef __PST__VOID __PST__g__114(__PST__SINT32);
typedef __PST__UINT8 __PST__g__115(__PST__g__27);
typedef __PST__UINT8 __PST__g__116(__PST__FLOAT32);
typedef __PST__UINT8 __PST__g__117(__PST__UINT8);
typedef __PST__UINT8 __PST__g__118(__PST__g__17, __PST__UINT16);
typedef __PST__UINT8 __PST__g__119(__PST__g__19, __PST__UINT16);
typedef __PST__UINT8 __PST__g__120(__PST__UINT16, __PST__g__19);
typedef __PST__UINT8 __PST__g__121(__PST__g__35);
typedef __PST__UINT8 __PST__g__122(__PST__UINT32, __PST__g__35);
typedef __PST__UINT8 __PST__g__123(void);
typedef __PST__UINT8 __PST__g__124(__PST__UINT16, __PST__UINT8, __PST__UINT8, __PST__UINT16);
typedef __PST__UINT16 __PST__g__125(void);
typedef const __PST__UINT8 __PST__g__128;
typedef __PST__g__128 *__PST__g__127;
typedef __PST__g__127 __PST__g__126(void);
typedef const __PST__SINT16 __PST__g__131;
typedef __PST__g__131 *__PST__g__130;
typedef __PST__g__130 __PST__g__129(void);
typedef __PST__VOID __PST__g__132(__PST__UINT16);
typedef __PST__VOID __PST__g__133(__PST__UINT8);
typedef __PST__FLOAT32 __PST__g__134(__PST__FLOAT32);
typedef __PST__SINT32 __PST__g__135();
typedef __PST__FLOAT32 __PST__g__136(__PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32);
typedef __PST__UINT8 __PST__g__137(__PST__SINT8);
typedef __PST__g__134 *__PST__g__138;
typedef const __PST__g__32 __PST__g__139;
typedef __PST__g__139 *__PST__g__140;
typedef const __PST__g__17 __PST__g__141;
typedef __PST__g__141 *__PST__g__142;
typedef __PST__g__117 *__PST__g__143;
typedef __PST__g__37 *__PST__g__144;
typedef volatile union __PST__g__59 __PST__g__145;
typedef __PST__g__145 *__PST__g__146;
typedef volatile struct __PST__g__60 __PST__g__147;
typedef __PST__g__147 *__PST__g__148;
typedef __PST__g__121 *__PST__g__151;
typedef volatile __PST__g__65 __PST__g__152;
typedef __PST__g__152 *__PST__g__153;
typedef volatile __PST__g__67 __PST__g__154;
typedef __PST__g__154 *__PST__g__155;
typedef __PST__g__122 *__PST__g__158;
typedef volatile union __PST__g__39 __PST__g__159;
typedef __PST__g__159 *__PST__g__160;
typedef volatile __PST__UINT32 __PST__g__161;
typedef __PST__g__161 *__PST__g__162;
typedef volatile union __PST__g__47 __PST__g__163;
typedef __PST__g__163 *__PST__g__164;
typedef volatile union __PST__g__52 __PST__g__165;
typedef __PST__g__165 *__PST__g__166;
typedef volatile union __PST__g__56 __PST__g__167;
typedef __PST__g__167 *__PST__g__168;
typedef __PST__g__123 *__PST__g__169;
typedef volatile union __PST__g__75 __PST__g__170;
typedef __PST__g__170 *__PST__g__171;
typedef volatile union __PST__g__62 __PST__g__172;
typedef __PST__g__172 *__PST__g__173;
typedef __PST__g__135 *__PST__g__174;
typedef volatile struct __PST__g__76 __PST__g__175;
typedef __PST__g__175 *__PST__g__176;
typedef volatile __PST__g__70 __PST__g__179;
typedef __PST__g__179 *__PST__g__180;
typedef volatile __PST__g__72 __PST__g__181;
typedef __PST__g__181 *__PST__g__182;
typedef const __PST__g__19 __PST__g__185;
typedef __PST__g__185 *__PST__g__186;
typedef volatile __PST__g__81 __PST__g__187;
typedef __PST__g__187 *__PST__g__188;
typedef volatile __PST__g__106 __PST__g__189;
typedef __PST__g__189 *__PST__g__190;
typedef const __PST__g__35 __PST__g__191;
typedef __PST__g__191 *__PST__g__192;
typedef __PST__g__119 *__PST__g__193;
typedef __PST__g__124 *__PST__g__194;
typedef __PST__g__125 *__PST__g__195;
typedef const __PST__g__36 __PST__g__196;
typedef __PST__g__196 *__PST__g__197;
typedef __PST__g__132 *__PST__g__198;
typedef __PST__g__133 *__PST__g__199;
typedef __PST__UINT32 __PST__g__200(__PST__g__161);
typedef __PST__g__200 *__PST__g__201;
typedef volatile __PST__g__108 __PST__g__202;
typedef __PST__g__202 *__PST__g__203;
typedef __PST__g__115 *__PST__g__204;
typedef __PST__g__114 *__PST__g__205;
typedef __PST__g__116 *__PST__g__206;
typedef __PST__g__126 *__PST__g__207;
typedef __PST__g__137 *__PST__g__208;
typedef __PST__g__136 *__PST__g__209;
typedef __PST__g__120 *__PST__g__210;
typedef __PST__g__118 *__PST__g__211;
typedef __PST__g__129 *__PST__g__212;
typedef volatile __PST__SINT32 __PST__g__213;
typedef __PST__SINT8 __PST__g__219(void);
typedef volatile __PST__SINT8 __PST__g__220;
typedef volatile __PST__UINT8 __PST__g__221;
typedef __PST__SINT32 __PST__g__222(void);
typedef __PST__UINT32 __PST__g__223(void);
typedef __PST__FLOAT64 __PST__g__224(void);
typedef volatile __PST__FLOAT64 __PST__g__225;
typedef __PST__SINT32 __PST__g__226(void);
