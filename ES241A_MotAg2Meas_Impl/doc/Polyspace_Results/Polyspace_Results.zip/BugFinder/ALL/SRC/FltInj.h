
#ifndef FLTINJ_H
#define FLTINJ_H

/* Fault Injection Command */
#define FLTINJ_MOTAG2MEAS_MOTAG2MECL            40U

#endif
