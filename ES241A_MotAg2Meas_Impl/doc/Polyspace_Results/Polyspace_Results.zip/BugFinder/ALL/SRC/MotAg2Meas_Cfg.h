
#ifndef MOTAG2MEAS_CFG_H        
#define MOTAG2MEAS_CFG_H

#include "Rte_MotAg2Meas_Type.h"

#define MOTAG2ANSINCOSFLTNTCNR_CNT_ENUM                 NTCNR_0X087

#endif
