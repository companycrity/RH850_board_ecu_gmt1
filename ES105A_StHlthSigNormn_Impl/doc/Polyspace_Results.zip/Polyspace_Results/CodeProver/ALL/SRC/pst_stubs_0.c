#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * Rte_Read_StHlthSigNormn_CurrMotSumABC_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_CurrMotSumABC_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_CurrMotSumDEF_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_CurrMotSumDEF_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_DutyCycThermProtnMaxOutp_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_DutyCycThermProtnMaxOutp_Val(__PST__g__28 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_7;
        }
        P_0[0] = pst_random_g_7;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_EcuTFild_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_EcuTFild_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_HwAg_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_HwAg_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_HwAgEotCcw_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_HwAgEotCcw_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_HwAgEotCw_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_HwAgEotCw_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_HwAuthy_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_HwAuthy_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_HwTqChACorrlnTraErr_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_HwTqChACorrlnTraErr_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_HwTqChBCorrlnTraErr_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_HwTqChBCorrlnTraErr_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_HwTqIdptSig_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_HwTqIdptSig_Val(__PST__g__27 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_LclRamEccSngBitCntrOutp_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_LclRamEccSngBitCntrOutp_Val(__PST__g__27 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_MaxLrndFric_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_MaxLrndFric_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_MotAg2VltgSqd_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_MotAg2VltgSqd_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_MotAgABErrTerm_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_MotAgABErrTerm_Val(__PST__g__28 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_7;
        }
        P_0[0] = pst_random_g_7;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_MotAgACErrTerm_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_MotAgACErrTerm_Val(__PST__g__28 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_7;
        }
        P_0[0] = pst_random_g_7;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_MotAgBCErrTerm_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_MotAgBCErrTerm_Val(__PST__g__28 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_7;
        }
        P_0[0] = pst_random_g_7;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_MotDrvErrA_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_MotDrvErrA_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_MotDrvErrB_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_MotDrvErrB_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_MotDrvErrC_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_MotDrvErrC_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_MotDrvErrD_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_MotDrvErrD_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_MotDrvErrE_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_MotDrvErrE_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_MotDrvErrF_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_MotDrvErrF_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_MotVelCrf_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_MotVelCrf_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_RackLimrEotSig0Avl_Logl
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_RackLimrEotSig0Avl_Logl(__PST__g__27 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_RackLimrEotSig1Avl_Logl
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_RackLimrEotSig1Avl_Logl(__PST__g__27 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_StHlthSigNormn_WhlImbRejctnCmd_Val
 */


__PST__UINT8 Rte_Read_StHlthSigNormn_WhlImbRejctnCmd_Val(__PST__g__31 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_AbsltMotPosABDifStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_AbsltMotPosABDifStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_AbsltMotPosABDifStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_AbsltMotPosACDifStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_AbsltMotPosACDifStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_AbsltMotPosACDifStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_AbsltMotPosBCDifStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_AbsltMotPosBCDifStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_AbsltMotPosBCDifStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_CtrlrTRng_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_CtrlrTRng_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_CtrlrTRng_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_CtrlrTStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_CtrlrTStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_CtrlrTStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_CurrMotSumABCStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_CurrMotSumABCStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_CurrMotSumABCStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_CurrMotSumDEFStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_CurrMotSumDEFStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_CurrMotSumDEFStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_DigTqIdptSigStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_DigTqIdptSigStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_DigTqIdptSigStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_DigTqSnsrAStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_DigTqSnsrAStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_DigTqSnsrAStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_DigTqSnsrBStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_DigTqSnsrBStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_DigTqSnsrBStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_DutyCycStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_DutyCycStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_DutyCycStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_EotImpctStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_EotImpctStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_EotImpctStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_FricEstimnStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_FricEstimnStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_FricEstimnStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_MotPosStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_MotPosStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_MotPosStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_OutpAssiStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_OutpAssiStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_OutpAssiStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_PhaAStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_PhaAStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_PhaAStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_PhaBStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_PhaBStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_PhaBStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_PhaCStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_PhaCStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_PhaCStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_PhaDStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_PhaDStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_PhaDStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_PhaEStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_PhaEStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_PhaEStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_PhaFStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_PhaFStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_PhaFStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_RamEccSngBitCorrnStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_RamEccSngBitCorrnStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_RamEccSngBitCorrnStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_VltgRng_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_VltgRng_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_VltgRng_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_StHlthSigNormn_WhlImbMaxCmpStHlth_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_StHlthSigNormn_WhlImbMaxCmpStHlth_Val"


__PST__UINT8 Rte_Write_StHlthSigNormn_WhlImbMaxCmpStHlth_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_StHlthSigNormn_GetFricLrngData_Oper
 */


__PST__UINT8 Rte_Call_StHlthSigNormn_GetFricLrngData_Oper(__PST__g__27 P_0, __PST__g__27 P_1, __PST__g__27 P_2, __PST__g__31 P_3)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_6;
        }
        P_1[0] = pst_random_g_6;
    }

    /* parameter 2 */

    if (P_2 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_2[pst_random_int] = pst_random_g_6;
        }
        P_2[0] = pst_random_g_6;
    }

    /* parameter 3 */

    if (P_3 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_3[pst_random_int] = pst_random_g_10;
        }
        P_3[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_StHlthSigNormn_GetNtcQlfrSts_Oper
 */


__PST__UINT8 Rte_Call_StHlthSigNormn_GetNtcQlfrSts_Oper(__PST__UINT16 P_0, __PST__g__27 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_6;
        }
        P_1[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_StHlthSigNormn_SetNtcSts_Oper
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_StHlthSigNormn_SetNtcSts_Oper"


__PST__UINT8 Rte_Call_StHlthSigNormn_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_CurrMeasCorrlnMaxErrCurr_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_CurrMeasCorrlnMaxErrCurr_Val"


__PST__FLOAT32 Rte_Prm_StHlthSigNormn_CurrMeasCorrlnMaxErrCurr_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_EcuTMeasRngDiagcMax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_EcuTMeasRngDiagcMax_Val"


__PST__FLOAT32 Rte_Prm_StHlthSigNormn_EcuTMeasRngDiagcMax_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_EcuTMeasRngDiagcMin_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_EcuTMeasRngDiagcMin_Val"


__PST__FLOAT32 Rte_Prm_StHlthSigNormn_EcuTMeasRngDiagcMin_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_EotLrngAuthyStrtLrn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_EotLrngAuthyStrtLrn_Val"


__PST__FLOAT32 Rte_Prm_StHlthSigNormn_EotLrngAuthyStrtLrn_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_HwTqCorrlnChATraSumSetFltThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_HwTqCorrlnChATraSumSetFltThd_Val"


__PST__FLOAT32 Rte_Prm_StHlthSigNormn_HwTqCorrlnChATraSumSetFltThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_HwTqCorrlnChBTraSumSetFltThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_HwTqCorrlnChBTraSumSetFltThd_Val"


__PST__FLOAT32 Rte_Prm_StHlthSigNormn_HwTqCorrlnChBTraSumSetFltThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_StHlthSigNormnHiCtrlrT_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_StHlthSigNormnHiCtrlrT_Val"


__PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnHiCtrlrT_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_StHlthSigNormnLoCtrlrT_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_StHlthSigNormnLoCtrlrT_Val"


__PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnLoCtrlrT_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_StHlthSigNormnMaxFricThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_StHlthSigNormnMaxFricThd_Val"


__PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnMaxFricThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_StHlthSigNormnMinRackTrvlLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_StHlthSigNormnMinRackTrvlLim_Val"


__PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnMinRackTrvlLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_StHlthSigNormnMotVelCal_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_StHlthSigNormnMotVelCal_Val"


__PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnMotVelCal_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthCurrMotSum_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthCurrMotSum_Val"


__PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthCurrMotSum_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthPhaInfo_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthPhaInfo_Val"


__PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthPhaInfo_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_StHlthSigNormnValMaxStHlthErr_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_StHlthSigNormnValMaxStHlthErr_Val"


__PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnValMaxStHlthErr_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_StHlthSigNormnValMinStHlthErr_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_StHlthSigNormnValMinStHlthErr_Val"


__PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnValMinStHlthErr_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_StHlthSigNormnWhlImbRejctnThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_StHlthSigNormnWhlImbRejctnThd_Val"


__PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnWhlImbRejctnThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_MotDrvDiagcErrThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_MotDrvDiagcErrThd_Val"


__PST__UINT32 Rte_Prm_StHlthSigNormn_MotDrvDiagcErrThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_DutyCycThermProtnDutyCycFildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_DutyCycThermProtnDutyCycFildThd_Val"


__PST__UINT16 Rte_Prm_StHlthSigNormn_DutyCycThermProtnDutyCycFildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_StHlthSigNormnDutyCycFltLimThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_StHlthSigNormnDutyCycFltLimThd_Val"


__PST__UINT16 Rte_Prm_StHlthSigNormn_StHlthSigNormnDutyCycFltLimThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthCorrlnErr_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthCorrlnErr_Val"


__PST__UINT16 Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthCorrlnErr_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_StHlthSigNormnAbsltMotPosDifStHlthDiagThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_StHlthSigNormnAbsltMotPosDifStHlthDiagThd_Val"


__PST__UINT8 Rte_Prm_StHlthSigNormn_StHlthSigNormnAbsltMotPosDifStHlthDiagThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_StHlthSigNormnCurrMotSumStHlthDiagThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_StHlthSigNormnCurrMotSumStHlthDiagThd_Val"


__PST__UINT8 Rte_Prm_StHlthSigNormn_StHlthSigNormnCurrMotSumStHlthDiagThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_StHlthSigNormnDigTqStHlthDiagThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_StHlthSigNormnDigTqStHlthDiagThd_Val"


__PST__UINT8 Rte_Prm_StHlthSigNormn_StHlthSigNormnDigTqStHlthDiagThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_StHlthSigNormnIdptSigStHlthSca_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_StHlthSigNormnIdptSigStHlthSca_Val"


__PST__UINT8 Rte_Prm_StHlthSigNormn_StHlthSigNormnIdptSigStHlthSca_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_StHlthSigNormnMotPosStHlthDiagThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_StHlthSigNormnMotPosStHlthDiagThd_Val"


__PST__UINT8 Rte_Prm_StHlthSigNormn_StHlthSigNormnMotPosStHlthDiagThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_StHlthSigNormnPhaInfoStHlthDiagThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_StHlthSigNormnPhaInfoStHlthDiagThd_Val"


__PST__UINT8 Rte_Prm_StHlthSigNormn_StHlthSigNormnPhaInfoStHlthDiagThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_StHlthSigNormn_SysGlbPrmMotPoleCnt_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_StHlthSigNormn_SysGlbPrmMotPoleCnt_Val"


__PST__UINT8 Rte_Prm_StHlthSigNormn_SysGlbPrmMotPoleCnt_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_IrvWrite_StHlthSigNormn_StHlthSigNormnInit1_EolFric
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvWrite_StHlthSigNormn_StHlthSigNormnInit1_EolFric"


__PST__VOID Rte_IrvWrite_StHlthSigNormn_StHlthSigNormnInit1_EolFric(__PST__FLOAT32 P_0)
{
    /* function is pure */

    return;
}

/*
 * Rte_IrvRead_StHlthSigNormn_UpdRawSig_Oper_EolFric
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvRead_StHlthSigNormn_UpdRawSig_Oper_EolFric"


__PST__FLOAT32 Rte_IrvRead_StHlthSigNormn_UpdRawSig_Oper_EolFric(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * fabsf
 */

#pragma POLYSPACE_POLYMORPHIC "fabsf"


__PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

