/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Rte_Read_StHlthSigNormn_CurrMotSumABC_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_CurrMotSumABC_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_CurrMotSumABC_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_CurrMotSumABC_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_CurrMotSumABC_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_CurrMotSumDEF_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_CurrMotSumDEF_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_CurrMotSumDEF_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_CurrMotSumDEF_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_CurrMotSumDEF_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_DutyCycThermProtnMaxOutp_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_DutyCycThermProtnMaxOutp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_DutyCycThermProtnMaxOutp_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_DutyCycThermProtnMaxOutp_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_DutyCycThermProtnMaxOutp_Val(__PST__g__28 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_EcuTFild_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_EcuTFild_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_EcuTFild_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_EcuTFild_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_EcuTFild_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_HwAg_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_HwAg_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_HwAg_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_HwAg_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_HwAg_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_HwAgEotCcw_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_HwAgEotCcw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_HwAgEotCcw_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_HwAgEotCcw_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_HwAgEotCcw_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_HwAgEotCw_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_HwAgEotCw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_HwAgEotCw_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_HwAgEotCw_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_HwAgEotCw_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_HwAuthy_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_HwAuthy_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_HwAuthy_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_HwAuthy_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_HwAuthy_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_HwTqChACorrlnTraErr_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_HwTqChACorrlnTraErr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_HwTqChACorrlnTraErr_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_HwTqChACorrlnTraErr_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_HwTqChACorrlnTraErr_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_HwTqChBCorrlnTraErr_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_HwTqChBCorrlnTraErr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_HwTqChBCorrlnTraErr_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_HwTqChBCorrlnTraErr_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_HwTqChBCorrlnTraErr_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_HwTqIdptSig_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_HwTqIdptSig_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_HwTqIdptSig_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_HwTqIdptSig_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_HwTqIdptSig_Val(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_LclRamEccSngBitCntrOutp_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_LclRamEccSngBitCntrOutp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_LclRamEccSngBitCntrOutp_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_LclRamEccSngBitCntrOutp_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_LclRamEccSngBitCntrOutp_Val(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_MaxLrndFric_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_MaxLrndFric_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_MaxLrndFric_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_MaxLrndFric_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_MaxLrndFric_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_MotAg2VltgSqd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_MotAg2VltgSqd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_MotAg2VltgSqd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_MotAg2VltgSqd_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_MotAg2VltgSqd_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_MotAgABErrTerm_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_MotAgABErrTerm_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_MotAgABErrTerm_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_MotAgABErrTerm_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_MotAgABErrTerm_Val(__PST__g__28 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_MotAgACErrTerm_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_MotAgACErrTerm_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_MotAgACErrTerm_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_MotAgACErrTerm_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_MotAgACErrTerm_Val(__PST__g__28 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_MotAgBCErrTerm_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_MotAgBCErrTerm_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_MotAgBCErrTerm_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_MotAgBCErrTerm_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_MotAgBCErrTerm_Val(__PST__g__28 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_MotDrvErrA_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_MotDrvErrA_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_MotDrvErrA_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_MotDrvErrA_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_MotDrvErrA_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_MotDrvErrB_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_MotDrvErrB_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_MotDrvErrB_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_MotDrvErrB_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_MotDrvErrB_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_MotDrvErrC_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_MotDrvErrC_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_MotDrvErrC_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_MotDrvErrC_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_MotDrvErrC_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_MotDrvErrD_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_MotDrvErrD_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_MotDrvErrD_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_MotDrvErrD_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_MotDrvErrD_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_MotDrvErrE_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_MotDrvErrE_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_MotDrvErrE_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_MotDrvErrE_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_MotDrvErrE_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_MotDrvErrF_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_MotDrvErrF_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_MotDrvErrF_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_MotDrvErrF_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_MotDrvErrF_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_MotVelCrf_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_MotVelCrf_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_MotVelCrf_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_MotVelCrf_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_MotVelCrf_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_RackLimrEotSig0Avl_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_RackLimrEotSig0Avl_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_RackLimrEotSig0Avl_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_RackLimrEotSig0Avl_Logl"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_RackLimrEotSig0Avl_Logl(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_RackLimrEotSig1Avl_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_RackLimrEotSig1Avl_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_RackLimrEotSig1Avl_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_RackLimrEotSig1Avl_Logl"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_RackLimrEotSig1Avl_Logl(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_StHlthSigNormn_WhlImbRejctnCmd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_StHlthSigNormn_WhlImbRejctnCmd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_StHlthSigNormn_WhlImbRejctnCmd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_StHlthSigNormn_WhlImbRejctnCmd_Val"
//
// __PST__UINT8 Rte_Read_StHlthSigNormn_WhlImbRejctnCmd_Val(__PST__g__31 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_AbsltMotPosABDifStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_AbsltMotPosABDifStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_AbsltMotPosABDifStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_AbsltMotPosABDifStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_AbsltMotPosABDifStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_AbsltMotPosACDifStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_AbsltMotPosACDifStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_AbsltMotPosACDifStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_AbsltMotPosACDifStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_AbsltMotPosACDifStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_AbsltMotPosBCDifStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_AbsltMotPosBCDifStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_AbsltMotPosBCDifStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_AbsltMotPosBCDifStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_AbsltMotPosBCDifStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_CtrlrTRng_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_CtrlrTRng_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_CtrlrTRng_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_CtrlrTRng_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_CtrlrTRng_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_CtrlrTStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_CtrlrTStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_CtrlrTStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_CtrlrTStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_CtrlrTStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_CurrMotSumABCStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_CurrMotSumABCStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_CurrMotSumABCStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_CurrMotSumABCStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_CurrMotSumABCStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_CurrMotSumDEFStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_CurrMotSumDEFStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_CurrMotSumDEFStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_CurrMotSumDEFStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_CurrMotSumDEFStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_DigTqIdptSigStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_DigTqIdptSigStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_DigTqIdptSigStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_DigTqIdptSigStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_DigTqIdptSigStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_DigTqSnsrAStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_DigTqSnsrAStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_DigTqSnsrAStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_DigTqSnsrAStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_DigTqSnsrAStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_DigTqSnsrBStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_DigTqSnsrBStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_DigTqSnsrBStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_DigTqSnsrBStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_DigTqSnsrBStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_DutyCycStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_DutyCycStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_DutyCycStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_DutyCycStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_DutyCycStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_EotImpctStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_EotImpctStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_EotImpctStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_EotImpctStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_EotImpctStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_FricEstimnStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_FricEstimnStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_FricEstimnStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_FricEstimnStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_FricEstimnStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_MotPosStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_MotPosStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_MotPosStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_MotPosStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_MotPosStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_OutpAssiStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_OutpAssiStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_OutpAssiStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_OutpAssiStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_OutpAssiStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_PhaAStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_PhaAStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_PhaAStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_PhaAStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_PhaAStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_PhaBStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_PhaBStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_PhaBStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_PhaBStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_PhaBStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_PhaCStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_PhaCStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_PhaCStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_PhaCStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_PhaCStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_PhaDStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_PhaDStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_PhaDStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_PhaDStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_PhaDStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_PhaEStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_PhaEStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_PhaEStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_PhaEStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_PhaEStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_PhaFStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_PhaFStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_PhaFStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_PhaFStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_PhaFStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_RamEccSngBitCorrnStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_RamEccSngBitCorrnStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_RamEccSngBitCorrnStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_RamEccSngBitCorrnStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_RamEccSngBitCorrnStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_VltgRng_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_VltgRng_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_VltgRng_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_VltgRng_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_VltgRng_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_StHlthSigNormn_WhlImbMaxCmpStHlth_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_StHlthSigNormn_WhlImbMaxCmpStHlth_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_StHlthSigNormn_WhlImbMaxCmpStHlth_Val"
// #pragma POLYSPACE_WORST "Rte_Write_StHlthSigNormn_WhlImbMaxCmpStHlth_Val"
//
// __PST__UINT8 Rte_Write_StHlthSigNormn_WhlImbMaxCmpStHlth_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_StHlthSigNormn_GetFricLrngData_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_StHlthSigNormn_GetFricLrngData_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_StHlthSigNormn_GetFricLrngData_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_StHlthSigNormn_GetFricLrngData_Oper"
//
// __PST__UINT8 Rte_Call_StHlthSigNormn_GetFricLrngData_Oper(__PST__g__27 P_0, __PST__g__27 P_1, __PST__g__27 P_2, __PST__g__31 P_3)
// {
//    ...
// }


// Pragmas for function Rte_Call_StHlthSigNormn_GetNtcQlfrSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_StHlthSigNormn_GetNtcQlfrSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_StHlthSigNormn_GetNtcQlfrSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_StHlthSigNormn_GetNtcQlfrSts_Oper"
//
// __PST__UINT8 Rte_Call_StHlthSigNormn_GetNtcQlfrSts_Oper(__PST__UINT16 P_0, __PST__g__27 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_StHlthSigNormn_SetNtcSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_StHlthSigNormn_SetNtcSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_StHlthSigNormn_SetNtcSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_StHlthSigNormn_SetNtcSts_Oper"
//
// __PST__UINT8 Rte_Call_StHlthSigNormn_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_CurrMeasCorrlnMaxErrCurr_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_CurrMeasCorrlnMaxErrCurr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_CurrMeasCorrlnMaxErrCurr_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_CurrMeasCorrlnMaxErrCurr_Val"
//
// __PST__FLOAT32 Rte_Prm_StHlthSigNormn_CurrMeasCorrlnMaxErrCurr_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_EcuTMeasRngDiagcMax_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_EcuTMeasRngDiagcMax_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_EcuTMeasRngDiagcMax_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_EcuTMeasRngDiagcMax_Val"
//
// __PST__FLOAT32 Rte_Prm_StHlthSigNormn_EcuTMeasRngDiagcMax_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_EcuTMeasRngDiagcMin_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_EcuTMeasRngDiagcMin_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_EcuTMeasRngDiagcMin_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_EcuTMeasRngDiagcMin_Val"
//
// __PST__FLOAT32 Rte_Prm_StHlthSigNormn_EcuTMeasRngDiagcMin_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_EotLrngAuthyStrtLrn_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_EotLrngAuthyStrtLrn_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_EotLrngAuthyStrtLrn_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_EotLrngAuthyStrtLrn_Val"
//
// __PST__FLOAT32 Rte_Prm_StHlthSigNormn_EotLrngAuthyStrtLrn_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_HwTqCorrlnChATraSumSetFltThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_HwTqCorrlnChATraSumSetFltThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_HwTqCorrlnChATraSumSetFltThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_HwTqCorrlnChATraSumSetFltThd_Val"
//
// __PST__FLOAT32 Rte_Prm_StHlthSigNormn_HwTqCorrlnChATraSumSetFltThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_HwTqCorrlnChBTraSumSetFltThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_HwTqCorrlnChBTraSumSetFltThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_HwTqCorrlnChBTraSumSetFltThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_HwTqCorrlnChBTraSumSetFltThd_Val"
//
// __PST__FLOAT32 Rte_Prm_StHlthSigNormn_HwTqCorrlnChBTraSumSetFltThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_StHlthSigNormnHiCtrlrT_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_StHlthSigNormnHiCtrlrT_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_StHlthSigNormnHiCtrlrT_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_StHlthSigNormnHiCtrlrT_Val"
//
// __PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnHiCtrlrT_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_StHlthSigNormnLoCtrlrT_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_StHlthSigNormnLoCtrlrT_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_StHlthSigNormnLoCtrlrT_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_StHlthSigNormnLoCtrlrT_Val"
//
// __PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnLoCtrlrT_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_StHlthSigNormnMaxFricThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_StHlthSigNormnMaxFricThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_StHlthSigNormnMaxFricThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_StHlthSigNormnMaxFricThd_Val"
//
// __PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnMaxFricThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_StHlthSigNormnMinRackTrvlLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_StHlthSigNormnMinRackTrvlLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_StHlthSigNormnMinRackTrvlLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_StHlthSigNormnMinRackTrvlLim_Val"
//
// __PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnMinRackTrvlLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_StHlthSigNormnMotVelCal_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_StHlthSigNormnMotVelCal_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_StHlthSigNormnMotVelCal_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_StHlthSigNormnMotVelCal_Val"
//
// __PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnMotVelCal_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthCurrMotSum_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthCurrMotSum_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthCurrMotSum_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthCurrMotSum_Val"
//
// __PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthCurrMotSum_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthPhaInfo_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthPhaInfo_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthPhaInfo_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthPhaInfo_Val"
//
// __PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthPhaInfo_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_StHlthSigNormnValMaxStHlthErr_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_StHlthSigNormnValMaxStHlthErr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_StHlthSigNormnValMaxStHlthErr_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_StHlthSigNormnValMaxStHlthErr_Val"
//
// __PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnValMaxStHlthErr_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_StHlthSigNormnValMinStHlthErr_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_StHlthSigNormnValMinStHlthErr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_StHlthSigNormnValMinStHlthErr_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_StHlthSigNormnValMinStHlthErr_Val"
//
// __PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnValMinStHlthErr_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_StHlthSigNormnWhlImbRejctnThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_StHlthSigNormnWhlImbRejctnThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_StHlthSigNormnWhlImbRejctnThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_StHlthSigNormnWhlImbRejctnThd_Val"
//
// __PST__FLOAT32 Rte_Prm_StHlthSigNormn_StHlthSigNormnWhlImbRejctnThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_MotDrvDiagcErrThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_MotDrvDiagcErrThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_MotDrvDiagcErrThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_MotDrvDiagcErrThd_Val"
//
// __PST__UINT32 Rte_Prm_StHlthSigNormn_MotDrvDiagcErrThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_DutyCycThermProtnDutyCycFildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_DutyCycThermProtnDutyCycFildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_DutyCycThermProtnDutyCycFildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_DutyCycThermProtnDutyCycFildThd_Val"
//
// __PST__UINT16 Rte_Prm_StHlthSigNormn_DutyCycThermProtnDutyCycFildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_StHlthSigNormnDutyCycFltLimThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_StHlthSigNormnDutyCycFltLimThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_StHlthSigNormnDutyCycFltLimThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_StHlthSigNormnDutyCycFltLimThd_Val"
//
// __PST__UINT16 Rte_Prm_StHlthSigNormn_StHlthSigNormnDutyCycFltLimThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthCorrlnErr_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthCorrlnErr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthCorrlnErr_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthCorrlnErr_Val"
//
// __PST__UINT16 Rte_Prm_StHlthSigNormn_StHlthSigNormnStHlthCorrlnErr_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_StHlthSigNormnAbsltMotPosDifStHlthDiagThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_StHlthSigNormnAbsltMotPosDifStHlthDiagThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_StHlthSigNormnAbsltMotPosDifStHlthDiagThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_StHlthSigNormnAbsltMotPosDifStHlthDiagThd_Val"
//
// __PST__UINT8 Rte_Prm_StHlthSigNormn_StHlthSigNormnAbsltMotPosDifStHlthDiagThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_StHlthSigNormnCurrMotSumStHlthDiagThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_StHlthSigNormnCurrMotSumStHlthDiagThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_StHlthSigNormnCurrMotSumStHlthDiagThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_StHlthSigNormnCurrMotSumStHlthDiagThd_Val"
//
// __PST__UINT8 Rte_Prm_StHlthSigNormn_StHlthSigNormnCurrMotSumStHlthDiagThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_StHlthSigNormnDigTqStHlthDiagThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_StHlthSigNormnDigTqStHlthDiagThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_StHlthSigNormnDigTqStHlthDiagThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_StHlthSigNormnDigTqStHlthDiagThd_Val"
//
// __PST__UINT8 Rte_Prm_StHlthSigNormn_StHlthSigNormnDigTqStHlthDiagThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_StHlthSigNormnIdptSigStHlthSca_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_StHlthSigNormnIdptSigStHlthSca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_StHlthSigNormnIdptSigStHlthSca_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_StHlthSigNormnIdptSigStHlthSca_Val"
//
// __PST__UINT8 Rte_Prm_StHlthSigNormn_StHlthSigNormnIdptSigStHlthSca_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_StHlthSigNormnMotPosStHlthDiagThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_StHlthSigNormnMotPosStHlthDiagThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_StHlthSigNormnMotPosStHlthDiagThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_StHlthSigNormnMotPosStHlthDiagThd_Val"
//
// __PST__UINT8 Rte_Prm_StHlthSigNormn_StHlthSigNormnMotPosStHlthDiagThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_StHlthSigNormnPhaInfoStHlthDiagThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_StHlthSigNormnPhaInfoStHlthDiagThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_StHlthSigNormnPhaInfoStHlthDiagThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_StHlthSigNormnPhaInfoStHlthDiagThd_Val"
//
// __PST__UINT8 Rte_Prm_StHlthSigNormn_StHlthSigNormnPhaInfoStHlthDiagThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_StHlthSigNormn_SysGlbPrmMotPoleCnt_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_StHlthSigNormn_SysGlbPrmMotPoleCnt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_StHlthSigNormn_SysGlbPrmMotPoleCnt_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_StHlthSigNormn_SysGlbPrmMotPoleCnt_Val"
//
// __PST__UINT8 Rte_Prm_StHlthSigNormn_SysGlbPrmMotPoleCnt_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_StHlthSigNormn_StHlthSigNormnInit1_EolFric
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_StHlthSigNormn_StHlthSigNormnInit1_EolFric"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_StHlthSigNormn_StHlthSigNormnInit1_EolFric"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_StHlthSigNormn_StHlthSigNormnInit1_EolFric"
//
// __PST__VOID Rte_IrvWrite_StHlthSigNormn_StHlthSigNormnInit1_EolFric(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_StHlthSigNormn_UpdRawSig_Oper_EolFric
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_StHlthSigNormn_UpdRawSig_Oper_EolFric"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_StHlthSigNormn_UpdRawSig_Oper_EolFric"
// #pragma POLYSPACE_WORST "Rte_IrvRead_StHlthSigNormn_UpdRawSig_Oper_EolFric"
//
// __PST__FLOAT32 Rte_IrvRead_StHlthSigNormn_UpdRawSig_Oper_EolFric(__PST__VOID)
// {
//    ...
// }


// Pragmas for function fabsf
//
// #pragma POLYSPACE_PURE "fabsf"
// #pragma POLYSPACE_CLEAN "fabsf"
// #pragma POLYSPACE_WORST "fabsf"
//
// __PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
// {
//    ...
// }

