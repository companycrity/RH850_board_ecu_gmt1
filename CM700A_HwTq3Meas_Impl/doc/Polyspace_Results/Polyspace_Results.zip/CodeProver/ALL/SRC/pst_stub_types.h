typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__VOID __PST__g__15(void);
typedef __PST__FLOAT32 *__PST__g__17;
typedef __PST__VOID __PST__g__16(__PST__g__17);
typedef __PST__UINT8 *__PST__g__19;
typedef __PST__VOID __PST__g__18(__PST__g__19);
typedef __PST__VOID __PST__g__20(__PST__FLOAT32);
typedef long double __PST__FLOAT96;
typedef __PST__FLOAT96 __PST__g__21(void);
typedef __PST__g__11 *__PST__g__24;
typedef volatile __PST__FLOAT96 __PST__g__25;
typedef __PST__SINT8 *__PST__g__27;
typedef volatile __PST__g__27 __PST__g__26;
typedef const struct Rte_CDS_CDD_HwTq3Meas __PST__g__30;
typedef __PST__g__30 *__PST__g__29;
typedef const __PST__g__29 __PST__g__28;
typedef __PST__UINT32 *__PST__g__32;
typedef struct __PST__g__34 *__PST__g__33;
struct Rte_CDS_CDD_HwTq3Meas
  {
    __PST__g__19 Pim_GearIdn2Avl;
    __PST__g__19 Pim_GearIdn2Data;
    __PST__g__19 Pim_HwTq3ComStsErrCntr;
    __PST__g__19 Pim_HwTq3IntSnsrErrCntr;
    __PST__g__17 Pim_HwTq3MeasPrevHwTq3;
    __PST__g__19 Pim_HwTq3MeasPrevRollgCntr;
    __PST__g__32 Pim_HwTq3MsgMissRxCnt;
    __PST__g__33 Pim_HwTq3Offs;
  };
typedef __PST__SINT8 __PST__g__35[3];
struct __PST__g__34
  {
    __PST__FLOAT32 OffsTrim;
    __PST__UINT8 OffsTrimPrfmdSts;
    __PST__g__35 __pst_unused_field___pstfiller;
  };
typedef __PST__SINT32 __PST__g__204[1];
union __PST__g__38
  {
    __PST__g__204 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef __PST__SINT8 __PST__g__202[4];
typedef __PST__SINT8 __PST__g__203[8];
union __PST__g__46
  {
    __PST__g__204 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__51
  {
    __PST__g__204 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__55
  {
    __PST__g__204 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__58
  {
    __PST__g__204 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__61
  {
    __PST__g__204 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__65
  {
    __PST__g__204 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__65 __PST__g__64;
struct __PST__g__72
  {
    const __PST__UINT32 FRS : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    const __PST__UINT32 __pst_unused_field_2 : 1;
    const __PST__UINT32 __pst_unused_field_3 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    const __PST__UINT32 __pst_unused_field_6 : 1;
    const __PST__UINT32 NRS : 1;
    const __PST__UINT32 __pst_unused_field_8 : 1;
    const __PST__UINT32 __pst_unused_field_9 : 1;
    const __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 21;
  };
typedef const struct __PST__g__72 __PST__g__71;
union __PST__g__70
  {
    __PST__g__71 BIT;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__70 __PST__g__69;
struct __PST__g__75
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 NRC : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
union __PST__g__74
  {
    struct __PST__g__75 BIT;
    __PST__UINT32 UINT32;
  };
union __PST__g__82
  {
    __PST__g__204 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__82 __PST__g__81;
struct __PST__g__108
  {
    const __PST__UINT32 __pst_unused_field_0 : 24;
    const __PST__UINT32 __pst_unused_field_1 : 4;
    const __PST__UINT32 __pst_unused_field_2 : 2;
    const __PST__UINT32 FND : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
  };
typedef const struct __PST__g__108 __PST__g__107;
union __PST__g__106
  {
    __PST__g__107 BIT;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__106 __PST__g__105;
struct __PST__g__37
  {
    union __PST__g__38 TSPC;
    __PST__g__202 __pst_unused_field_1;
    __PST__g__203 __pst_unused_field_2;
    union __PST__g__46 _CC;
    union __PST__g__51 BRP;
    union __PST__g__55 IDE;
    union __PST__g__58 MDC;
    union __PST__g__61 SPCT;
    __PST__g__64 MST;
    __PST__g__69 CS;
    union __PST__g__74 CSC;
    __PST__g__202 __pst_unused_field_11;
    __PST__g__81 SRXD;
    __PST__g__202 __pst_unused_field_13;
    __PST__g__202 __pst_unused_field_14;
    __PST__g__202 __pst_unused_field_15;
    __PST__g__105 FRXD;
  };
typedef volatile struct __PST__g__37 __PST__g__36;
struct __PST__g__39
  {
    __PST__UINT32 __pst_unused_field_0 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 15;
  };
union __PST__g__43
  {
    __PST__g__204 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__44
  {
    __PST__UINT32 __pst_unused_field_0 : 32;
  };
typedef __PST__UINT8 __PST__g__45[8];
struct __PST__g__47
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 3;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 19;
  };
struct __PST__g__52
  {
    __PST__UINT32 __pst_unused_field_0 : 5;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 3;
    __PST__UINT32 __pst_unused_field_2 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_4 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_6 : 4;
    __PST__UINT32 __pst_unused_field_pstnonamef4 : 4;
  };
struct __PST__g__56
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 21;
  };
struct __PST__g__59
  {
    __PST__UINT32 __pst_unused_field_0 : 3;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
struct __PST__g__62
  {
    __PST__UINT32 __pst_unused_field_0 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 25;
  };
struct __PST__g__67
  {
    const __PST__UINT32 __pst_unused_field_0 : 3;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__67 __PST__g__66;
union __PST__g__77
  {
    __PST__g__204 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__77 __PST__g__76;
struct __PST__g__79
  {
    const __PST__UINT32 __pst_unused_field_0 : 32;
  };
typedef const struct __PST__g__79 __PST__g__78;
typedef const __PST__UINT32 __PST__g__80;
struct __PST__g__84
  {
    const __PST__UINT32 __pst_unused_field_0 : 20;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 3;
    const __PST__UINT32 __pst_unused_field_3 : 6;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
  };
typedef const struct __PST__g__84 __PST__g__83;
union __PST__g__90
  {
    __PST__g__204 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__90 __PST__g__89;
struct __PST__g__92
  {
    const __PST__UINT32 __pst_unused_field_0 : 17;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 15;
  };
typedef const struct __PST__g__92 __PST__g__91;
union __PST__g__96
  {
    __PST__g__204 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__96 __PST__g__95;
struct __PST__g__98
  {
    const __PST__UINT32 __pst_unused_field_0 : 21;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 11;
  };
typedef const struct __PST__g__98 __PST__g__97;
union __PST__g__102
  {
    __PST__g__204 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__102 __PST__g__101;
struct __PST__g__104
  {
    const __PST__UINT32 __pst_unused_field_0 : 32;
  };
typedef const struct __PST__g__104 __PST__g__103;
typedef __PST__VOID __PST__g__113(__PST__SINT32);
typedef __PST__UINT8 __PST__g__114(__PST__g__27);
typedef __PST__UINT8 __PST__g__115(__PST__UINT8);
typedef __PST__UINT8 __PST__g__116(__PST__FLOAT32);
typedef __PST__UINT8 __PST__g__117(__PST__UINT16, __PST__g__19);
typedef __PST__UINT8 __PST__g__118(__PST__g__32);
typedef __PST__UINT8 __PST__g__119(__PST__UINT32, __PST__g__32);
typedef __PST__UINT8 __PST__g__120(void);
typedef __PST__UINT8 __PST__g__121(__PST__UINT16, __PST__UINT8, __PST__UINT8, __PST__UINT16);
typedef __PST__UINT16 __PST__g__122(void);
typedef __PST__SINT32 __PST__g__123();
typedef __PST__FLOAT32 __PST__g__124(__PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32);
typedef __PST__UINT8 __PST__g__125(__PST__UINT8, __PST__UINT8, __PST__UINT8);
typedef const __PST__g__33 __PST__g__126;
typedef __PST__g__126 *__PST__g__127;
typedef const __PST__g__17 __PST__g__128;
typedef __PST__g__128 *__PST__g__129;
typedef __PST__g__115 *__PST__g__130;
typedef __PST__g__36 *__PST__g__131;
typedef volatile union __PST__g__58 __PST__g__132;
typedef __PST__g__132 *__PST__g__133;
typedef volatile __PST__UINT32 __PST__g__134;
typedef __PST__g__134 *__PST__g__135;
typedef __PST__g__118 *__PST__g__136;
typedef volatile __PST__g__64 __PST__g__137;
typedef __PST__g__137 *__PST__g__138;
typedef volatile __PST__g__80 __PST__g__139;
typedef __PST__g__139 *__PST__g__140;
typedef __PST__g__119 *__PST__g__141;
typedef volatile union __PST__g__38 __PST__g__142;
typedef __PST__g__142 *__PST__g__143;
typedef volatile union __PST__g__46 __PST__g__144;
typedef __PST__g__144 *__PST__g__145;
typedef volatile union __PST__g__51 __PST__g__146;
typedef __PST__g__146 *__PST__g__147;
typedef volatile union __PST__g__55 __PST__g__148;
typedef __PST__g__148 *__PST__g__149;
typedef volatile union __PST__g__61 __PST__g__150;
typedef __PST__g__150 *__PST__g__151;
typedef __PST__g__120 *__PST__g__152;
typedef __PST__g__114 *__PST__g__153;
typedef volatile __PST__g__69 __PST__g__154;
typedef __PST__g__154 *__PST__g__155;
typedef volatile __PST__g__105 __PST__g__156;
typedef __PST__g__156 *__PST__g__157;
typedef volatile __PST__g__81 __PST__g__158;
typedef __PST__g__158 *__PST__g__159;
typedef const __PST__g__19 __PST__g__160;
typedef __PST__g__160 *__PST__g__161;
typedef const __PST__g__32 __PST__g__162;
typedef __PST__g__162 *__PST__g__163;
typedef __PST__VOID __PST__g__164(__PST__UINT32, __PST__UINT32, __PST__UINT8, __PST__UINT8);
typedef __PST__g__164 *__PST__g__165;
typedef __PST__g__124 *__PST__g__166;
typedef __PST__g__121 *__PST__g__167;
typedef __PST__g__122 *__PST__g__168;
typedef __PST__g__117 *__PST__g__169;
typedef __PST__g__113 *__PST__g__170;
typedef volatile union __PST__g__74 __PST__g__171;
typedef __PST__g__171 *__PST__g__172;
typedef __PST__UINT32 __PST__g__173(__PST__g__134);
typedef __PST__g__173 *__PST__g__174;
typedef volatile __PST__g__107 __PST__g__175;
typedef __PST__g__175 *__PST__g__176;
typedef volatile __PST__g__71 __PST__g__179;
typedef __PST__g__179 *__PST__g__180;
typedef __PST__g__116 *__PST__g__181;
typedef __PST__g__123 *__PST__g__182;
typedef volatile struct __PST__g__75 __PST__g__183;
typedef __PST__g__183 *__PST__g__184;
typedef __PST__g__125 *__PST__g__187;
typedef volatile __PST__SINT32 __PST__g__188;
typedef __PST__SINT8 __PST__g__194(void);
typedef volatile __PST__SINT8 __PST__g__195;
typedef volatile __PST__UINT8 __PST__g__196;
typedef __PST__SINT32 __PST__g__197(void);
typedef __PST__UINT32 __PST__g__198(void);
typedef __PST__FLOAT64 __PST__g__199(void);
typedef volatile __PST__FLOAT64 __PST__g__200;
typedef __PST__SINT32 __PST__g__201(void);
