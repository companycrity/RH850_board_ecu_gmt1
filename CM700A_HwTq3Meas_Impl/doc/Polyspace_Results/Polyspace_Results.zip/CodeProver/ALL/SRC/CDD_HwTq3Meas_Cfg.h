
#ifndef CDD_HWTQ3MEAS_CFG_H     /* Multiple include preventer */
#define CDD_HWTQ3MEAS_CFG_H

#include "Rte_CDD_HwTq3Meas.h"

#define HWTQ3MEAS_HWTQ3MFGNTCNR_ULS_U16                 NTCNR_0X1E3
#define HWTQ3MEAS_HWTQ3PRTCLNTCNR_ULS_U16               NTCNR_0X079


#endif
