
#ifndef FLTINJ_H
#define FLTINJ_H

/* Fault Injection Command */
#define FLTINJ_TQOSCN_PREFINALCMD       (43U)

#endif
