/**********************************************************************************************************************
* Copyright 2015 Nexteer 
* Nexteer Confidential
*
* Module File Name  : NxtrFixdPt.h
* Module Description: Nexteer Fixed Point Library Header
* Project           : CBD
* Author            : Selva Sengottaiyan
***********************************************************************************************************************
* Version Control:
* %version:          %
* %derived_by:       %
*----------------------------------------------------------------------------------------------------------------------
* Date      Rev      Author         Change Description                                                           SCR #
* -------   -------  --------  ---------------------------------------------------------------------------     --------
* 02/13/15  1.0      Selva         Initial EA4 version
**********************************************************************************************************************/

/******************************************* Multiple Include Protection *********************************************/
#ifndef NXTRFIXDPT_H
#define NXTRFIXDPT_H

/************************************************ Include Statements *************************************************/
#include "Std_Types.h"

/******************************************** File Level Rule Deviations *********************************************/
/* MISRA-C:2004 Rule 1.1 [NXTRDEV 1.1.1]: Inline functions are used for Nexteer library macros to allow for throughput optimization */
/* MISRA-C:2004 Rule 8.5 [NXTRDEV 8.5.1]: Function definitions are required to be in a header for inline function usage */

/*********************************************** Exported Declarations ***********************************************/


INLINE FUNC(sint16, NxtrFixdPt_CODE) FloatToFixdWithRound_s16_f32(float32 Inp, float32 Mplr);
INLINE FUNC(sint32, NxtrFixdPt_CODE) FloatToFixdWithRound_s32_f32(float32 Inp, float32 Mplr);
INLINE FUNC(uint16, NxtrFixdPt_CODE) FloatToFixdWithRound_u16_f32(float32 Inp, float32 Mplr);
INLINE FUNC(uint32, NxtrFixdPt_CODE) FloatToFixdWithRound_u32_f32(float32 Inp, float32 Mplr);

INLINE FUNC(sint16, NxtrFixdPt_CODE) FloatToFixd_s16_f32(float32 Inp, float32 Mplr);
INLINE FUNC(sint32, NxtrFixdPt_CODE) FloatToFixd_s32_f32(float32 Inp, float32 Mplr);
INLINE FUNC(uint16, NxtrFixdPt_CODE) FloatToFixd_u16_f32(float32 Inp, float32 Mplr);
INLINE FUNC(uint32, NxtrFixdPt_CODE) FloatToFixd_u32_f32(float32 Inp, float32 Mplr);

INLINE FUNC(float32, NxtrFixdPt_CODE) FixdToFloat_f32_s16(sint16 Inp, float32 Mplr);
INLINE FUNC(float32, NxtrFixdPt_CODE) FixdToFloat_f32_s32(sint32 Inp, float32 Mplr);
INLINE FUNC(float32, NxtrFixdPt_CODE) FixdToFloat_f32_u16(uint16 Inp, float32 Mplr);
INLINE FUNC(float32, NxtrFixdPt_CODE) FixdToFloat_f32_u32(uint32 Inp, float32 Mplr);

/****************************************************** Macros *******************************************************/
#define NXTRFIXDPT_TOFLOATP0_ULS_F32  1.0F
#define NXTRFIXDPT_TOFIXDP0_ULS_F32  1.0F


#define NXTRFIXDPT_TOFLOATP1_ULS_F32  0.5F
#define NXTRFIXDPT_TOFIXDP1_ULS_F32  2.0F


#define NXTRFIXDPT_TOFLOATP2_ULS_F32  0.25F
#define NXTRFIXDPT_TOFIXDP2_ULS_F32  4.0F


#define NXTRFIXDPT_TOFLOATP3_ULS_F32  0.125F
#define NXTRFIXDPT_TOFIXDP3_ULS_F32  8.0F


#define NXTRFIXDPT_TOFLOATP4_ULS_F32  0.0625F
#define NXTRFIXDPT_TOFIXDP4_ULS_F32  16.0F


#define NXTRFIXDPT_TOFLOATP5_ULS_F32  0.03125F
#define NXTRFIXDPT_TOFIXDP5_ULS_F32  32.0F


#define NXTRFIXDPT_TOFLOATP6_ULS_F32  0.015625F
#define NXTRFIXDPT_TOFIXDP6_ULS_F32  64.0F


#define NXTRFIXDPT_TOFLOATP7_ULS_F32  0.0078125F
#define NXTRFIXDPT_TOFIXDP7_ULS_F32  128.0F


#define NXTRFIXDPT_TOFLOATP8_ULS_F32  0.00390625F
#define NXTRFIXDPT_TOFIXDP8_ULS_F32  256.0F


#define NXTRFIXDPT_TOFLOATP9_ULS_F32  0.001953125F
#define NXTRFIXDPT_TOFIXDP9_ULS_F32  512.0F


#define NXTRFIXDPT_TOFLOATP10_ULS_F32  0.0009765625F
#define NXTRFIXDPT_TOFIXDP10_ULS_F32  1024.0F


#define NXTRFIXDPT_TOFLOATP11_ULS_F32  0.00048828125F
#define NXTRFIXDPT_TOFIXDP11_ULS_F32  2048.0F


#define NXTRFIXDPT_TOFLOATP12_ULS_F32  0.000244140625F
#define NXTRFIXDPT_TOFIXDP12_ULS_F32  4096.0F


#define NXTRFIXDPT_TOFLOATP13_ULS_F32  0.0001220703125F
#define NXTRFIXDPT_TOFIXDP13_ULS_F32  8192.0F


#define NXTRFIXDPT_TOFLOATP14_ULS_F32  6.103515625e-05F
#define NXTRFIXDPT_TOFIXDP14_ULS_F32  16384.0F


#define NXTRFIXDPT_TOFLOATP15_ULS_F32  3.0517578125e-05F
#define NXTRFIXDPT_TOFIXDP15_ULS_F32  32768.0F


#define NXTRFIXDPT_TOFLOATP16_ULS_F32  1.52587890625e-05F
#define NXTRFIXDPT_TOFIXDP16_ULS_F32  65536.0F


#define NXTRFIXDPT_TOFLOATP17_ULS_F32  7.62939453125e-06F
#define NXTRFIXDPT_TOFIXDP17_ULS_F32  131072.0F


#define NXTRFIXDPT_TOFLOATP18_ULS_F32  3.81469726562e-06F
#define NXTRFIXDPT_TOFIXDP18_ULS_F32  262144.0F


#define NXTRFIXDPT_TOFLOATP19_ULS_F32  1.90734863281e-06F
#define NXTRFIXDPT_TOFIXDP19_ULS_F32  524288.0F


#define NXTRFIXDPT_TOFLOATP20_ULS_F32  9.53674316406e-07F
#define NXTRFIXDPT_TOFIXDP20_ULS_F32  1048576.0F


#define NXTRFIXDPT_TOFLOATP21_ULS_F32  4.76837158203e-07F
#define NXTRFIXDPT_TOFIXDP21_ULS_F32  2097152.0F


#define NXTRFIXDPT_TOFLOATP22_ULS_F32  2.38418579102e-07F
#define NXTRFIXDPT_TOFIXDP22_ULS_F32  4194304.0F


#define NXTRFIXDPT_TOFLOATP23_ULS_F32  1.19209289551e-07F
#define NXTRFIXDPT_TOFIXDP23_ULS_F32  8388608.0F


#define NXTRFIXDPT_TOFLOATP24_ULS_F32  5.96046447754e-08F
#define NXTRFIXDPT_TOFIXDP24_ULS_F32  16777216.0F


#define NXTRFIXDPT_TOFLOATP25_ULS_F32  2.98023223877e-08F
#define NXTRFIXDPT_TOFIXDP25_ULS_F32  33554432.0F


#define NXTRFIXDPT_TOFLOATP26_ULS_F32  1.49011611938e-08F
#define NXTRFIXDPT_TOFIXDP26_ULS_F32  67108864.0F


#define NXTRFIXDPT_TOFLOATP27_ULS_F32  7.45058059692e-09F
#define NXTRFIXDPT_TOFIXDP27_ULS_F32  134217728.0F


#define NXTRFIXDPT_TOFLOATP28_ULS_F32  3.72529029846e-09F
#define NXTRFIXDPT_TOFIXDP28_ULS_F32  268435456.0F


#define NXTRFIXDPT_TOFLOATP29_ULS_F32  1.86264514923e-09F
#define NXTRFIXDPT_TOFIXDP29_ULS_F32  536870912.0F


#define NXTRFIXDPT_TOFLOATP30_ULS_F32  9.31322574615e-10F
#define NXTRFIXDPT_TOFIXDP30_ULS_F32  1073741824.0F


#define NXTRFIXDPT_TOFLOATP31_ULS_F32  4.65661287308e-10F
#define NXTRFIXDPT_TOFIXDP31_ULS_F32  2147483648.0F


#define NXTRFIXDPT_TOFLOATP32_ULS_F32  2.32830643654e-10F
#define NXTRFIXDPT_TOFIXDP32_ULS_F32  4294967296.0F



/********************** Inline functions******************************/

/*****************************************************************************
*  Name:        FloatToFixdWithRound_s16_f32  
*  Description: Converts the float to fixed point and rounds to the nearest integer
*  Inputs:      Single precision float and the multiplication factor derived from the Corresponding Macro   
*  Outputs:     16 bit signed number.         
*  Usage Notes: Macro NXTRFIXDPT_TOFIXDP'X'_ULS_F32 shall be used where X is the precision of signed 16 bit output. 
                 usage:  -327678 < inp1* Mplr < 32767
*****************************************************************************/
INLINE FUNC(sint16, NxtrFixdPt_CODE) FloatToFixdWithRound_s16_f32(float32 Inp, float32 Mplr)
{
  return ( ((Inp < 0.0F) ? ((sint16)(sint32)(float32)((Inp * Mplr) - 0.5F)): ((sint16)(sint32)(float32)((Inp * Mplr) + 0.5F))));
}


/*****************************************************************************
*  Name:         FloatToFixdWithRound_s32_f32  
*  Description:  Converts the float to fixed point and rounds to the nearest integer
*  Inputs:       Single precision float and the multiplication factor derived from the Corresponding Macro   
*  Outputs:      32 bit signed number.        
*  Usage Notes:  Macro NXTRFIXDPT_TOFIXDP'X'_ULS_F32 shall be used where X is the precision of signed 32 bit output 
                 and  -(2^31)<inp1* Mplr <(2^31)
*****************************************************************************/
INLINE FUNC(sint32, NxtrFixdPt_CODE) FloatToFixdWithRound_s32_f32(float32 Inp, float32 Mplr)
{
  return ( ((Inp < 0.0F) ? ((sint32)(float32)((Inp * Mplr) - 0.5F)): ((sint32)(float32)((Inp * Mplr) + 0.5F))));
}


/*****************************************************************************
*  Name:         FloatToFixdWithRound_u16_f32  
*  Description:  Converts the float to fixed point and rounds to the nearest integer
*  Inputs:       Single precision float and the multiplication factor derived from the Corresponding Macro    
*  Outputs:      16 bit unsigned number.         
*  Usage Notes:  Macro NXTRFIXDPT_TOFIXDP'X'_ULS_F32 shall be used where X is the precision of unsigned 16 bit output.
                 inp1* Mplr < (2^16)-1
*****************************************************************************/
INLINE FUNC(uint16, NxtrFixdPt_CODE) FloatToFixdWithRound_u16_f32(float32 Inp, float32 Mplr)
{
  return ((uint16)(uint32)(float32)((Inp * Mplr) + 0.5F));
}


/*****************************************************************************
*  Name:          FloatToFixdWithRound_u32_f32  
*  Description:   Converts the float to fixed point and rounds to the nearest integer
*  Inputs:        Single precision float and the multiplication factor derived from the Corresponding Macro    
*  Outputs:       32 bit unsigned number.         
*  Usage Notes:   Macro NXTRFIXDPT_TOFIXEDP'X'_ULS_F32 shall be used where X is the precision of unsigned 32 bit output 
                   and must satisfy   inp1* Mplr < (2^32)-1
*****************************************************************************/
INLINE FUNC(uint32, NxtrFixdPt_CODE) FloatToFixdWithRound_u32_f32(float32 Inp, float32 Mplr)
{
  return ((uint32)(float32)((Inp * Mplr) + 0.5F));
}



/*****************************************************************************
*  Name:         FloatToFixd_s16_f32  
*  Description:  Converts the float to corresponding Fixed point.
*  Inputs:       Single precision float and the multiplication factor derived from the Corresponding Macro .                    
*  Outputs:      16 bit signed number.         
*  Usage Notes:  Macro NXTRFIXDPT_TOFIXEDP'X'_ULS_F32 shall be used where X is the precision of signed 16 bit output.
                 and must satisfy  -(2^15)<= inp1* Mplr <= (2^15)-1
*****************************************************************************/
INLINE FUNC(sint16, NxtrFixdPt_CODE) FloatToFixd_s16_f32(float32 Inp, float32 Mplr)
{
  return ((sint16)(sint32)(float32)(Inp * Mplr));
}


/*****************************************************************************
*  Name:         FloatToFixd_s32_f32  
*  Description:  Converts the float to corresponding Fixed point.
*  Inputs:       Single precision float and the multiplication factor derived from the Corresponding Macro .                    
*  Outputs:      32 bit signed number.         
*  Usage Notes:  Macro NXTRFIXDPT_TOFIXEDP'X'_ULS_F32 shall be used where X is the precision of signed 32 bit output
                 and must satisfy   -(2^31) <=inp1 <= (2^31)-1
*****************************************************************************/
INLINE FUNC(sint32, NxtrFixdPt_CODE) FloatToFixd_s32_f32(float32 Inp, float32 Mplr)
{
  return ((sint32)(float32)(Inp * Mplr));
}


/*****************************************************************************
*  Name:         FloatToFixd_u16_f32  
*  Description:  Converts the float to corresponding Fixed point.
*  Inputs:       Single precision float and the multiplication factor derived from the Corresponding Macro .                    
*  Outputs:      16 bit unsigned number.         
*  Usage Notes:  Macro NXTRFIXDPT_TOFIXEDP'X'_ULS_F32 shall be used where X is the precision of unsigned 16 bit output
                 and must satisfy inp1* Mplr <= (2^16)-1
*****************************************************************************/
INLINE FUNC(uint16, NxtrFixdPt_CODE) FloatToFixd_u16_f32(float32 Inp, float32 Mplr)
{
  return ((uint16)(uint32)(float32)(Inp * Mplr));
}


/*****************************************************************************
*  Name:         FloatToFixd_u32_f32  
*  Description:  Converts the float to corresponding Fixed point.
*  Inputs:       Single precision float and the multiplication factor derived from the Corresponding Macro .                    
*  Outputs:      32 bit unsigned number.         
*  Usage Notes:  Macro NXTRFIXDPT_TOFIXEDP'X'_ULS_F32 shall be used where X is the precision of unsigned 32 bit output.
                  and must satisfy  inp1* Mplr < (2^32)-1
*****************************************************************************/
INLINE FUNC(uint32, NxtrFixdPt_CODE) FloatToFixd_u32_f32(float32 Inp, float32 Mplr)
{
  return ((uint32)(float32)((Inp * Mplr) ));
}


/*****************************************************************************
*  Name:           FixdToFloat_f32_s16        
*  Description:    Converts the Fixed point signed 16 bit to single precision float.
*  Inputs:         16 bit signed integer and the multiplication factor derived from the Corresponding Macro .  
*  Outputs:        Single Precision Float        
*  Usage Notes:    Macro "NXTRFIXDPT_TOFLOATP'X'_ULS_F32" shall be used where X is the precision of signed 16 bit input
                   and must satisfy -(2^15) <= Inp <= (2^15) 
*****************************************************************************/
INLINE FUNC(float32, NxtrFixdPt_CODE) FixdToFloat_f32_s16(sint16 Inp, float32 Mplr)
{
  return ((float32)((float32)Inp * Mplr));
}


/*****************************************************************************
*  Name:           FixdToFloat_f32_s32        
*  Description:    Converts the Fixed point signed 32 bit to single precision float.
*  Inputs:         32 bit signed integer and the multiplication factor derived from the Corresponding Macro .  
*  Outputs:        Single Precision Float        
*  Usage Notes:    Macro "NXTRFIXDPT_TOFLOATP'X'_ULS_F32" shall be used where X is the precision of signed 32 bit input
*                   and must satisfy -(2^31) <= Inp <= (2^31)   
*****************************************************************************/
INLINE FUNC(float32, NxtrFixdPt_CODE) FixdToFloat_f32_s32(sint32 Inp, float32 Mplr)
{
  return ((float32)((float32)Inp * Mplr));
}


/*****************************************************************************
*  Name:           FixdToFloat_f32_u16        
*  Description:    Converts the Fixed point unsigned 16 bit to single precision float.
*  Inputs:         16 bit unsigned integer and the multiplication factor derived from the Corresponding Macro .  
*  Outputs:        Single Precision Float        
*  Usage Notes:    Macro "NXTRFIXDPT_TOFLOATP'X'_ULS_F32" shall be used where X is the precision of unsigned 16 bit input
                   and must satisfy Inp <= (2^16)-1
*****************************************************************************/
INLINE FUNC(float32, NxtrFixdPt_CODE) FixdToFloat_f32_u16(uint16 Inp, float32 Mplr)
{
  return ((float32)((float32)Inp * Mplr));
}


/*****************************************************************************
*  Name:           FixdToFloat_f32_u32       
*  Description:    Converts the Fixed point unsigned 32 bit to single precision float.
*  Inputs:         32 bit unsigned integer and the multiplication factor derived from the Corresponding Macro .  
*  Outputs:        Single Precision Float        
*  Usage Notes:    Macro "NXTRFIXDPT_TOFLOATP'X'_ULS_F32" shall be used where X is the precision of unsigned 32 bit input
                                        and must satisfy Inp <= (2^32)-1
*****************************************************************************/
INLINE FUNC(float32, NxtrFixdPt_CODE) FixdToFloat_f32_u32(uint32 Inp, float32 Mplr)
{
  return ((float32)((float32)Inp * Mplr));
}

/******************************************/
#endif
