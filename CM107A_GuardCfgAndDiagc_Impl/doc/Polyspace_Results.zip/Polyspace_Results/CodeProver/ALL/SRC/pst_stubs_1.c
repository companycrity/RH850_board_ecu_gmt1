#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__883 _main_gen_init_g883(void);

extern union __PST__g__882 _main_gen_init_g882(void);

extern struct __PST__g__881 _main_gen_init_g881(void);

extern union __PST__g__880 _main_gen_init_g880(void);

extern __PST__g__878 _main_gen_init_g878(void);

extern __PST__g__868 _main_gen_init_g868(void);

extern union __PST__g__827 _main_gen_init_g827(void);

extern __PST__g__613 _main_gen_init_g613(void);

extern __PST__g__611 _main_gen_init_g611(void);

extern __PST__g__609 _main_gen_init_g609(void);

extern __PST__g__607 _main_gen_init_g607(void);

extern __PST__g__591 _main_gen_init_g591(void);

extern union __PST__g__589 _main_gen_init_g589(void);

extern __PST__g__587 _main_gen_init_g587(void);

extern union __PST__g__580 _main_gen_init_g580(void);

extern __PST__g__578 _main_gen_init_g578(void);

extern union __PST__g__556 _main_gen_init_g556(void);

extern union __PST__g__553 _main_gen_init_g553(void);

extern union __PST__g__550 _main_gen_init_g550(void);

extern __PST__g__548 _main_gen_init_g548(void);

extern union __PST__g__538 _main_gen_init_g538(void);

extern union __PST__g__536 _main_gen_init_g536(void);

extern union __PST__g__533 _main_gen_init_g533(void);

extern union __PST__g__529 _main_gen_init_g529(void);

extern union __PST__g__526 _main_gen_init_g526(void);

extern __PST__g__524 _main_gen_init_g524(void);

extern union __PST__g__522 _main_gen_init_g522(void);

extern union __PST__g__520 _main_gen_init_g520(void);

extern union __PST__g__518 _main_gen_init_g518(void);

extern union __PST__g__516 _main_gen_init_g516(void);

extern union __PST__g__513 _main_gen_init_g513(void);

extern __PST__g__506 _main_gen_init_g506(void);

extern union __PST__g__483 _main_gen_init_g483(void);

extern union __PST__g__473 _main_gen_init_g473(void);

extern __PST__g__446 _main_gen_init_g446(void);

extern union __PST__g__263 _main_gen_init_g263(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern union __PST__g__112 _main_gen_init_g112(void);

extern __PST__g__98 _main_gen_init_g98(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern union __PST__g__74 _main_gen_init_g74(void);

extern union __PST__g__71 _main_gen_init_g71(void);

extern union __PST__g__67 _main_gen_init_g67(void);

extern union __PST__g__63 _main_gen_init_g63(void);

extern __PST__g__46 _main_gen_init_g46(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern union __PST__g__33 _main_gen_init_g33(void);

extern __PST__g__23 _main_gen_init_g23(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

union __PST__g__33 _main_gen_init_g33(void)
{
    static union __PST__g__33 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__23 _main_gen_init_g23(void)
{
    __PST__g__23 x;
    /* struct/union type */
    x.ESSTR0 = _main_gen_init_g33();
    return x;
}

union __PST__g__63 _main_gen_init_g63(void)
{
    static union __PST__g__63 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__67 _main_gen_init_g67(void)
{
    static union __PST__g__67 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__71 _main_gen_init_g71(void)
{
    static union __PST__g__71 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

union __PST__g__74 _main_gen_init_g74(void)
{
    static union __PST__g__74 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__46 _main_gen_init_g46(void)
{
    __PST__g__46 x;
    /* struct/union type */
    x.EMK0 = _main_gen_init_g63();
    x.ESSTC0 = _main_gen_init_g67();
    x.PCMD1 = _main_gen_init_g71();
    x.PS = _main_gen_init_g74();
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

union __PST__g__112 _main_gen_init_g112(void)
{
    static union __PST__g__112 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__263 _main_gen_init_g263(void)
{
    static union __PST__g__263 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__98 _main_gen_init_g98(void)
{
    __PST__g__98 x;
    /* struct/union type */
    x.PMC0 = _main_gen_init_g112();
    x.PCR0_0 = _main_gen_init_g263();
    return x;
}

union __PST__g__473 _main_gen_init_g473(void)
{
    static union __PST__g__473 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__483 _main_gen_init_g483(void)
{
    static union __PST__g__483 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__446 _main_gen_init_g446(void)
{
    __PST__g__446 x;
    /* struct/union type */
    x.JPCR0_0 = _main_gen_init_g473();
    x.JPIBC0 = _main_gen_init_g483();
    return x;
}

union __PST__g__513 _main_gen_init_g513(void)
{
    static union __PST__g__513 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__516 _main_gen_init_g516(void)
{
    static union __PST__g__516 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__518 _main_gen_init_g518(void)
{
    static union __PST__g__518 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__520 _main_gen_init_g520(void)
{
    static union __PST__g__520 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__522 _main_gen_init_g522(void)
{
    static union __PST__g__522 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__506 _main_gen_init_g506(void)
{
    __PST__g__506 x;
    /* struct/union type */
    x.ENUM = _main_gen_init_g513();
    x.PMTUM0 = _main_gen_init_g516();
    x.PMTUM2 = _main_gen_init_g518();
    x.PMTUM3 = _main_gen_init_g520();
    x.PMTUM4 = _main_gen_init_g522();
    return x;
}

union __PST__g__526 _main_gen_init_g526(void)
{
    static union __PST__g__526 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__529 _main_gen_init_g529(void)
{
    static union __PST__g__529 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__533 _main_gen_init_g533(void)
{
    static union __PST__g__533 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__536 _main_gen_init_g536(void)
{
    static union __PST__g__536 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__538 _main_gen_init_g538(void)
{
    static union __PST__g__538 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__524 _main_gen_init_g524(void)
{
    __PST__g__524 x;
    /* struct/union type */
    x.SP = _main_gen_init_g526();
    x.G0MK = _main_gen_init_g529();
    x.G0BA = _main_gen_init_g533();
    x.G1MK = _main_gen_init_g536();
    x.G1BA = _main_gen_init_g538();
    return x;
}

union __PST__g__550 _main_gen_init_g550(void)
{
    static union __PST__g__550 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__553 _main_gen_init_g553(void)
{
    static union __PST__g__553 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__556 _main_gen_init_g556(void)
{
    static union __PST__g__556 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__548 _main_gen_init_g548(void)
{
    __PST__g__548 x;
    /* struct/union type */
    x.FSGD3ADPROT0 = _main_gen_init_g550();
    x.FSGD3ADPROT1 = _main_gen_init_g550();
    x.FSGD3ADPROT2 = _main_gen_init_g550();
    x.FSGD3ADPROT3 = _main_gen_init_g550();
    x.FSGD3ADPROT4 = _main_gen_init_g550();
    x.FSGD3ADPROT5 = _main_gen_init_g550();
    x.FSGD3ADPROT6 = _main_gen_init_g550();
    x.FSGD3ADPROT7 = _main_gen_init_g550();
    x.FSGD3ADPROT8 = _main_gen_init_g550();
    x.FSGD3ADPROT9 = _main_gen_init_g550();
    x.FSGD3ADPROT10 = _main_gen_init_g550();
    x.FSGD3ADPROT11 = _main_gen_init_g550();
    x.ERRSLV3ACTL = _main_gen_init_g553();
    x.ERRSLV3ASTAT = _main_gen_init_g556();
    x.FSGD0ADPROT0 = _main_gen_init_g550();
    x.FSGD0ADPROT1 = _main_gen_init_g550();
    x.FSGD1ADPROT0 = _main_gen_init_g550();
    x.FSGD1ADPROT1 = _main_gen_init_g550();
    x.FSGD1ADPROT2 = _main_gen_init_g550();
    x.FSGD1ADPROT3 = _main_gen_init_g550();
    x.FSGD1ADPROT4 = _main_gen_init_g550();
    x.FSGD1ADPROT5 = _main_gen_init_g550();
    x.FSGD1ADPROT6 = _main_gen_init_g550();
    x.FSGD1ADPROT7 = _main_gen_init_g550();
    x.FSGD1ADPROT8 = _main_gen_init_g550();
    x.FSGD1ADPROT9 = _main_gen_init_g550();
    x.FSGD1ADPROT10 = _main_gen_init_g550();
    x.FSGD1ADPROT11 = _main_gen_init_g550();
    x.FSGD1ADPROT12 = _main_gen_init_g550();
    x.FSGD1ADPROT13 = _main_gen_init_g550();
    x.FSGD1ADPROT14 = _main_gen_init_g550();
    x.FSGD1BDPROT0 = _main_gen_init_g550();
    x.FSGD1BDPROT1 = _main_gen_init_g550();
    x.FSGD1BDPROT2 = _main_gen_init_g550();
    x.FSGD1BDPROT3 = _main_gen_init_g550();
    x.FSGD1BDPROT4 = _main_gen_init_g550();
    x.FSGD1BDPROT5 = _main_gen_init_g550();
    x.FSGD1BDPROT6 = _main_gen_init_g550();
    x.FSGD1BDPROT7 = _main_gen_init_g550();
    x.FSGD1BDPROT8 = _main_gen_init_g550();
    x.FSGD1BDPROT9 = _main_gen_init_g550();
    x.FSGD1BDPROT10 = _main_gen_init_g550();
    x.FSGD1BDPROT11 = _main_gen_init_g550();
    x.FSGD1BDPROT12 = _main_gen_init_g550();
    x.FSGD1BDPROT13 = _main_gen_init_g550();
    x.FSGD1BDPROT14 = _main_gen_init_g550();
    x.FSGD5ADPROT0 = _main_gen_init_g550();
    x.FSGD2ADPROT0 = _main_gen_init_g550();
    x.FSGD2ADPROT1 = _main_gen_init_g550();
    x.FSGD2ADPROT2 = _main_gen_init_g550();
    x.FSGD2ADPROT3 = _main_gen_init_g550();
    x.FSGD2ADPROT4 = _main_gen_init_g550();
    x.FSGD2ADPROT5 = _main_gen_init_g550();
    x.FSGD2ADPROT6 = _main_gen_init_g550();
    x.FSGD2ADPROT7 = _main_gen_init_g550();
    x.FSGD2ADPROT8 = _main_gen_init_g550();
    x.FSGD2ADPROT9 = _main_gen_init_g550();
    x.FSGD2ADPROT10 = _main_gen_init_g550();
    x.FSGD2ADPROT11 = _main_gen_init_g550();
    x.FSGD2ADPROT12 = _main_gen_init_g550();
    x.FSGD2ADPROT13 = _main_gen_init_g550();
    x.FSGD2ADPROT14 = _main_gen_init_g550();
    x.FSGD2ADPROT15 = _main_gen_init_g550();
    return x;
}

union __PST__g__580 _main_gen_init_g580(void)
{
    static union __PST__g__580 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__578 _main_gen_init_g578(void)
{
    __PST__g__578 x;
    /* struct/union type */
    x.CTL = _main_gen_init_g580();
    return x;
}

union __PST__g__589 _main_gen_init_g589(void)
{
    static union __PST__g__589 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__587 _main_gen_init_g587(void)
{
    __PST__g__587 x;
    /* struct/union type */
    x.CTL0 = _main_gen_init_g589();
    return x;
}

__PST__g__591 _main_gen_init_g591(void)
{
    __PST__g__591 x;
    /* struct/union type */
    x.CTL0 = _main_gen_init_g589();
    return x;
}

__PST__g__607 _main_gen_init_g607(void)
{
    __PST__g__607 x;
    /* struct/union type */
    x.CTL0 = _main_gen_init_g589();
    return x;
}

__PST__g__609 _main_gen_init_g609(void)
{
    __PST__g__609 x;
    /* struct/union type */
    x.CTL0 = _main_gen_init_g589();
    return x;
}

__PST__g__611 _main_gen_init_g611(void)
{
    __PST__g__611 x;
    /* struct/union type */
    x.CTL0 = _main_gen_init_g589();
    return x;
}

union __PST__g__827 _main_gen_init_g827(void)
{
    static union __PST__g__827 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__613 _main_gen_init_g613(void)
{
    __PST__g__613 x;
    /* struct/union type */
    x.THACR = _main_gen_init_g827();
    return x;
}

__PST__g__868 _main_gen_init_g868(void)
{
    __PST__g__868 x;
    /* struct/union type */
    x.THACR = _main_gen_init_g827();
    return x;
}

struct __PST__g__881 _main_gen_init_g881(void)
{
    static struct __PST__g__881 x;
    /* struct/union type */
    {
        __PST__UINT16 bitf;
        bitf = _main_gen_init_g7();
        unchecked_assert(bitf <= 1);
        x.VCIE = bitf;
    }
    {
        __PST__UINT16 bitf;
        bitf = _main_gen_init_g7();
        unchecked_assert(bitf <= 1);
        x.VPGE = bitf;
    }
    return x;
}

union __PST__g__880 _main_gen_init_g880(void)
{
    static union __PST__g__880 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g881();
    x.UINT16 = _main_gen_init_g7();
    return x;
}

struct __PST__g__883 _main_gen_init_g883(void)
{
    static struct __PST__g__883 x;
    /* struct/union type */
    {
        __PST__UINT16 bitf;
        bitf = _main_gen_init_g7();
        unchecked_assert(bitf <= 1);
        x.VCIF = bitf;
    }
    {
        __PST__UINT16 bitf;
        bitf = _main_gen_init_g7();
        unchecked_assert(bitf <= 1);
        x.VPGF = bitf;
    }
    return x;
}

union __PST__g__882 _main_gen_init_g882(void)
{
    static union __PST__g__882 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g883();
    return x;
}

__PST__g__878 _main_gen_init_g878(void)
{
    __PST__g__878 x;
    /* struct/union type */
    x.CONT = _main_gen_init_g880();
    x.FLAG = _main_gen_init_g882();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_ECMM(void)
{
    extern __PST__g__23 ECMM;
    
    /* initialization with random value */
    {
        ECMM = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_ECM(void)
{
    extern __PST__g__46 ECM;
    
    /* initialization with random value */
    {
        ECM = _main_gen_init_g46();
    }
}

static void _main_gen_init_sym_PORT(void)
{
    extern __PST__g__98 PORT;
    
    /* initialization with random value */
    {
        PORT = _main_gen_init_g98();
    }
}

static void _main_gen_init_sym_PORTJ(void)
{
    extern __PST__g__446 PORTJ;
    
    /* initialization with random value */
    {
        PORTJ = _main_gen_init_g446();
    }
}

static void _main_gen_init_sym_IPG(void)
{
    extern __PST__g__506 IPG;
    
    /* initialization with random value */
    {
        IPG = _main_gen_init_g506();
    }
}

static void _main_gen_init_sym_PEG(void)
{
    extern __PST__g__524 PEG;
    
    /* initialization with random value */
    {
        PEG = _main_gen_init_g524();
    }
}

static void _main_gen_init_sym_PBG(void)
{
    extern __PST__g__548 PBG;
    
    /* initialization with random value */
    {
        PBG = _main_gen_init_g548();
    }
}

static void _main_gen_init_sym_DNFA0(void)
{
    extern __PST__g__578 DNFA0;
    
    /* initialization with random value */
    {
        DNFA0 = _main_gen_init_g578();
    }
}

static void _main_gen_init_sym_FCLA0(void)
{
    extern __PST__g__587 FCLA0;
    
    /* initialization with random value */
    {
        FCLA0 = _main_gen_init_g587();
    }
}

static void _main_gen_init_sym_FCLA1(void)
{
    extern __PST__g__591 FCLA1;
    
    /* initialization with random value */
    {
        FCLA1 = _main_gen_init_g591();
    }
}

static void _main_gen_init_sym_FCLA2(void)
{
    extern __PST__g__607 FCLA2;
    
    /* initialization with random value */
    {
        FCLA2 = _main_gen_init_g607();
    }
}

static void _main_gen_init_sym_FCLA3(void)
{
    extern __PST__g__609 FCLA3;
    
    /* initialization with random value */
    {
        FCLA3 = _main_gen_init_g609();
    }
}

static void _main_gen_init_sym_FCLA4(void)
{
    extern __PST__g__611 FCLA4;
    
    /* initialization with random value */
    {
        FCLA4 = _main_gen_init_g611();
    }
}

static void _main_gen_init_sym_ADCD0(void)
{
    extern __PST__g__613 ADCD0;
    
    /* initialization with random value */
    {
        ADCD0 = _main_gen_init_g613();
    }
}

static void _main_gen_init_sym_ADCD1(void)
{
    extern __PST__g__868 ADCD1;
    
    /* initialization with random value */
    {
        ADCD1 = _main_gen_init_g868();
    }
}

static void _main_gen_init_sym_SEG(void)
{
    extern __PST__g__878 SEG;
    
    /* initialization with random value */
    {
        SEG = _main_gen_init_g878();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable ECMM */
    _main_gen_init_sym_ECMM();
    
    /* init for variable ECM */
    _main_gen_init_sym_ECM();
    
    /* init for variable PORT */
    _main_gen_init_sym_PORT();
    
    /* init for variable PORTJ */
    _main_gen_init_sym_PORTJ();
    
    /* init for variable IPG */
    _main_gen_init_sym_IPG();
    
    /* init for variable PEG */
    _main_gen_init_sym_PEG();
    
    /* init for variable PBG */
    _main_gen_init_sym_PBG();
    
    /* init for variable DNFA0 */
    _main_gen_init_sym_DNFA0();
    
    /* init for variable FCLA0 */
    _main_gen_init_sym_FCLA0();
    
    /* init for variable FCLA1 */
    _main_gen_init_sym_FCLA1();
    
    /* init for variable FCLA2 */
    _main_gen_init_sym_FCLA2();
    
    /* init for variable FCLA3 */
    _main_gen_init_sym_FCLA3();
    
    /* init for variable FCLA4 */
    _main_gen_init_sym_FCLA4();
    
    /* init for variable ADCD0 */
    _main_gen_init_sym_ADCD0();
    
    /* init for variable ADCD1 */
    _main_gen_init_sym_ADCD1();
    
    /* init for variable SEG */
    _main_gen_init_sym_SEG();
    
}
