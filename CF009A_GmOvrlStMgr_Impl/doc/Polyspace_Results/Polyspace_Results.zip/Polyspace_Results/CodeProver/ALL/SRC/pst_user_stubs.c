/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function expf
//
// #pragma POLYSPACE_PURE "expf"
// #pragma POLYSPACE_CLEAN "expf"
// #pragma POLYSPACE_WORST "expf"
//
// __PST__FLOAT32 expf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function fabsf
//
// #pragma POLYSPACE_PURE "fabsf"
// #pragma POLYSPACE_CLEAN "fabsf"
// #pragma POLYSPACE_WORST "fabsf"
//
// __PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_AbsActvProtd_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_AbsActvProtd_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_AbsActvProtd_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_AbsActvProtd_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_AbsActvProtd_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_ApaEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_ApaEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_ApaEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_ApaEna_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_ApaEna_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_EscEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_EscEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_EscEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_EscEna_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_EscEna_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_EscLimdActv_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_EscLimdActv_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_EscLimdActv_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_EscLimdActv_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_EscLimdActv_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_HwAgEotCcw_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_HwAgEotCcw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_HwAgEotCcw_Val"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_HwAgEotCcw_Val"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_HwAgEotCcw_Val(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_HwAgEotCw_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_HwAgEotCw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_HwAgEotCw_Val"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_HwAgEotCw_Val"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_HwAgEotCw_Val(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_HwAgTar_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_HwAgTar_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_HwAgTar_Val"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_HwAgTar_Val"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_HwAgTar_Val(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_HwAgTraj_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_HwAgTraj_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_HwAgTraj_Val"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_HwAgTraj_Val"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_HwAgTraj_Val(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_HwAgTrajEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_HwAgTrajEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_HwAgTrajEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_HwAgTrajEna_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_HwAgTrajEna_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_HwHaptcEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_HwHaptcEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_HwHaptcEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_HwHaptcEna_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_HwHaptcEna_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_HwTq_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_HwTq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_HwTq_Val"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_HwTq_Val"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_HwTq_Val(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_LkaEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_LkaEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_LkaEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_LkaEna_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_LkaEna_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_LkaTqCmdCdnd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_LkaTqCmdCdnd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_LkaTqCmdCdnd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_LkaTqCmdCdnd_Val"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_LkaTqCmdCdnd_Val(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_LoaSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_LoaSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_LoaSt_Val"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_LoaSt_Val"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_LoaSt_Val(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_MfgOvrlDi_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_MfgOvrlDi_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_MfgOvrlDi_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_MfgOvrlDi_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_MfgOvrlDi_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_Msg17DBusHiSpdInvld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_Msg17DBusHiSpdInvld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_Msg17DBusHiSpdInvld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_Msg17DBusHiSpdInvld_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_Msg17DBusHiSpdInvld_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_Msg17DBusHiSpdMiss_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_Msg17DBusHiSpdMiss_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_Msg17DBusHiSpdMiss_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_Msg17DBusHiSpdMiss_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_Msg17DBusHiSpdMiss_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_Msg180BusChassisExpInvld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_Msg180BusChassisExpInvld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_Msg180BusChassisExpInvld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_Msg180BusChassisExpInvld_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_Msg180BusChassisExpInvld_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_Msg180BusChassisExpMiss_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_Msg180BusChassisExpMiss_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_Msg180BusChassisExpMiss_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_Msg180BusChassisExpMiss_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_Msg180BusChassisExpMiss_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_Msg180BusHiSpdInvld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_Msg180BusHiSpdInvld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_Msg180BusHiSpdInvld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_Msg180BusHiSpdInvld_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_Msg180BusHiSpdInvld_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_Msg180BusHiSpdMiss_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_Msg180BusHiSpdMiss_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_Msg180BusHiSpdMiss_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_Msg180BusHiSpdMiss_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_Msg180BusHiSpdMiss_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_Msg1E9BusHiSpdInvld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_Msg1E9BusHiSpdInvld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_Msg1E9BusHiSpdInvld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_Msg1E9BusHiSpdInvld_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_Msg1E9BusHiSpdInvld_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_Msg1E9BusHiSpdMiss_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_Msg1E9BusHiSpdMiss_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_Msg1E9BusHiSpdMiss_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_Msg1E9BusHiSpdMiss_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_Msg1E9BusHiSpdMiss_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_Msg1F5BusHiSpdInvld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_Msg1F5BusHiSpdInvld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_Msg1F5BusHiSpdInvld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_Msg1F5BusHiSpdInvld_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_Msg1F5BusHiSpdInvld_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_Msg214BusHiSpdInvld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_Msg214BusHiSpdInvld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_Msg214BusHiSpdInvld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_Msg214BusHiSpdInvld_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_Msg214BusHiSpdInvld_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_Msg214BusHiSpdMiss_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_Msg214BusHiSpdMiss_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_Msg214BusHiSpdMiss_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_Msg214BusHiSpdMiss_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_Msg214BusHiSpdMiss_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_Msg337BusChassisExpInvld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_Msg337BusChassisExpInvld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_Msg337BusChassisExpInvld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_Msg337BusChassisExpInvld_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_Msg337BusChassisExpInvld_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_Msg337BusChassisExpMiss_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_Msg337BusChassisExpMiss_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_Msg337BusChassisExpMiss_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_Msg337BusChassisExpMiss_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_Msg337BusChassisExpMiss_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_ShiftLvrRvs_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_ShiftLvrRvs_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_ShiftLvrRvs_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_ShiftLvrRvs_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_ShiftLvrRvs_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_SysSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_SysSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_SysSt_Val"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_SysSt_Val"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_SysSt_Val(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_VehSpd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_VehSpd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_VehSpd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_VehSpd_Val"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_VehSpd_Val(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_VehSpdSecurMax_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_VehSpdSecurMax_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_VehSpdSecurMax_Val"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_VehSpdSecurMax_Val"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_VehSpdSecurMax_Val(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_VehSpdSecurMaxVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_VehSpdSecurMaxVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_VehSpdSecurMaxVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_VehSpdSecurMaxVld_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_VehSpdSecurMaxVld_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_VehSpdSecurMin_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_VehSpdSecurMin_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_VehSpdSecurMin_Val"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_VehSpdSecurMin_Val"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_VehSpdSecurMin_Val(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_VehSpdSecurMinVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_VehSpdSecurMinVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_VehSpdSecurMinVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_VehSpdSecurMinVld_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_VehSpdSecurMinVld_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmOvrlStMgr_VehStabyEnhmtActv_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmOvrlStMgr_VehStabyEnhmtActv_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmOvrlStMgr_VehStabyEnhmtActv_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmOvrlStMgr_VehStabyEnhmtActv_Logl"
//
// __PST__UINT8 Rte_Read_GmOvrlStMgr_VehStabyEnhmtActv_Logl(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_GmOvrlStMgr_ApaDrvrIntvDetd_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_GmOvrlStMgr_ApaDrvrIntvDetd_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_GmOvrlStMgr_ApaDrvrIntvDetd_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_GmOvrlStMgr_ApaDrvrIntvDetd_Logl"
//
// __PST__UINT8 Rte_Write_GmOvrlStMgr_ApaDrvrIntvDetd_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_GmOvrlStMgr_ApaSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_GmOvrlStMgr_ApaSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_GmOvrlStMgr_ApaSt_Val"
// #pragma POLYSPACE_WORST "Rte_Write_GmOvrlStMgr_ApaSt_Val"
//
// __PST__UINT8 Rte_Write_GmOvrlStMgr_ApaSt_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_GmOvrlStMgr_EscSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_GmOvrlStMgr_EscSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_GmOvrlStMgr_EscSt_Val"
// #pragma POLYSPACE_WORST "Rte_Write_GmOvrlStMgr_EscSt_Val"
//
// __PST__UINT8 Rte_Write_GmOvrlStMgr_EscSt_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_GmOvrlStMgr_HwAgServoCmd_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_GmOvrlStMgr_HwAgServoCmd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_GmOvrlStMgr_HwAgServoCmd_Val"
// #pragma POLYSPACE_WORST "Rte_Write_GmOvrlStMgr_HwAgServoCmd_Val"
//
// __PST__UINT8 Rte_Write_GmOvrlStMgr_HwAgServoCmd_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_GmOvrlStMgr_HwAgServoEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_GmOvrlStMgr_HwAgServoEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_GmOvrlStMgr_HwAgServoEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_GmOvrlStMgr_HwAgServoEna_Logl"
//
// __PST__UINT8 Rte_Write_GmOvrlStMgr_HwAgServoEna_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_GmOvrlStMgr_HwOscnEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_GmOvrlStMgr_HwOscnEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_GmOvrlStMgr_HwOscnEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_GmOvrlStMgr_HwOscnEna_Logl"
//
// __PST__UINT8 Rte_Write_GmOvrlStMgr_HwOscnEna_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_GmOvrlStMgr_HwOscnFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_GmOvrlStMgr_HwOscnFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_GmOvrlStMgr_HwOscnFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Write_GmOvrlStMgr_HwOscnFrq_Val"
//
// __PST__UINT8 Rte_Write_GmOvrlStMgr_HwOscnFrq_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_GmOvrlStMgr_HwOscnMotAmp_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_GmOvrlStMgr_HwOscnMotAmp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_GmOvrlStMgr_HwOscnMotAmp_Val"
// #pragma POLYSPACE_WORST "Rte_Write_GmOvrlStMgr_HwOscnMotAmp_Val"
//
// __PST__UINT8 Rte_Write_GmOvrlStMgr_HwOscnMotAmp_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_GmOvrlStMgr_HwTqOscSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_GmOvrlStMgr_HwTqOscSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_GmOvrlStMgr_HwTqOscSt_Val"
// #pragma POLYSPACE_WORST "Rte_Write_GmOvrlStMgr_HwTqOscSt_Val"
//
// __PST__UINT8 Rte_Write_GmOvrlStMgr_HwTqOscSt_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_GmOvrlStMgr_LkaSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_GmOvrlStMgr_LkaSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_GmOvrlStMgr_LkaSt_Val"
// #pragma POLYSPACE_WORST "Rte_Write_GmOvrlStMgr_LkaSt_Val"
//
// __PST__UINT8 Rte_Write_GmOvrlStMgr_LkaSt_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_GmOvrlStMgr_GetRefTmr100MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_GmOvrlStMgr_GetRefTmr100MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_GmOvrlStMgr_GetRefTmr100MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_GmOvrlStMgr_GetRefTmr100MicroSec32bit_Oper"
//
// __PST__UINT8 Rte_Call_GmOvrlStMgr_GetRefTmr100MicroSec32bit_Oper(__PST__g__29 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_GmOvrlStMgr_GetTiSpan100MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_GmOvrlStMgr_GetTiSpan100MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_GmOvrlStMgr_GetTiSpan100MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_GmOvrlStMgr_GetTiSpan100MicroSec32bit_Oper"
//
// __PST__UINT8 Rte_Call_GmOvrlStMgr_GetTiSpan100MicroSec32bit_Oper(__PST__UINT32 P_0, __PST__g__29 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_GmOvrlStMgr_GmLoaIgnCntr_GetErrorStatus
//
// #pragma POLYSPACE_PURE "Rte_Call_GmOvrlStMgr_GmLoaIgnCntr_GetErrorStatus"
// #pragma POLYSPACE_CLEAN "Rte_Call_GmOvrlStMgr_GmLoaIgnCntr_GetErrorStatus"
// #pragma POLYSPACE_WORST "Rte_Call_GmOvrlStMgr_GmLoaIgnCntr_GetErrorStatus"
//
// __PST__UINT8 Rte_Call_GmOvrlStMgr_GmLoaIgnCntr_GetErrorStatus(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_GmOvrlStMgr_GmLoaIgnCntr_SetRamBlockStatus
//
// #pragma POLYSPACE_PURE "Rte_Call_GmOvrlStMgr_GmLoaIgnCntr_SetRamBlockStatus"
// #pragma POLYSPACE_CLEAN "Rte_Call_GmOvrlStMgr_GmLoaIgnCntr_SetRamBlockStatus"
// #pragma POLYSPACE_WORST "Rte_Call_GmOvrlStMgr_GmLoaIgnCntr_SetRamBlockStatus"
//
// __PST__UINT8 Rte_Call_GmOvrlStMgr_GmLoaIgnCntr_SetRamBlockStatus(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_GmOvrlStMgr_SetNtcSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_GmOvrlStMgr_SetNtcSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_GmOvrlStMgr_SetNtcSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_GmOvrlStMgr_SetNtcSts_Oper"
//
// __PST__UINT8 Rte_Call_GmOvrlStMgr_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqThd_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaVehSpdHiLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaVehSpdHiLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaVehSpdHiLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaVehSpdHiLim_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaVehSpdHiLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrEscVehSpdHiLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrEscVehSpdHiLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrEscVehSpdHiLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrEscVehSpdHiLim_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrEscVehSpdHiLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcAmp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcAmp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcAmp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcAmp_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcAmp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHwTqFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHwTqFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHwTqFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHwTqFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHwTqFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqThd1_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqThd1_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqThd1_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqThd1_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqThd1_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqThd2_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqThd2_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqThd2_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqThd2_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqThd2_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaVehSpdHiLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaVehSpdHiLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaVehSpdHiLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaVehSpdHiLim_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaVehSpdHiLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaVehSpdLoLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaVehSpdLoLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaVehSpdLoLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaVehSpdLoLim_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaVehSpdLoLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbTqMax_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbTqMax_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbTqMax_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbTqMax_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbTqMax_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbTqMin_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbTqMin_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbTqMin_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbTqMin_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbTqMin_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbVehSpdMax_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbVehSpdMax_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbVehSpdMax_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbVehSpdMax_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbVehSpdMax_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbVehSpdMin_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbVehSpdMin_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbVehSpdMin_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbVehSpdMin_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbVehSpdMin_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnStrtHaptcAmp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnStrtHaptcAmp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnStrtHaptcAmp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnStrtHaptcAmp_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnStrtHaptcAmp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrStandStillThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrStandStillThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrStandStillThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrStandStillThd_Val"
//
// __PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrStandStillThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqTiThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqTiThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqTiThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqTiThd_Val"
//
// __PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqTiThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcDurn_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcDurn_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcDurn_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcDurn_Val"
//
// __PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcDurn_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcReactnTi_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcReactnTi_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcReactnTi_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcReactnTi_Val"
//
// __PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcReactnTi_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcReqTiThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcReqTiThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcReqTiThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcReqTiThd_Val"
//
// __PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcReqTiThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqTiThd1_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqTiThd1_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqTiThd1_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqTiThd1_Val"
//
// __PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqTiThd1_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqTiThd2_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqTiThd2_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqTiThd2_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqTiThd2_Val"
//
// __PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqTiThd2_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbOffTi_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbOffTi_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbOffTi_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbOffTi_Val"
//
// __PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbOffTi_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbOnTi_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbOnTi_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbOnTi_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbOnTi_Val"
//
// __PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbOnTi_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbStrtOnTi_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbStrtOnTi_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbStrtOnTi_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbStrtOnTi_Val"
//
// __PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbStrtOnTi_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrShiftLvrTiThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrShiftLvrTiThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrShiftLvrTiThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrShiftLvrTiThd_Val"
//
// __PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrShiftLvrTiThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrStandStillTiThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrStandStillTiThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrStandStillTiThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrStandStillTiThd_Val"
//
// __PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrStandStillTiThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaStIgnCntrThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaStIgnCntrThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaStIgnCntrThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaStIgnCntrThd_Val"
//
// __PST__UINT16 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaStIgnCntrThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHaptcEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHaptcEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHaptcEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHaptcEna_Logl"
//
// __PST__UINT8 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHaptcEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaMfgEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaMfgEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaMfgEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaMfgEna_Logl"
//
// __PST__UINT8 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaMfgEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrEscMfgEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrEscMfgEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrEscMfgEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrEscMfgEna_Logl"
//
// __PST__UINT8 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrEscMfgEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaMfgEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaMfgEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaMfgEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaMfgEna_Logl"
//
// __PST__UINT8 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaMfgEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnTqOscnAmpY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnTqOscnAmpY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnTqOscnAmpY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnTqOscnAmpY_Ary1D"
//
// __PST__g__48 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnTqOscnAmpY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnVehSpdX_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnVehSpdX_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnVehSpdX_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnVehSpdX_Ary1D"
//
// __PST__g__48 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnVehSpdX_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_GmOvrlStMgr_GmOvrlStMgrInit1_IgnCntrLcl
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_GmOvrlStMgr_GmOvrlStMgrInit1_IgnCntrLcl"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_GmOvrlStMgr_GmOvrlStMgrInit1_IgnCntrLcl"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_GmOvrlStMgr_GmOvrlStMgrInit1_IgnCntrLcl"
//
// __PST__VOID Rte_IrvWrite_GmOvrlStMgr_GmOvrlStMgrInit1_IgnCntrLcl(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_GmOvrlStMgr_GmOvrlStMgrPer1_IgnCntrLcl
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_GmOvrlStMgr_GmOvrlStMgrPer1_IgnCntrLcl"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_GmOvrlStMgr_GmOvrlStMgrPer1_IgnCntrLcl"
// #pragma POLYSPACE_WORST "Rte_IrvRead_GmOvrlStMgr_GmOvrlStMgrPer1_IgnCntrLcl"
//
// __PST__UINT16 Rte_IrvRead_GmOvrlStMgr_GmOvrlStMgrPer1_IgnCntrLcl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function LnrIntrpn_u16_u16VariXu16VariY
//
// #pragma POLYSPACE_PURE "LnrIntrpn_u16_u16VariXu16VariY"
// #pragma POLYSPACE_CLEAN "LnrIntrpn_u16_u16VariXu16VariY"
// #pragma POLYSPACE_WORST "LnrIntrpn_u16_u16VariXu16VariY"
//
// __PST__UINT16 LnrIntrpn_u16_u16VariXu16VariY(__PST__g__48 P_0, __PST__g__48 P_1, __PST__UINT16 P_2, __PST__UINT16 P_3)
// {
//    ...
// }

