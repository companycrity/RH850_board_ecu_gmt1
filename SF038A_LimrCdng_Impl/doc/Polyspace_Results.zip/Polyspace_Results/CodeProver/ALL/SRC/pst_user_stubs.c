/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Rte_Read_LimrCdng_EotAssiSca_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_LimrCdng_EotAssiSca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_LimrCdng_EotAssiSca_Val"
// #pragma POLYSPACE_WORST "Rte_Read_LimrCdng_EotAssiSca_Val"
//
// __PST__UINT8 Rte_Read_LimrCdng_EotAssiSca_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_LimrCdng_EotMotTqLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_LimrCdng_EotMotTqLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_LimrCdng_EotMotTqLim_Val"
// #pragma POLYSPACE_WORST "Rte_Read_LimrCdng_EotMotTqLim_Val"
//
// __PST__UINT8 Rte_Read_LimrCdng_EotMotTqLim_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_LimrCdng_StallMotTqLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_LimrCdng_StallMotTqLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_LimrCdng_StallMotTqLim_Val"
// #pragma POLYSPACE_WORST "Rte_Read_LimrCdng_StallMotTqLim_Val"
//
// __PST__UINT8 Rte_Read_LimrCdng_StallMotTqLim_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_LimrCdng_SysMotTqCmdSca_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_LimrCdng_SysMotTqCmdSca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_LimrCdng_SysMotTqCmdSca_Val"
// #pragma POLYSPACE_WORST "Rte_Read_LimrCdng_SysMotTqCmdSca_Val"
//
// __PST__UINT8 Rte_Read_LimrCdng_SysMotTqCmdSca_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_LimrCdng_ThermMotTqLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_LimrCdng_ThermMotTqLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_LimrCdng_ThermMotTqLim_Val"
// #pragma POLYSPACE_WORST "Rte_Read_LimrCdng_ThermMotTqLim_Val"
//
// __PST__UINT8 Rte_Read_LimrCdng_ThermMotTqLim_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_LimrCdng_VehSpd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_LimrCdng_VehSpd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_LimrCdng_VehSpd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_LimrCdng_VehSpd_Val"
//
// __PST__UINT8 Rte_Read_LimrCdng_VehSpd_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_LimrCdng_VehSpdMotTqLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_LimrCdng_VehSpdMotTqLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_LimrCdng_VehSpdMotTqLim_Val"
// #pragma POLYSPACE_WORST "Rte_Read_LimrCdng_VehSpdMotTqLim_Val"
//
// __PST__UINT8 Rte_Read_LimrCdng_VehSpdMotTqLim_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_LimrCdng_EotAssiScaCdnd_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_LimrCdng_EotAssiScaCdnd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_LimrCdng_EotAssiScaCdnd_Val"
// #pragma POLYSPACE_WORST "Rte_Write_LimrCdng_EotAssiScaCdnd_Val"
//
// __PST__UINT8 Rte_Write_LimrCdng_EotAssiScaCdnd_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_LimrCdng_EotMotTqLimCdnd_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_LimrCdng_EotMotTqLimCdnd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_LimrCdng_EotMotTqLimCdnd_Val"
// #pragma POLYSPACE_WORST "Rte_Write_LimrCdng_EotMotTqLimCdnd_Val"
//
// __PST__UINT8 Rte_Write_LimrCdng_EotMotTqLimCdnd_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_LimrCdng_StallMotTqLimCdnd_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_LimrCdng_StallMotTqLimCdnd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_LimrCdng_StallMotTqLimCdnd_Val"
// #pragma POLYSPACE_WORST "Rte_Write_LimrCdng_StallMotTqLimCdnd_Val"
//
// __PST__UINT8 Rte_Write_LimrCdng_StallMotTqLimCdnd_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_LimrCdng_SysMotTqCmdScaCdnd_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_LimrCdng_SysMotTqCmdScaCdnd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_LimrCdng_SysMotTqCmdScaCdnd_Val"
// #pragma POLYSPACE_WORST "Rte_Write_LimrCdng_SysMotTqCmdScaCdnd_Val"
//
// __PST__UINT8 Rte_Write_LimrCdng_SysMotTqCmdScaCdnd_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_LimrCdng_ThermMotTqLimCdnd_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_LimrCdng_ThermMotTqLimCdnd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_LimrCdng_ThermMotTqLimCdnd_Val"
// #pragma POLYSPACE_WORST "Rte_Write_LimrCdng_ThermMotTqLimCdnd_Val"
//
// __PST__UINT8 Rte_Write_LimrCdng_ThermMotTqLimCdnd_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_LimrCdng_VehSpdMotTqLimCdnd_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_LimrCdng_VehSpdMotTqLimCdnd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_LimrCdng_VehSpdMotTqLimCdnd_Val"
// #pragma POLYSPACE_WORST "Rte_Write_LimrCdng_VehSpdMotTqLimCdnd_Val"
//
// __PST__UINT8 Rte_Write_LimrCdng_VehSpdMotTqLimCdnd_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LimrCdng_LimrCdngGainDecSlew_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LimrCdng_LimrCdngGainDecSlew_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LimrCdng_LimrCdngGainDecSlew_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LimrCdng_LimrCdngGainDecSlew_Val"
//
// __PST__FLOAT32 Rte_Prm_LimrCdng_LimrCdngGainDecSlew_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LimrCdng_LimrCdngTqDecSlew_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LimrCdng_LimrCdngTqDecSlew_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LimrCdng_LimrCdngTqDecSlew_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LimrCdng_LimrCdngTqDecSlew_Val"
//
// __PST__FLOAT32 Rte_Prm_LimrCdng_LimrCdngTqDecSlew_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LimrCdng_LimrCdngGainIncSlewX_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_LimrCdng_LimrCdngGainIncSlewX_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LimrCdng_LimrCdngGainIncSlewX_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_LimrCdng_LimrCdngGainIncSlewX_Ary1D"
//
// __PST__g__32 Rte_Prm_LimrCdng_LimrCdngGainIncSlewX_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LimrCdng_LimrCdngGainIncSlewY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_LimrCdng_LimrCdngGainIncSlewY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LimrCdng_LimrCdngGainIncSlewY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_LimrCdng_LimrCdngGainIncSlewY_Ary1D"
//
// __PST__g__32 Rte_Prm_LimrCdng_LimrCdngGainIncSlewY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LimrCdng_LimrCdngTqIncSlewX_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_LimrCdng_LimrCdngTqIncSlewX_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LimrCdng_LimrCdngTqIncSlewX_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_LimrCdng_LimrCdngTqIncSlewX_Ary1D"
//
// __PST__g__32 Rte_Prm_LimrCdng_LimrCdngTqIncSlewX_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LimrCdng_LimrCdngTqIncSlewY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_LimrCdng_LimrCdngTqIncSlewY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LimrCdng_LimrCdngTqIncSlewY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_LimrCdng_LimrCdngTqIncSlewY_Ary1D"
//
// __PST__g__32 Rte_Prm_LimrCdng_LimrCdngTqIncSlewY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function LnrIntrpn_u16_u16VariXu16VariY
//
// #pragma POLYSPACE_PURE "LnrIntrpn_u16_u16VariXu16VariY"
// #pragma POLYSPACE_CLEAN "LnrIntrpn_u16_u16VariXu16VariY"
// #pragma POLYSPACE_WORST "LnrIntrpn_u16_u16VariXu16VariY"
//
// __PST__UINT16 LnrIntrpn_u16_u16VariXu16VariY(__PST__g__32 P_0, __PST__g__32 P_1, __PST__UINT16 P_2, __PST__UINT16 P_3)
// {
//    ...
// }

