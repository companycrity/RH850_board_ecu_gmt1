/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *          File:  PolarityCfg.c
 *     SW-C Type:  PolarityCfg
 *  Generated at:  Tue May 26 09:55:03 2015
 *
 *     Generator:  MICROSAR RTE Generator Version 4.3.0
 *                 RTE Core Version 1.3.0
 *       License:  Unlimited license CBD1400351 (THE ECU PRODUCT "STEERING SYSTEMS", THE ECU SUPPLIER "NEXTEER", THE VEHICLE MANUFACTURER "GENERAL MOTORS CORPORATION") for Nexteer Automotive Corporation
 *
 *   Description:  C-Code implementation template for SW-C <PolarityCfg>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
/**********************************************************************************************************************
* Copyright 2015 Nexteer 
* Nexteer Confidential
*
* Module File Name  : PolarityCfg.c
* Module Description: Implementation of Polarity Configuration FDD ES102A
* Project           : CBD 
* Author            : Sankardu Varadapureddi
***********************************************************************************************************************
* Version Control:
* %version          : 1 %
* %derived_by       : pznywf %
*----------------------------------------------------------------------------------------------------------------------
* Date      Rev      Author         Change Description                                                           SCR #
* -------   -------  --------  ---------------------------------------------------------------------------     --------
* 05/22/15  1        SV        Initial Version                                                                 EA4#271
**********************************************************************************************************************/

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

#include "Rte_PolarityCfg.h"


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
/******************************************** File Level Rule Deviations *********************************************/
/* MISRA-C:2004 Rule 16.10 [NXTRDEV 16.10.1]: There is no appropriate action to take on the return value */ 
/* MISRA-C:2004 Rule 19.1 [NXTRDEV 19.1.1]: AUTOSAR requires deviation from this rule for Memory Mapping include statements */

/********************************************* Embedded Local Constants **********************************************/
#define D_HWAG0POL_CNT_U32          0x00000001U
#define D_HWAG1POL_CNT_U32          0x00000002U
#define D_HWAG2POL_CNT_U32          0x00000004U
#define D_HWAG3POL_CNT_U32          0x00000008U
#define D_HWAG4POL_CNT_U32          0x00000010U
#define D_HWAG5POL_CNT_U32          0x00000020U
#define D_HWAG6POL_CNT_U32          0x00000040U
#define D_HWAG7POL_CNT_U32          0x00000080U

#define D_HWTQ0POL_CNT_U32          0x00000100U
#define D_HWTQ1POL_CNT_U32          0x00000200U
#define D_HWTQ2POL_CNT_U32          0x00000400U
#define D_HWTQ3POL_CNT_U32          0x00000800U
#define D_HWTQ4POL_CNT_U32          0x00001000U
#define D_HWTQ5POL_CNT_U32          0x00002000U
#define D_HWTQ6POL_CNT_U32          0x00004000U
#define D_HWTQ7POL_CNT_U32          0x00008000U

#define D_MOTAGMECL0POL_CNT_U32     0x00010000U
#define D_MOTAGMECL1POL_CNT_U32     0x00020000U
#define D_MOTAGMECL2POL_CNT_U32     0x00040000U
#define D_MOTAGMECL3POL_CNT_U32     0x00080000U
#define D_MOTAGMECL4POL_CNT_U32     0x00100000U
#define D_MOTAGMECL5POL_CNT_U32     0x00200000U
#define D_MOTAGMECL6POL_CNT_U32     0x00400000U
#define D_MOTAGMECL7POL_CNT_U32     0x00800000U

#define D_MOTELECMECLPOL_CNT_U32    0x01000000U
#define D_ASSIMECHPOL_CNT_U32       0x02000000U

#define D_ONE_CNT_S8                1
#define D_NEGONE_CNT_S8             (-1)  
/******************************************** Module Specific Variables **********************************************/

/******************************************** Local Function Prototypes **********************************************/
STATIC FUNC(sint8, PolarityCfg_CODE) GetPolarity(VAR(uint32, AUTOMATIC) Polarity_Cnt_T_u32,
                                                 VAR(uint32, AUTOMATIC) PolarityMask_Cnt_T_u32);

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * dtRef_const_VOID: DataReference
 *
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   uint32 *Rte_Pim_PolarityCfgSaved(void)
 *
 *********************************************************************************************************************/


#define PolarityCfg_START_SEC_CODE
#include "PolarityCfg_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PolarityCfgInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_AssiMechPolarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_HwAg0Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_HwAg1Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_HwAg2Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_HwAg3Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_HwAg4Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_HwAg5Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_HwAg6Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_HwAg7Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_HwTq0Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_HwTq1Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_HwTq2Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_HwTq3Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_HwTq4Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_HwTq5Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_HwTq6Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_HwTq7Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_MotAgMecl0Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_MotAgMecl1Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_MotAgMecl2Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_MotAgMecl3Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_MotAgMecl4Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_MotAgMecl5Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_MotAgMecl6Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_MotAgMecl7Polarity_Val(sint8 data)
 *   Std_ReturnType Rte_Write_MotElecMeclPolarity_Val(sint8 data)
 *
 *********************************************************************************************************************/

FUNC(void, PolarityCfg_CODE) PolarityCfgInit(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: PolarityCfgInit
 *********************************************************************************************************************/
    /* REQ: ES102A #77 I */
    /* REQ: ES102A #80 I */
    /* REQ: ES102A #120 I */
    /* REQ: ES102A #121 I */
    (void)Rte_Write_HwAg0Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_HWAG0POL_CNT_U32));    /* REQ: ES102A #103 I */
    (void)Rte_Write_HwAg1Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_HWAG1POL_CNT_U32));    /* REQ: ES102A #104 I */
    (void)Rte_Write_HwAg2Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_HWAG2POL_CNT_U32));    /* REQ: ES102A #105 I */
    (void)Rte_Write_HwAg3Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_HWAG3POL_CNT_U32));    /* REQ: ES102A #106 I */
    (void)Rte_Write_HwAg4Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_HWAG4POL_CNT_U32));    /* REQ: ES102A #107 I */
    (void)Rte_Write_HwAg5Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_HWAG5POL_CNT_U32));    /* REQ: ES102A #108 I */
    (void)Rte_Write_HwAg6Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_HWAG6POL_CNT_U32));    /* REQ: ES102A #109 I */
    (void)Rte_Write_HwAg7Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_HWAG7POL_CNT_U32));    /* REQ: ES102A #110 I */
     
    (void)Rte_Write_HwTq0Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_HWTQ0POL_CNT_U32));    /* REQ: ES102A #51 I */
    (void)Rte_Write_HwTq1Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_HWTQ1POL_CNT_U32));    /* REQ: ES102A #96 I */
    (void)Rte_Write_HwTq2Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_HWTQ2POL_CNT_U32));    /* REQ: ES102A #97 I */
    (void)Rte_Write_HwTq3Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_HWTQ3POL_CNT_U32));    /* REQ: ES102A #98 I */
    (void)Rte_Write_HwTq4Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_HWTQ4POL_CNT_U32));    /* REQ: ES102A #99 I */
    (void)Rte_Write_HwTq5Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_HWTQ5POL_CNT_U32));    /* REQ: ES102A #100 I */
    (void)Rte_Write_HwTq6Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_HWTQ6POL_CNT_U32));    /* REQ: ES102A #101 I */
    (void)Rte_Write_HwTq7Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_HWTQ7POL_CNT_U32));    /* REQ: ES102A #102 I */
     
    (void)Rte_Write_MotAgMecl0Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_MOTAGMECL0POL_CNT_U32));  /* REQ: ES102A #111 I */
    (void)Rte_Write_MotAgMecl1Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_MOTAGMECL1POL_CNT_U32));  /* REQ: ES102A #112 I */
    (void)Rte_Write_MotAgMecl2Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_MOTAGMECL2POL_CNT_U32));  /* REQ: ES102A #113 I */
    (void)Rte_Write_MotAgMecl3Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_MOTAGMECL3POL_CNT_U32));  /* REQ: ES102A #114 I */
    (void)Rte_Write_MotAgMecl4Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_MOTAGMECL4POL_CNT_U32));  /* REQ: ES102A #115 I */
    (void)Rte_Write_MotAgMecl5Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_MOTAGMECL5POL_CNT_U32));  /* REQ: ES102A #116 I */
    (void)Rte_Write_MotAgMecl6Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_MOTAGMECL6POL_CNT_U32));  /* REQ: ES102A #117 I */
    (void)Rte_Write_MotAgMecl7Polarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_MOTAGMECL7POL_CNT_U32));  /* REQ: ES102A #118 I */
     
    (void)Rte_Write_MotElecMeclPolarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_MOTELECMECLPOL_CNT_U32));    /* REQ: ES102A #119 I */
    (void)Rte_Write_AssiMechPolarity_Val(GetPolarity(*Rte_Pim_PolarityCfgSaved(), D_ASSIMECHPOL_CNT_U32));  /* REQ: ES102A #124 I */
    /* ENDREQ: ES102A #77 */
    /* ENDREQ: ES102A #80 */
    /* ENDREQ: ES102A #120 */
    /* ENDREQ: ES102A #121 */
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PolarityCfgRead
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Oper> of PortPrototype <PolarityCfgRead>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_ServiceRead_Val(uint32 data)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType PolarityCfgRead(uint32 *PolarityCfgSaved)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_PolarityCfgRead1_E_NOT_OK
 *
 *********************************************************************************************************************/

FUNC(Std_ReturnType, PolarityCfg_CODE) PolarityCfgRead(P2VAR(uint32, AUTOMATIC, RTE_POLARITYCFG_APPL_VAR) PolarityCfgSaved) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: PolarityCfgRead (returns application error)
 *********************************************************************************************************************/
    /* REQ: ES102A #32 I */
    /* REQ: ES102A #77 I */
    *PolarityCfgSaved = *Rte_Pim_PolarityCfgSaved();
    return RTE_E_OK;
    /* ENDREQ: ES102A #32 */
    /* ENDREQ: ES102A #77 */
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PolarityCfgWr
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Oper> of PortPrototype <PolarityCfgWr>
 *
 **********************************************************************************************************************
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_NvMService_AC3_SRBS_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType PolarityCfgWr(uint32 PolarityCfgSaved)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_PolarityCfgWr1_E_NOT_OK
 *
 *********************************************************************************************************************/

FUNC(Std_ReturnType, PolarityCfg_CODE) PolarityCfgWr(uint32 PolarityCfgSaved) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: PolarityCfgWr (returns application error)
 *********************************************************************************************************************/
    /* REQ: ES102A #77 I */
    /* REQ: ES102A #122 I */
    /* REQ: ES102A #123 I */
    *Rte_Pim_PolarityCfgSaved() = PolarityCfgSaved;
    (void)Rte_Call_NvMService_AC3_SRBS_WriteBlock(NULL_PTR);
    return RTE_E_OK;
    /* ENDREQ: ES102A #77 */
    /* ENDREQ: ES102A #122 */
    /* ENDREQ: ES102A #123 */
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define PolarityCfg_STOP_SEC_CODE
#include "PolarityCfg_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
STATIC FUNC(sint8, PolarityCfg_CODE) GetPolarity( VAR(uint32, AUTOMATIC) Polarity_Cnt_T_u32,
                                                  VAR(uint32, AUTOMATIC) PolarityMask_Cnt_T_u32)
{
    VAR(sint8, AUTOMATIC) Polarity_Cnt_T_s08;
    
    if ( (Polarity_Cnt_T_u32 & PolarityMask_Cnt_T_u32) == PolarityMask_Cnt_T_u32 )
    {
        Polarity_Cnt_T_s08 = D_ONE_CNT_S8;  
    }
    else
    {
        Polarity_Cnt_T_s08 = D_NEGONE_CNT_S8;
    }

    return(Polarity_Cnt_T_s08);
}

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
