#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern struct __PST__g__30 _main_gen_init_g30(void);

extern struct Rte_CDS_MotCtrlPrmEstimn _main_gen_init_g28(void);

struct __PST__g__30 _main_gen_init_g30(void)
{
    static struct __PST__g__30 x;
    /* struct/union type */
    x.MotBackEmfConNom = _main_gen_init_g10();
    x.MotRNom = _main_gen_init_g10();
    return x;
}

struct Rte_CDS_MotCtrlPrmEstimn _main_gen_init_g28(void)
{
    static struct Rte_CDS_MotCtrlPrmEstimn x;
    /* struct/union type */
    /* pointer */
    {
        static struct __PST__g__30 _main_gen_tmp_6[ARRAY_NBELEM(struct __PST__g__30)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(struct __PST__g__30); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g30();
        }
        x.Pim_MotPrmNom = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(struct __PST__g__30) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_8[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g10();
        }
        x.Pim_dMotCtrlPrmEstimnCtrlrREstimdPreLim = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_10[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g10();
        }
        x.Pim_dMotCtrlPrmEstimnFetRFfEstimd = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_12[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g10();
        }
        x.Pim_dMotCtrlPrmEstimnMotBackEmfConEstimdPreLim = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_14[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g10();
        }
        x.Pim_dMotCtrlPrmEstimnMotBackEmfConEstimdSatnSca = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_16[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g10();
        }
        x.Pim_dMotCtrlPrmEstimnMotInduEstimdPreLimDax = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_18[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g10();
        }
        x.Pim_dMotCtrlPrmEstimnMotInduEstimdPreLimQax = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_20[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g10();
        }
        x.Pim_dMotCtrlPrmEstimnMotInduEstimdSatnScaDax = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_22[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g10();
        }
        x.Pim_dMotCtrlPrmEstimnMotInduEstimdSatnScaQax = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_24[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_25;
        for (_i_main_gen_tmp_25 = 0; _i_main_gen_tmp_25 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_25++)
        {
            _main_gen_tmp_24[_i_main_gen_tmp_25] = _main_gen_init_g10();
        }
        x.Pim_dMotCtrlPrmEstimnMotRFfEstimd = PST_TRUE() ? 0 : &_main_gen_tmp_24[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_MotCtrlPrmEstimn(void)
{
    extern __PST__g__25 Rte_Inst_MotCtrlPrmEstimn;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_MotCtrlPrmEstimn _main_gen_tmp_4[ARRAY_NBELEM(struct Rte_CDS_MotCtrlPrmEstimn)];
            __PST__UINT32 _i_main_gen_tmp_5;
            for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(struct Rte_CDS_MotCtrlPrmEstimn); _i_main_gen_tmp_5++)
            {
                _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g28();
            }
            Rte_Inst_MotCtrlPrmEstimn = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(struct Rte_CDS_MotCtrlPrmEstimn) / 2];
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_MotCtrlPrmEstimn */
    _main_gen_init_sym_Rte_Inst_MotCtrlPrmEstimn();
    
}
