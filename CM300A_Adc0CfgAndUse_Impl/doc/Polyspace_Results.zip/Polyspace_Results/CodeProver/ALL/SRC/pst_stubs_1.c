#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern union __PST__g__294 _main_gen_init_g294(void);

extern union __PST__g__282 _main_gen_init_g282(void);

extern union __PST__g__275 _main_gen_init_g275(void);

extern union __PST__g__269 _main_gen_init_g269(void);

extern union __PST__g__267 _main_gen_init_g267(void);

extern union __PST__g__265 _main_gen_init_g265(void);

extern union __PST__g__263 _main_gen_init_g263(void);

extern union __PST__g__261 _main_gen_init_g261(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern union __PST__g__258 _main_gen_init_g258(void);

extern union __PST__g__256 _main_gen_init_g256(void);

extern union __PST__g__254 _main_gen_init_g254(void);

extern union __PST__g__249 _main_gen_init_g249(void);

extern union __PST__g__223 _main_gen_init_g223(void);

extern union __PST__g__220 _main_gen_init_g220(void);

extern struct __PST__g__217 _main_gen_init_g217(void);

extern union __PST__g__216 _main_gen_init_g216(void);

extern struct __PST__g__212 _main_gen_init_g212(void);

extern union __PST__g__211 _main_gen_init_g211(void);

extern struct __PST__g__198 _main_gen_init_g198(void);

extern union __PST__g__197 _main_gen_init_g197(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern union __PST__g__29 _main_gen_init_g29(void);

extern __PST__g__27 _main_gen_init_g27(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct Rte_CDS_CDD_Adc0CfgAndUse _main_gen_init_g25(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct Rte_CDS_CDD_Adc0CfgAndUse _main_gen_init_g25(void)
{
    static struct Rte_CDS_CDD_Adc0CfgAndUse x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g6();
        }
        x.Pim_Adc0DiagcEndPtr = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g6();
        }
        x.Pim_Adc0DiagcStrtPtr = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

union __PST__g__29 _main_gen_init_g29(void)
{
    static union __PST__g__29 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__198 _main_gen_init_g198(void)
{
    static struct __PST__g__198 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 3);
        x.SUSMTD = bitf;
    }
    return x;
}

union __PST__g__197 _main_gen_init_g197(void)
{
    static union __PST__g__197 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g198();
    return x;
}

struct __PST__g__212 _main_gen_init_g212(void)
{
    static struct __PST__g__212 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.ADDNT = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.DFMT = bitf;
    }
    return x;
}

union __PST__g__211 _main_gen_init_g211(void)
{
    static union __PST__g__211 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g212();
    return x;
}

struct __PST__g__217 _main_gen_init_g217(void)
{
    static struct __PST__g__217 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.IDEIE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.PEIE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.OWEIE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.ULEIE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.RDCLRE = bitf;
    }
    return x;
}

union __PST__g__216 _main_gen_init_g216(void)
{
    static union __PST__g__216 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g217();
    return x;
}

union __PST__g__220 _main_gen_init_g220(void)
{
    static union __PST__g__220 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__223 _main_gen_init_g223(void)
{
    static union __PST__g__223 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__249 _main_gen_init_g249(void)
{
    static union __PST__g__249 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__254 _main_gen_init_g254(void)
{
    static union __PST__g__254 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__256 _main_gen_init_g256(void)
{
    static union __PST__g__256 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

union __PST__g__258 _main_gen_init_g258(void)
{
    static union __PST__g__258 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__261 _main_gen_init_g261(void)
{
    static union __PST__g__261 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__263 _main_gen_init_g263(void)
{
    static union __PST__g__263 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__265 _main_gen_init_g265(void)
{
    static union __PST__g__265 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__267 _main_gen_init_g267(void)
{
    static union __PST__g__267 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__269 _main_gen_init_g269(void)
{
    static union __PST__g__269 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__275 _main_gen_init_g275(void)
{
    static union __PST__g__275 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__282 _main_gen_init_g282(void)
{
    static union __PST__g__282 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__294 _main_gen_init_g294(void)
{
    static union __PST__g__294 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* struct/union type */
    x.VCR00 = _main_gen_init_g29();
    x.VCR01 = _main_gen_init_g29();
    x.VCR02 = _main_gen_init_g29();
    x.VCR03 = _main_gen_init_g29();
    x.VCR04 = _main_gen_init_g29();
    x.VCR05 = _main_gen_init_g29();
    x.VCR06 = _main_gen_init_g29();
    x.VCR07 = _main_gen_init_g29();
    x.VCR08 = _main_gen_init_g29();
    x.VCR09 = _main_gen_init_g29();
    x.VCR10 = _main_gen_init_g29();
    x.VCR11 = _main_gen_init_g29();
    x.VCR12 = _main_gen_init_g29();
    x.VCR13 = _main_gen_init_g29();
    x.VCR14 = _main_gen_init_g29();
    x.VCR15 = _main_gen_init_g29();
    x.VCR16 = _main_gen_init_g29();
    x.VCR17 = _main_gen_init_g29();
    x.VCR18 = _main_gen_init_g29();
    x.VCR19 = _main_gen_init_g29();
    x.VCR20 = _main_gen_init_g29();
    x.VCR21 = _main_gen_init_g29();
    x.VCR22 = _main_gen_init_g29();
    x.VCR23 = _main_gen_init_g29();
    x.ADCR1 = _main_gen_init_g197();
    x.ADCR2 = _main_gen_init_g211();
    x.SFTCR = _main_gen_init_g216();
    x.ODCR = _main_gen_init_g220();
    x.ULLMTBR0 = _main_gen_init_g223();
    x.ULLMTBR1 = _main_gen_init_g223();
    x.ULLMTBR2 = _main_gen_init_g223();
    x.THCR = _main_gen_init_g249();
    x.THACR = _main_gen_init_g254();
    x.THBCR = _main_gen_init_g254();
    x.THER = _main_gen_init_g256();
    x.THGSR = _main_gen_init_g258();
    x.SGSTCR0 = _main_gen_init_g261();
    x.SGCR0 = _main_gen_init_g263();
    x.SGVCSP0 = _main_gen_init_g265();
    x.SGVCEP0 = _main_gen_init_g267();
    x.SGMCYCR0 = _main_gen_init_g269();
    x.ULLMSR0 = _main_gen_init_g275();
    x.SGSTCR1 = _main_gen_init_g261();
    x.SGCR1 = _main_gen_init_g263();
    x.SGVCSP1 = _main_gen_init_g265();
    x.SGVCEP1 = _main_gen_init_g267();
    x.SGMCYCR1 = _main_gen_init_g269();
    x.ULLMSR1 = _main_gen_init_g275();
    x.SGSTCR2 = _main_gen_init_g261();
    x.SGCR2 = _main_gen_init_g263();
    x.SGVCSP2 = _main_gen_init_g265();
    x.SGVCEP2 = _main_gen_init_g267();
    x.SGMCYCR2 = _main_gen_init_g269();
    x.ULLMSR2 = _main_gen_init_g275();
    x.SGSTCR3 = _main_gen_init_g261();
    x.SGCR3 = _main_gen_init_g282();
    x.SGVCSP3 = _main_gen_init_g265();
    x.SGVCEP3 = _main_gen_init_g267();
    x.SGMCYCR3 = _main_gen_init_g269();
    x.ULLMSR3 = _main_gen_init_g275();
    x.SGSTCR4 = _main_gen_init_g261();
    x.SGCR4 = _main_gen_init_g282();
    x.SGVCSP4 = _main_gen_init_g265();
    x.SGVCEP4 = _main_gen_init_g267();
    x.SGMCYCR4 = _main_gen_init_g269();
    x.ULLMSR4 = _main_gen_init_g275();
    x.ADOPDIG0 = _main_gen_init_g294();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_Adc0CfgAndUse(void)
{
    extern __PST__g__22 Rte_Inst_CDD_Adc0CfgAndUse;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_Adc0CfgAndUse _main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_CDD_Adc0CfgAndUse)];
            __PST__UINT32 _i_main_gen_tmp_1;
            for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(struct Rte_CDS_CDD_Adc0CfgAndUse); _i_main_gen_tmp_1++)
            {
                _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g25();
            }
            Rte_Inst_CDD_Adc0CfgAndUse = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_CDD_Adc0CfgAndUse) / 2];
        }
    }
}

static void _main_gen_init_sym_ADCD0(void)
{
    extern __PST__g__27 ADCD0;
    
    /* initialization with random value */
    {
        ADCD0 = _main_gen_init_g27();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_CDD_Adc0CfgAndUse */
    _main_gen_init_sym_Rte_Inst_CDD_Adc0CfgAndUse();
    
    /* init for variable ADCD0 */
    _main_gen_init_sym_ADCD0();
    
}
