typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__VOID __PST__g__15(void);
typedef __PST__FLOAT32 *__PST__g__17;
typedef __PST__VOID __PST__g__16(__PST__g__17);
typedef __PST__UINT8 *__PST__g__19;
typedef __PST__VOID __PST__g__18(__PST__g__19);
typedef __PST__VOID __PST__g__20(__PST__FLOAT32);
typedef __PST__FLOAT64 __PST__g__21(void);
typedef __PST__g__11 *__PST__g__23;
typedef volatile __PST__FLOAT64 __PST__g__24;
typedef __PST__SINT8 *__PST__g__26;
typedef volatile __PST__g__26 __PST__g__25;
typedef const struct Rte_CDS_CDD_HwTq0Meas __PST__g__29;
typedef __PST__g__29 *__PST__g__28;
typedef const __PST__g__28 __PST__g__27;
typedef __PST__UINT32 *__PST__g__31;
typedef struct __PST__g__33 *__PST__g__32;
struct Rte_CDS_CDD_HwTq0Meas
  {
    __PST__g__19 Pim_HwTq0ComStsErrCntr;
    __PST__g__19 Pim_HwTq0IntSnsrErrCntr;
    __PST__g__17 Pim_HwTq0MeasPrevHwTq0;
    __PST__g__19 Pim_HwTq0MeasPrevRollgCntr;
    __PST__g__31 Pim_HwTq0MsgMissRxCnt;
    __PST__g__32 Pim_HwTq0Offs;
    __PST__g__17 Pim_RackLimrCcwEot0;
    __PST__g__17 Pim_RackLimrCwEot0;
    __PST__g__19 Pim_RackLimrEot0Avl;
    __PST__g__19 Pim_RackLimrEot0Data0;
    __PST__g__19 Pim_RackLimrEot0Data1;
    __PST__g__19 Pim_RackLimrEot0Data2;
    __PST__g__19 Pim_RackLimrEot0Id2DataReadCmpl;
    __PST__g__19 Pim_RackLimrEot0Id3DataReadCmpl;
    __PST__g__19 Pim_RackLimrEot0Id4DataReadCmpl;
  };
typedef __PST__SINT8 __PST__g__34[3];
struct __PST__g__33
  {
    __PST__FLOAT32 OffsTrim;
    __PST__UINT8 OffsTrimPrfmdSts;
    __PST__g__34 __pst_unused_field___pstfiller;
  };
typedef __PST__SINT32 __PST__g__203[1];
union __PST__g__37
  {
    __PST__g__203 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef __PST__SINT8 __PST__g__201[4];
typedef __PST__SINT8 __PST__g__202[8];
union __PST__g__45
  {
    __PST__g__203 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__50
  {
    __PST__g__203 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__54
  {
    __PST__g__203 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__57
  {
    __PST__g__203 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__60
  {
    __PST__g__203 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__64
  {
    __PST__g__203 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__64 __PST__g__63;
struct __PST__g__71
  {
    const __PST__UINT32 FRS : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    const __PST__UINT32 __pst_unused_field_2 : 1;
    const __PST__UINT32 __pst_unused_field_3 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    const __PST__UINT32 __pst_unused_field_6 : 1;
    const __PST__UINT32 NRS : 1;
    const __PST__UINT32 __pst_unused_field_8 : 1;
    const __PST__UINT32 __pst_unused_field_9 : 1;
    const __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 21;
  };
typedef const struct __PST__g__71 __PST__g__70;
union __PST__g__69
  {
    __PST__g__70 BIT;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__69 __PST__g__68;
struct __PST__g__74
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 NRC : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
union __PST__g__73
  {
    struct __PST__g__74 BIT;
    __PST__UINT32 UINT32;
  };
union __PST__g__81
  {
    __PST__g__203 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__81 __PST__g__80;
struct __PST__g__107
  {
    const __PST__UINT32 __pst_unused_field_0 : 24;
    const __PST__UINT32 __pst_unused_field_1 : 4;
    const __PST__UINT32 __pst_unused_field_2 : 2;
    const __PST__UINT32 FND : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
  };
typedef const struct __PST__g__107 __PST__g__106;
union __PST__g__105
  {
    __PST__g__106 BIT;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__105 __PST__g__104;
struct __PST__g__36
  {
    union __PST__g__37 TSPC;
    __PST__g__201 __pst_unused_field_1;
    __PST__g__202 __pst_unused_field_2;
    union __PST__g__45 _CC;
    union __PST__g__50 BRP;
    union __PST__g__54 IDE;
    union __PST__g__57 MDC;
    union __PST__g__60 SPCT;
    __PST__g__63 MST;
    __PST__g__68 CS;
    union __PST__g__73 CSC;
    __PST__g__201 __pst_unused_field_11;
    __PST__g__80 SRXD;
    __PST__g__201 __pst_unused_field_13;
    __PST__g__201 __pst_unused_field_14;
    __PST__g__201 __pst_unused_field_15;
    __PST__g__104 FRXD;
  };
typedef volatile struct __PST__g__36 __PST__g__35;
struct __PST__g__38
  {
    __PST__UINT32 __pst_unused_field_0 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 15;
  };
union __PST__g__42
  {
    __PST__g__203 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__43
  {
    __PST__UINT32 __pst_unused_field_0 : 32;
  };
typedef __PST__UINT8 __PST__g__44[8];
struct __PST__g__46
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 3;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 19;
  };
struct __PST__g__51
  {
    __PST__UINT32 __pst_unused_field_0 : 5;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 3;
    __PST__UINT32 __pst_unused_field_2 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_4 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_6 : 4;
    __PST__UINT32 __pst_unused_field_pstnonamef4 : 4;
  };
struct __PST__g__55
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 21;
  };
struct __PST__g__58
  {
    __PST__UINT32 __pst_unused_field_0 : 3;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
struct __PST__g__61
  {
    __PST__UINT32 __pst_unused_field_0 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 25;
  };
struct __PST__g__66
  {
    const __PST__UINT32 __pst_unused_field_0 : 3;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__66 __PST__g__65;
union __PST__g__76
  {
    __PST__g__203 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__76 __PST__g__75;
struct __PST__g__78
  {
    const __PST__UINT32 __pst_unused_field_0 : 32;
  };
typedef const struct __PST__g__78 __PST__g__77;
typedef const __PST__UINT32 __PST__g__79;
struct __PST__g__83
  {
    const __PST__UINT32 __pst_unused_field_0 : 20;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 3;
    const __PST__UINT32 __pst_unused_field_3 : 6;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
  };
typedef const struct __PST__g__83 __PST__g__82;
union __PST__g__89
  {
    __PST__g__203 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__89 __PST__g__88;
struct __PST__g__91
  {
    const __PST__UINT32 __pst_unused_field_0 : 17;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 15;
  };
typedef const struct __PST__g__91 __PST__g__90;
union __PST__g__95
  {
    __PST__g__203 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__95 __PST__g__94;
struct __PST__g__97
  {
    const __PST__UINT32 __pst_unused_field_0 : 21;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 11;
  };
typedef const struct __PST__g__97 __PST__g__96;
union __PST__g__101
  {
    __PST__g__203 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__101 __PST__g__100;
struct __PST__g__103
  {
    const __PST__UINT32 __pst_unused_field_0 : 32;
  };
typedef const struct __PST__g__103 __PST__g__102;
typedef __PST__VOID __PST__g__112(__PST__SINT32);
typedef __PST__UINT8 __PST__g__113(__PST__g__26);
typedef __PST__UINT8 __PST__g__114(__PST__FLOAT32);
typedef __PST__UINT8 __PST__g__115(__PST__UINT8);
typedef __PST__UINT8 __PST__g__116(__PST__g__17, __PST__UINT16);
typedef __PST__UINT8 __PST__g__117(__PST__g__19, __PST__UINT16);
typedef __PST__UINT8 __PST__g__118(__PST__UINT16, __PST__g__19);
typedef __PST__UINT8 __PST__g__119(__PST__g__31);
typedef __PST__UINT8 __PST__g__120(__PST__UINT32, __PST__g__31);
typedef __PST__UINT8 __PST__g__121(void);
typedef __PST__UINT8 __PST__g__122(__PST__UINT16, __PST__UINT8, __PST__UINT8, __PST__UINT16);
typedef __PST__UINT16 __PST__g__123(void);
typedef __PST__SINT32 __PST__g__124();
typedef __PST__FLOAT32 __PST__g__125(__PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32);
typedef const __PST__g__32 __PST__g__126;
typedef __PST__g__126 *__PST__g__127;
typedef const __PST__g__17 __PST__g__128;
typedef __PST__g__128 *__PST__g__129;
typedef __PST__g__115 *__PST__g__130;
typedef __PST__g__35 *__PST__g__131;
typedef volatile union __PST__g__57 __PST__g__132;
typedef __PST__g__132 *__PST__g__133;
typedef volatile __PST__UINT32 __PST__g__134;
typedef __PST__g__134 *__PST__g__135;
typedef __PST__g__119 *__PST__g__136;
typedef volatile __PST__g__63 __PST__g__137;
typedef __PST__g__137 *__PST__g__138;
typedef volatile __PST__g__79 __PST__g__139;
typedef __PST__g__139 *__PST__g__140;
typedef __PST__g__120 *__PST__g__141;
typedef volatile union __PST__g__37 __PST__g__142;
typedef __PST__g__142 *__PST__g__143;
typedef volatile union __PST__g__45 __PST__g__144;
typedef __PST__g__144 *__PST__g__145;
typedef volatile union __PST__g__50 __PST__g__146;
typedef __PST__g__146 *__PST__g__147;
typedef volatile union __PST__g__54 __PST__g__148;
typedef __PST__g__148 *__PST__g__149;
typedef volatile union __PST__g__60 __PST__g__150;
typedef __PST__g__150 *__PST__g__151;
typedef __PST__g__121 *__PST__g__152;
typedef __PST__g__113 *__PST__g__153;
typedef volatile __PST__g__68 __PST__g__154;
typedef __PST__g__154 *__PST__g__155;
typedef volatile __PST__g__104 __PST__g__156;
typedef __PST__g__156 *__PST__g__157;
typedef __PST__g__117 *__PST__g__158;
typedef const __PST__g__19 __PST__g__159;
typedef __PST__g__159 *__PST__g__160;
typedef const __PST__g__31 __PST__g__161;
typedef __PST__g__161 *__PST__g__162;
typedef __PST__g__125 *__PST__g__163;
typedef __PST__g__116 *__PST__g__164;
typedef __PST__g__122 *__PST__g__165;
typedef __PST__g__123 *__PST__g__166;
typedef __PST__g__118 *__PST__g__167;
typedef __PST__g__112 *__PST__g__168;
typedef __PST__VOID __PST__g__169(__PST__UINT32, __PST__UINT32);
typedef __PST__g__169 *__PST__g__170;
typedef volatile union __PST__g__73 __PST__g__171;
typedef __PST__g__171 *__PST__g__172;
typedef __PST__UINT32 __PST__g__173(__PST__g__134);
typedef __PST__g__173 *__PST__g__174;
typedef volatile __PST__g__106 __PST__g__175;
typedef __PST__g__175 *__PST__g__176;
typedef volatile __PST__g__70 __PST__g__179;
typedef __PST__g__179 *__PST__g__180;
typedef __PST__g__114 *__PST__g__181;
typedef __PST__g__124 *__PST__g__182;
typedef volatile struct __PST__g__74 __PST__g__183;
typedef __PST__g__183 *__PST__g__184;
typedef volatile __PST__g__80 __PST__g__187;
typedef __PST__g__187 *__PST__g__188;
typedef volatile __PST__SINT32 __PST__g__189;
typedef __PST__SINT8 __PST__g__195(void);
typedef volatile __PST__SINT8 __PST__g__196;
typedef volatile __PST__UINT8 __PST__g__197;
typedef __PST__SINT32 __PST__g__198(void);
typedef __PST__UINT32 __PST__g__199(void);
typedef __PST__SINT32 __PST__g__200(void);
