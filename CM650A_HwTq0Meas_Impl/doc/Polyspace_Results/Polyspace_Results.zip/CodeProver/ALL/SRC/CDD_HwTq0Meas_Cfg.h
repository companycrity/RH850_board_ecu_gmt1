
#ifndef CDD_HWTQ0MEAS_CFG_H     /* Multiple include preventer */
#define CDD_HWTQ0MEAS_CFG_H

#include "Rte_CDD_HwTq0Meas.h"

#define HWTQ0MEAS_HWTQ0MFGNTCNR_ULS_U16                 NTCNR_0X1E0
#define HWTQ0MEAS_HWTQ0PRTCLNTCNR_ULS_U16               NTCNR_0X073


#endif
