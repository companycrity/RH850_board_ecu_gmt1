
#ifndef FLTINJ_H
#define FLTINJ_H

/* Fault Injection Command */
#define FLTINJ_STABYCMP_ASSICMD         (7U)

#endif
