/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Rte_Read_GmStrtStop_EngSpd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_GmStrtStop_EngSpd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmStrtStop_EngSpd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_GmStrtStop_EngSpd_Val"
//
// __PST__UINT8 Rte_Read_GmStrtStop_EngSpd_Val(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmStrtStop_HwTq_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_GmStrtStop_HwTq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmStrtStop_HwTq_Val"
// #pragma POLYSPACE_WORST "Rte_Read_GmStrtStop_HwTq_Val"
//
// __PST__UINT8 Rte_Read_GmStrtStop_HwTq_Val(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmStrtStop_HwVel_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_GmStrtStop_HwVel_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmStrtStop_HwVel_Val"
// #pragma POLYSPACE_WORST "Rte_Read_GmStrtStop_HwVel_Val"
//
// __PST__UINT8 Rte_Read_GmStrtStop_HwVel_Val(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmStrtStop_Msg0C9BusHiSpdInvld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmStrtStop_Msg0C9BusHiSpdInvld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmStrtStop_Msg0C9BusHiSpdInvld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmStrtStop_Msg0C9BusHiSpdInvld_Logl"
//
// __PST__UINT8 Rte_Read_GmStrtStop_Msg0C9BusHiSpdInvld_Logl(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmStrtStop_Msg0C9BusHiSpdMiss_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmStrtStop_Msg0C9BusHiSpdMiss_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmStrtStop_Msg0C9BusHiSpdMiss_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmStrtStop_Msg0C9BusHiSpdMiss_Logl"
//
// __PST__UINT8 Rte_Read_GmStrtStop_Msg0C9BusHiSpdMiss_Logl(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmStrtStop_VehSpd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_GmStrtStop_VehSpd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmStrtStop_VehSpd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_GmStrtStop_VehSpd_Val"
//
// __PST__UINT8 Rte_Read_GmStrtStop_VehSpd_Val(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GmStrtStop_VehSpdVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GmStrtStop_VehSpdVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GmStrtStop_VehSpdVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GmStrtStop_VehSpdVld_Logl"
//
// __PST__UINT8 Rte_Read_GmStrtStop_VehSpdVld_Logl(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_GmStrtStop_VehStrtStopMotTqCmdSca_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_GmStrtStop_VehStrtStopMotTqCmdSca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_GmStrtStop_VehStrtStopMotTqCmdSca_Val"
// #pragma POLYSPACE_WORST "Rte_Write_GmStrtStop_VehStrtStopMotTqCmdSca_Val"
//
// __PST__UINT8 Rte_Write_GmStrtStop_VehStrtStopMotTqCmdSca_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_GmStrtStop_VehStrtStopRampRate_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_GmStrtStop_VehStrtStopRampRate_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_GmStrtStop_VehStrtStopRampRate_Val"
// #pragma POLYSPACE_WORST "Rte_Write_GmStrtStop_VehStrtStopRampRate_Val"
//
// __PST__UINT8 Rte_Write_GmStrtStop_VehStrtStopRampRate_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_GmStrtStop_VehStrtStopSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_GmStrtStop_VehStrtStopSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_GmStrtStop_VehStrtStopSt_Val"
// #pragma POLYSPACE_WORST "Rte_Write_GmStrtStop_VehStrtStopSt_Val"
//
// __PST__UINT8 Rte_Write_GmStrtStop_VehStrtStopSt_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_GmStrtStop_GetRefTmr100MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_GmStrtStop_GetRefTmr100MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_GmStrtStop_GetRefTmr100MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_GmStrtStop_GetRefTmr100MicroSec32bit_Oper"
//
// __PST__UINT8 Rte_Call_GmStrtStop_GetRefTmr100MicroSec32bit_Oper(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_GmStrtStop_GetTiSpan100MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_GmStrtStop_GetTiSpan100MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_GmStrtStop_GetTiSpan100MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_GmStrtStop_GetTiSpan100MicroSec32bit_Oper"
//
// __PST__UINT8 Rte_Call_GmStrtStop_GetTiSpan100MicroSec32bit_Oper(__PST__UINT32 P_0, __PST__g__26 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopFltRateLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopFltRateLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopFltRateLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopFltRateLim_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopFltRateLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopMod1EngTranThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopMod1EngTranThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopMod1EngTranThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopMod1EngTranThd_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopMod1EngTranThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopMod1Sca_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopMod1Sca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopMod1Sca_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopMod1Sca_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopMod1Sca_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopMod1ToStopRateLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopMod1ToStopRateLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopMod1ToStopRateLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopMod1ToStopRateLim_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopMod1ToStopRateLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopMod1VehSpdTranThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopMod1VehSpdTranThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopMod1VehSpdTranThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopMod1VehSpdTranThd_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopMod1VehSpdTranThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopMod2Sca_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopMod2Sca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopMod2Sca_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopMod2Sca_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopMod2Sca_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopNormModEngTranThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopNormModEngTranThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopNormModEngTranThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopNormModEngTranThd_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopNormModEngTranThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopNormModVehSpdTranThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopNormModVehSpdTranThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopNormModVehSpdTranThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopNormModVehSpdTranThd_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopNormModVehSpdTranThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopNormRateLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopNormRateLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopNormRateLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopNormRateLim_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopNormRateLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopNormToMod1RateLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopNormToMod1RateLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopNormToMod1RateLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopNormToMod1RateLim_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopNormToMod1RateLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopStopAndMod2RateLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopStopAndMod2RateLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopStopAndMod2RateLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopStopAndMod2RateLim_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopStopAndMod2RateLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopStopMod1HwTqTranThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopStopMod1HwTqTranThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopStopMod1HwTqTranThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopStopMod1HwTqTranThd_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopStopMod1HwTqTranThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopStopMod1HwVelTranThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopStopMod1HwVelTranThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopStopMod1HwVelTranThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopStopMod1HwVelTranThd_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopStopMod1HwVelTranThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopStopMod1Tmr_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopStopMod1Tmr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopStopMod1Tmr_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopStopMod1Tmr_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopStopMod1Tmr_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopStopMod1VehSpdTranThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopStopMod1VehSpdTranThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopStopMod1VehSpdTranThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopStopMod1VehSpdTranThd_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopStopMod1VehSpdTranThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopStopMod2HwTqTranThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopStopMod2HwTqTranThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopStopMod2HwTqTranThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopStopMod2HwTqTranThd_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopStopMod2HwTqTranThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopStopMod2HwVelTranThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopStopMod2HwVelTranThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopStopMod2HwVelTranThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopStopMod2HwVelTranThd_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopStopMod2HwVelTranThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopStopMod2Tmr_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopStopMod2Tmr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopStopMod2Tmr_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopStopMod2Tmr_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopStopMod2Tmr_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopStopMod2VehSpdTranThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopStopMod2VehSpdTranThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopStopMod2VehSpdTranThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopStopMod2VehSpdTranThd_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopStopMod2VehSpdTranThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopStopModSca_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopStopModSca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopStopModSca_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopStopModSca_Val"
//
// __PST__FLOAT32 Rte_Prm_GmStrtStop_GmStrtStopStopModSca_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GmStrtStop_GmStrtStopEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_GmStrtStop_GmStrtStopEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GmStrtStop_GmStrtStopEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_GmStrtStop_GmStrtStopEna_Logl"
//
// __PST__UINT8 Rte_Prm_GmStrtStop_GmStrtStopEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function fabsf
//
// #pragma POLYSPACE_PURE "fabsf"
// #pragma POLYSPACE_CLEAN "fabsf"
// #pragma POLYSPACE_WORST "fabsf"
//
// __PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
// {
//    ...
// }

