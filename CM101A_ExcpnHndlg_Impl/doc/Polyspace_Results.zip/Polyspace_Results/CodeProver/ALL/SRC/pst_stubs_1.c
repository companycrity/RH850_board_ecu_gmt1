#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__519 _main_gen_init_g519(void);

extern struct __PST__g__517 _main_gen_init_g517(void);

extern __PST__g__513 _main_gen_init_g513(void);

extern union __PST__g__416 _main_gen_init_g416(void);

extern union __PST__g__406 _main_gen_init_g406(void);

extern __PST__g__392 _main_gen_init_g392(void);

extern union __PST__g__387 _main_gen_init_g387(void);

extern struct __PST__g__385 _main_gen_init_g385(void);

extern union __PST__g__383 _main_gen_init_g383(void);

extern __PST__g__360 _main_gen_init_g360(void);

extern union __PST__g__351 _main_gen_init_g351(void);

extern union __PST__g__346 _main_gen_init_g346(void);

extern __PST__g__330 _main_gen_init_g330(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern union __PST__g__326 _main_gen_init_g326(void);

extern __PST__g__322 _main_gen_init_g322(void);

extern union __PST__g__312 _main_gen_init_g312(void);

extern union __PST__g__310 _main_gen_init_g310(void);

extern __PST__g__308 _main_gen_init_g308(void);

extern union __PST__g__146 _main_gen_init_g146(void);

extern struct __PST__g__139 _main_gen_init_g139(void);

extern union __PST__g__137 _main_gen_init_g137(void);

extern struct __PST__g__132 _main_gen_init_g132(void);

extern union __PST__g__130 _main_gen_init_g130(void);

extern __PST__g__103 _main_gen_init_g103(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern union __PST__g__79 _main_gen_init_g79(void);

extern union __PST__g__76 _main_gen_init_g76(void);

extern union __PST__g__74 _main_gen_init_g74(void);

extern union __PST__g__72 _main_gen_init_g72(void);

extern __PST__g__51 _main_gen_init_g51(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct __PST__g__40 _main_gen_init_g40(void);

extern union __PST__g__38 _main_gen_init_g38(void);

extern __PST__g__28 _main_gen_init_g28(void);

struct __PST__g__40 _main_gen_init_g40(void)
{
    static struct __PST__g__40 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.SSE001 = bitf;
    }
    return x;
}

union __PST__g__38 _main_gen_init_g38(void)
{
    static union __PST__g__38 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g40();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* struct/union type */
    x.ESSTR0 = _main_gen_init_g38();
    return x;
}

union __PST__g__72 _main_gen_init_g72(void)
{
    static union __PST__g__72 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__74 _main_gen_init_g74(void)
{
    static union __PST__g__74 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__76 _main_gen_init_g76(void)
{
    static union __PST__g__76 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__79 _main_gen_init_g79(void)
{
    static union __PST__g__79 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__51 _main_gen_init_g51(void)
{
    __PST__g__51 x;
    /* struct/union type */
    x.ESSTC0 = _main_gen_init_g72();
    x.ESSTC1 = _main_gen_init_g74();
    x.PCMD1 = _main_gen_init_g76();
    x.PS = _main_gen_init_g79();
    return x;
}

struct __PST__g__132 _main_gen_init_g132(void)
{
    static struct __PST__g__132 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.DEBUGMODE = bitf;
    }
    return x;
}

union __PST__g__130 _main_gen_init_g130(void)
{
    static union __PST__g__130 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g132();
    return x;
}

struct __PST__g__139 _main_gen_init_g139(void)
{
    static struct __PST__g__139 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.DEBUGMODEB = bitf;
    }
    return x;
}

union __PST__g__137 _main_gen_init_g137(void)
{
    static union __PST__g__137 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g139();
    return x;
}

union __PST__g__146 _main_gen_init_g146(void)
{
    static union __PST__g__146 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__103 _main_gen_init_g103(void)
{
    __PST__g__103 x;
    /* struct/union type */
    x.BSEQ0ST = _main_gen_init_g130();
    x.BSEQ0STB = _main_gen_init_g137();
    x.RESFC = _main_gen_init_g146();
    return x;
}

union __PST__g__310 _main_gen_init_g310(void)
{
    static union __PST__g__310 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__312 _main_gen_init_g312(void)
{
    static union __PST__g__312 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__308 _main_gen_init_g308(void)
{
    __PST__g__308 x;
    /* struct/union type */
    x.DAT0 = _main_gen_init_g310();
    x.DAT1 = _main_gen_init_g312();
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

union __PST__g__326 _main_gen_init_g326(void)
{
    static union __PST__g__326 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

__PST__g__322 _main_gen_init_g322(void)
{
    __PST__g__322 x;
    /* struct/union type */
    x.FLAG = _main_gen_init_g326();
    return x;
}

union __PST__g__346 _main_gen_init_g346(void)
{
    static union __PST__g__346 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__351 _main_gen_init_g351(void)
{
    static union __PST__g__351 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__330 _main_gen_init_g330(void)
{
    __PST__g__330 x;
    /* struct/union type */
    x.CF1STERSTR_VCI = _main_gen_init_g346();
    x.CF1STEADR0_VCI = _main_gen_init_g351();
    x.CF1STERSTR_PE1 = _main_gen_init_g346();
    x.CF1STEADR0_PE1 = _main_gen_init_g351();
    return x;
}

struct __PST__g__385 _main_gen_init_g385(void)
{
    static struct __PST__g__385 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.DEDF0 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.DEDF1 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.DEDF2 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.DEDF3 = bitf;
    }
    return x;
}

union __PST__g__383 _main_gen_init_g383(void)
{
    static union __PST__g__383 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g385();
    return x;
}

union __PST__g__387 _main_gen_init_g387(void)
{
    static union __PST__g__387 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__360 _main_gen_init_g360(void)
{
    __PST__g__360 x;
    /* struct/union type */
    x.LR1STERSTR_PE1 = _main_gen_init_g383();
    x.LR1STEADR0_PE1 = _main_gen_init_g387();
    x.LR1STEADR1_PE1 = _main_gen_init_g387();
    x.LR1STEADR2_PE1 = _main_gen_init_g387();
    x.LR1STEADR3_PE1 = _main_gen_init_g387();
    return x;
}

union __PST__g__406 _main_gen_init_g406(void)
{
    static union __PST__g__406 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__416 _main_gen_init_g416(void)
{
    static union __PST__g__416 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__392 _main_gen_init_g392(void)
{
    __PST__g__392 x;
    /* struct/union type */
    x.DMACER = _main_gen_init_g406();
    x.DTSER2 = _main_gen_init_g416();
    return x;
}

struct __PST__g__519 _main_gen_init_g519(void)
{
    static struct __PST__g__519 x;
    /* struct/union type */
    x.FailedSupervisionRefCycles = _main_gen_init_g7();
    x.DeadlineViolationCnt = _main_gen_init_g7();
    x.ProgramFlowViolationCnt = _main_gen_init_g7();
    return x;
}

struct __PST__g__517 _main_gen_init_g517(void)
{
    static struct __PST__g__517 x;
    /* struct/union type */
    /* pointer */
    {
        static struct __PST__g__519 _main_gen_tmp_6[ARRAY_NBELEM(struct __PST__g__519)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(struct __PST__g__519); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g519();
        }
        x.EntityStatusGRef = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(struct __PST__g__519) / 2];
    }
    return x;
}

__PST__g__513 _main_gen_init_g513(void)
{
    __PST__g__513 x;
    /* struct/union type */
    /* pointer */
    {
        static struct __PST__g__517 _main_gen_tmp_4[ARRAY_NBELEM(struct __PST__g__517)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(struct __PST__g__517); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g517();
        }
        x.WdgMSupervisedEntityRef = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(struct __PST__g__517) / 2];
    }
    x.NrOfSupervisedEntities = _main_gen_init_g6();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_ECMM(void)
{
    extern __PST__g__28 ECMM;
    
    /* initialization with random value */
    {
        ECMM = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ECMC(void)
{
    extern __PST__g__28 ECMC;
    
    /* initialization with random value */
    {
        ECMC = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ECM(void)
{
    extern __PST__g__51 ECM;
    
    /* initialization with random value */
    {
        ECM = _main_gen_init_g51();
    }
}

static void _main_gen_init_sym_SYS(void)
{
    extern __PST__g__103 SYS;
    
    /* initialization with random value */
    {
        SYS = _main_gen_init_g103();
    }
}

static void _main_gen_init_sym_BRAM(void)
{
    extern __PST__g__308 BRAM;
    
    /* initialization with random value */
    {
        BRAM = _main_gen_init_g308();
    }
}

static void _main_gen_init_sym_SEG(void)
{
    extern __PST__g__322 SEG;
    
    /* initialization with random value */
    {
        SEG = _main_gen_init_g322();
    }
}

static void _main_gen_init_sym_ECCFLI(void)
{
    extern __PST__g__330 ECCFLI;
    
    /* initialization with random value */
    {
        ECCFLI = _main_gen_init_g330();
    }
}

static void _main_gen_init_sym_ECCCPU1(void)
{
    extern __PST__g__360 ECCCPU1;
    
    /* initialization with random value */
    {
        ECCCPU1 = _main_gen_init_g360();
    }
}

static void _main_gen_init_sym_DMASS(void)
{
    extern __PST__g__392 DMASS;
    
    /* initialization with random value */
    {
        DMASS = _main_gen_init_g392();
    }
}

static void _main_gen_init_sym_WdgMConfig_Mode0(void)
{
    extern __PST__g__513 WdgMConfig_Mode0;
    
    /* initialization with random value */
    {
        WdgMConfig_Mode0 = _main_gen_init_g513();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable ECMM */
    _main_gen_init_sym_ECMM();
    
    /* init for variable ECMC */
    _main_gen_init_sym_ECMC();
    
    /* init for variable ECM */
    _main_gen_init_sym_ECM();
    
    /* init for variable SYS */
    _main_gen_init_sym_SYS();
    
    /* init for variable BRAM */
    _main_gen_init_sym_BRAM();
    
    /* init for variable SEG */
    _main_gen_init_sym_SEG();
    
    /* init for variable ECCFLI */
    _main_gen_init_sym_ECCFLI();
    
    /* init for variable ECCCPU1 */
    _main_gen_init_sym_ECCCPU1();
    
    /* init for variable DMASS */
    _main_gen_init_sym_DMASS();
    
    /* init for variable WdgMConfig_Mode0 */
    _main_gen_init_sym_WdgMConfig_Mode0();
    
}
