/*** for CM101A contract folder                                       ***/


#ifndef _WdgM_PBcfg_h_
#define _WdgM_PBcfg_h_ 1

extern const WdgM_ConfigType WdgMConfig_Mode0;

#endif /* _WdgM_PBcfg_h_ */

