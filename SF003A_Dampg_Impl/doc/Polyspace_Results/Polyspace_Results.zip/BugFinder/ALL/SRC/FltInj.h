
#ifndef FLTINJ_H
#define FLTINJ_H

/* Fault Injection Assist Command */
#define FLTINJ_DAMPG_DAMPGCMDBAS                (3U)

#endif
