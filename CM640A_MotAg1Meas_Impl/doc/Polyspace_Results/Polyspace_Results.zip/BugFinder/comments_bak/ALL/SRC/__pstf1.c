/**********************************************************************************************************************
* Copyright 2015 Nexteer 
* Nexteer Confidential
*
* Module File Name  : CDD_MotAg1Meas.h
* Module Description: CSIH3 peripheral configuration and motor Angle 1 measurement Complex Driver Header
* Project           : CBD
* Author            : Rijvi Ahmed
***********************************************************************************************************************
* Version Control:
* %version:          1 %
* %derived_by:       jzk9cc %
*----------------------------------------------------------------------------------------------------------------------
* Date      Rev      Author         Change Description                                                           SCR #
* -------   -------  --------  ---------------------------------------------------------------------------     --------
* 07/09/15      1        Rijvi                  initial version                                                                                     EA4#849
**********************************************************************************************************************/

/******************************************* Multiple Include Protection *********************************************/
#ifndef CDD_MOTAG1MEAS_H
#define CDD_MOTAG1MEAS_H


/************************************************ Include Statements *************************************************/
#include "Std_Types.h"

#define  MOTAG1MEAS_MOTAG1TRSMSTRTININ_CNT_U32  ((uint32)2147680256u)  /* Used in DMA */



/******************************************** File Level Rule Deviations *********************************************/


/*********************************************** Exported Declarations ***********************************************/

extern FUNC (void, CDD_MotAg1Meas_CODE) MotAg1MeasPer1 (void);


/**************************************** End Of Multiple Include Protection *****************************************/
#endif

