/* Header file for contract folder of CM640A */

#ifndef CDD_MOTAG1MEAS_CFG_H    /* Multiple include preventer */
#define CDD_MOTAG1MEAS_CFG_H

#include "Rte_CDD_MotAg1Meas.h"

#define MOTAG1MEAS_MOTAG1PRTCLFLTNTCNR_CNT_ENUM                 NTCNR_0X085 


#endif
