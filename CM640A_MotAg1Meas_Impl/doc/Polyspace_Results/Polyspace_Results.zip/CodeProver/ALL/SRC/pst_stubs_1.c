#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__SINT8 _main_gen_init_g2(void);

extern struct __PST__g__105 _main_gen_init_g105(void);

extern union __PST__g__104 _main_gen_init_g104(void);

extern union __PST__g__95 _main_gen_init_g95(void);

extern union __PST__g__84 _main_gen_init_g84(void);

extern union __PST__g__81 _main_gen_init_g81(void);

extern union __PST__g__68 _main_gen_init_g68(void);

extern union __PST__g__62 _main_gen_init_g62(void);

extern union __PST__g__59 _main_gen_init_g59(void);

extern union __PST__g__56 _main_gen_init_g56(void);

extern union __PST__g__52 _main_gen_init_g52(void);

extern struct __PST__g__41 _main_gen_init_g41(void);

extern union __PST__g__40 _main_gen_init_g40(void);

extern __PST__g__38 _main_gen_init_g38(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern struct Rte_CDS_CDD_MotAg1Meas _main_gen_init_g30(void);

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

struct Rte_CDS_CDD_MotAg1Meas _main_gen_init_g30(void)
{
    static struct Rte_CDS_CDD_MotAg1Meas x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__g__32 _main_gen_tmp_6[ARRAY_NBELEM(__PST__g__32)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__g__32); _i_main_gen_tmp_7++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_8_0;
                
                for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 26; _main_gen_tmp_8_0++)
                {
                    /* base type */
                    _main_gen_tmp_6[_i_main_gen_tmp_7][_main_gen_tmp_8_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_MotAg1CoeffTbl = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__g__32) / 2];
    }
    /* pointer */
    {
        static __PST__g__34 _main_gen_tmp_9[ARRAY_NBELEM(__PST__g__34)];
        __PST__UINT32 _i_main_gen_tmp_10;
        for (_i_main_gen_tmp_10 = 0; _i_main_gen_tmp_10 < ARRAY_NBELEM(__PST__g__34); _i_main_gen_tmp_10++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_11_0;
                
                for (_main_gen_tmp_11_0 = 0; _main_gen_tmp_11_0 < 128; _main_gen_tmp_11_0++)
                {
                    /* base type */
                    _main_gen_tmp_9[_i_main_gen_tmp_10][_main_gen_tmp_11_0] = pst_random_g_2;
                }
            }
        }
        x.Pim_MotAg1CorrnTbl = PST_TRUE() ? 0 : &_main_gen_tmp_9[ARRAY_NBELEM(__PST__g__34) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g7();
        }
        x.Pim_MotAg1ErrParFltCntPrev = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g7();
        }
        x.Pim_MotAg1ErrParFltNtcStInfoCntPrev = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g6();
        }
        x.Pim_MotAg1ErrPrev = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_18[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g6();
        }
        x.Pim_MotAg1MeclRollgCntrPrev = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_20[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g7();
        }
        x.Pim_MotAg1ParFltCntPrev = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g7();
        }
        x.Pim_MotAg1ParFltNtcStInfoCntPrev = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_25;
        for (_i_main_gen_tmp_25 = 0; _i_main_gen_tmp_25 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_25++)
        {
            _main_gen_tmp_24[_i_main_gen_tmp_25] = _main_gen_init_g7();
        }
        x.Pim_MotAg1RawMeclPrev = PST_TRUE() ? 0 : &_main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_27;
        for (_i_main_gen_tmp_27 = 0; _i_main_gen_tmp_27 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_27++)
        {
            _main_gen_tmp_26[_i_main_gen_tmp_27] = _main_gen_init_g7();
        }
        x.Pim_MotAg1VltgFltCntPrev = PST_TRUE() ? 0 : &_main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_28[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_29;
        for (_i_main_gen_tmp_29 = 0; _i_main_gen_tmp_29 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_29++)
        {
            _main_gen_tmp_28[_i_main_gen_tmp_29] = _main_gen_init_g7();
        }
        x.Pim_MotAg1VltgFltNtcStInfoCntPrev = PST_TRUE() ? 0 : &_main_gen_tmp_28[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_30[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_31;
        for (_i_main_gen_tmp_31 = 0; _i_main_gen_tmp_31 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_31++)
        {
            _main_gen_tmp_30[_i_main_gen_tmp_31] = _main_gen_init_g8();
        }
        x.Pim_dMotAg1MeasMotAg1RawAgReg = PST_TRUE() ? 0 : &_main_gen_tmp_30[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_32[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_33;
        for (_i_main_gen_tmp_33 = 0; _i_main_gen_tmp_33 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_33++)
        {
            _main_gen_tmp_32[_i_main_gen_tmp_33] = _main_gen_init_g8();
        }
        x.Pim_dMotAg1MeasMotAg1RawErrReg = PST_TRUE() ? 0 : &_main_gen_tmp_32[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_34[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_35;
        for (_i_main_gen_tmp_35 = 0; _i_main_gen_tmp_35 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_35++)
        {
            _main_gen_tmp_34[_i_main_gen_tmp_35] = _main_gen_init_g8();
        }
        x.Pim_dMotAg1MeasMotAg1RawTurnCntrReg = PST_TRUE() ? 0 : &_main_gen_tmp_34[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    return x;
}

struct __PST__g__41 _main_gen_init_g41(void)
{
    static struct __PST__g__41 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.PWR = bitf;
    }
    return x;
}

union __PST__g__40 _main_gen_init_g40(void)
{
    static union __PST__g__40 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g41();
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__52 _main_gen_init_g52(void)
{
    static union __PST__g__52 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__56 _main_gen_init_g56(void)
{
    static union __PST__g__56 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__59 _main_gen_init_g59(void)
{
    static union __PST__g__59 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__62 _main_gen_init_g62(void)
{
    static union __PST__g__62 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__68 _main_gen_init_g68(void)
{
    static union __PST__g__68 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__81 _main_gen_init_g81(void)
{
    static union __PST__g__81 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__84 _main_gen_init_g84(void)
{
    static union __PST__g__84 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__95 _main_gen_init_g95(void)
{
    static union __PST__g__95 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__105 _main_gen_init_g105(void)
{
    static struct __PST__g__105 x;
    /* struct/union type */
    {
        __PST__UINT16 bitf;
        bitf = _main_gen_init_g7();
        unchecked_assert(bitf <= 4095);
        x.BRS = bitf;
    }
    return x;
}

union __PST__g__104 _main_gen_init_g104(void)
{
    static union __PST__g__104 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g105();
    return x;
}

__PST__g__38 _main_gen_init_g38(void)
{
    __PST__g__38 x;
    /* struct/union type */
    x.CTL0 = _main_gen_init_g40();
    x.STCR0 = _main_gen_init_g52();
    x.CTL1 = _main_gen_init_g56();
    x.CTL2 = _main_gen_init_g59();
    x.MCTL1 = _main_gen_init_g62();
    x.TX0W = _main_gen_init_g68();
    x.MRWP0 = _main_gen_init_g81();
    x.MCTL0 = _main_gen_init_g84();
    x.CFG4 = _main_gen_init_g95();
    x.BRS0 = _main_gen_init_g104();
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_MotAg1Meas(void)
{
    extern __PST__g__27 Rte_Inst_CDD_MotAg1Meas;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_MotAg1Meas _main_gen_tmp_4[ARRAY_NBELEM(struct Rte_CDS_CDD_MotAg1Meas)];
            __PST__UINT32 _i_main_gen_tmp_5;
            for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(struct Rte_CDS_CDD_MotAg1Meas); _i_main_gen_tmp_5++)
            {
                _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g30();
            }
            Rte_Inst_CDD_MotAg1Meas = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(struct Rte_CDS_CDD_MotAg1Meas) / 2];
        }
    }
}

static void _main_gen_init_sym_CSIH3(void)
{
    extern __PST__g__38 CSIH3;
    
    /* initialization with random value */
    {
        CSIH3 = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg1RawRes(void)
{
    extern __PST__g__116 MOTCTRLMGR_MotCtrlMotAg1RawRes;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_36_0;
            
            for (_main_gen_tmp_36_0 = 0; _main_gen_tmp_36_0 < 3; _main_gen_tmp_36_0++)
            {
                /* base type */
                MOTCTRLMGR_MotCtrlMotAg1RawRes[_main_gen_tmp_36_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgMecl1Polarity(void)
{
    extern __PST__SINT8 MOTCTRLMGR_MotCtrlMotAgMecl1Polarity;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAgMecl1Polarity = _main_gen_init_g2();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_CDD_MotAg1Meas */
    _main_gen_init_sym_Rte_Inst_CDD_MotAg1Meas();
    
    /* init for variable CSIH3 */
    _main_gen_init_sym_CSIH3();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg1RawRes */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg1RawRes();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgMecl1Polarity */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgMecl1Polarity();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg1ErrReg : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg1ParFltCnt : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg1VltgFltCnt : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg1Mecl : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg1MeclRollgCntr : useless (never read) */

}
