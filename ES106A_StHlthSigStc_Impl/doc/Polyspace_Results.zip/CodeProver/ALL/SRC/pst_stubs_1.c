#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__31 _main_gen_init_g31(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct Rte_CDS_StHlthSigStc _main_gen_init_g44(void);

struct Rte_CDS_StHlthSigStc _main_gen_init_g44(void)
{
    static struct Rte_CDS_StHlthSigStc x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__g__46 _main_gen_tmp_10[ARRAY_NBELEM(__PST__g__46)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__g__46); _i_main_gen_tmp_11++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_12_0;
                
                for (_main_gen_tmp_12_0 = 0; _main_gen_tmp_12_0 < 22; _main_gen_tmp_12_0++)
                {
                    /* base type */
                    _main_gen_tmp_10[_i_main_gen_tmp_11][_main_gen_tmp_12_0] = pst_random_g_8;
                }
            }
        }
        x.Pim_IgnCycSampleCntrAry = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__g__46) / 2];
    }
    /* pointer */
    {
        static __PST__g__48 _main_gen_tmp_13[ARRAY_NBELEM(__PST__g__48)];
        __PST__UINT32 _i_main_gen_tmp_14;
        for (_i_main_gen_tmp_14 = 0; _i_main_gen_tmp_14 < ARRAY_NBELEM(__PST__g__48); _i_main_gen_tmp_14++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_15_0;
                
                for (_main_gen_tmp_15_0 = 0; _main_gen_tmp_15_0 < 66; _main_gen_tmp_15_0++)
                {
                    /* base type */
                    _main_gen_tmp_13[_i_main_gen_tmp_14][_main_gen_tmp_15_0] = pst_random_g_6;
                }
            }
        }
        x.Pim_RamBuf = PST_TRUE() ? 0 : &_main_gen_tmp_13[ARRAY_NBELEM(__PST__g__48) / 2];
    }
    /* pointer */
    {
        static __PST__g__50 _main_gen_tmp_16[ARRAY_NBELEM(__PST__g__50)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__g__50); _i_main_gen_tmp_17++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_18_0;
                
                for (_main_gen_tmp_18_0 = 0; _main_gen_tmp_18_0 < 22; _main_gen_tmp_18_0++)
                {
                    /* base type */
                    _main_gen_tmp_16[_i_main_gen_tmp_17][_main_gen_tmp_18_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_SigAvrgBuf = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__g__50) / 2];
    }
    /* pointer */
    {
        static __PST__g__52 _main_gen_tmp_19[ARRAY_NBELEM(__PST__g__52)];
        __PST__UINT32 _i_main_gen_tmp_20;
        for (_i_main_gen_tmp_20 = 0; _i_main_gen_tmp_20 < ARRAY_NBELEM(__PST__g__52); _i_main_gen_tmp_20++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_21_0;
                
                for (_main_gen_tmp_21_0 = 0; _main_gen_tmp_21_0 < 225; _main_gen_tmp_21_0++)
                {
                    /* base type */
                    _main_gen_tmp_19[_i_main_gen_tmp_20][_main_gen_tmp_21_0] = pst_random_g_6;
                }
            }
        }
        x.Pim_SigStcHistDataAry = PST_TRUE() ? 0 : &_main_gen_tmp_19[ARRAY_NBELEM(__PST__g__52) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g6();
        }
        x.Pim_VldNvm = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    return x;
}

__PST__g__31 _main_gen_init_g31(void)
{
    __PST__g__31 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_StHlthSigStc(void)
{
    extern __PST__g__41 Rte_Inst_StHlthSigStc;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_StHlthSigStc _main_gen_tmp_8[ARRAY_NBELEM(struct Rte_CDS_StHlthSigStc)];
            __PST__UINT32 _i_main_gen_tmp_9;
            for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(struct Rte_CDS_StHlthSigStc); _i_main_gen_tmp_9++)
            {
                _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g44();
            }
            Rte_Inst_StHlthSigStc = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(struct Rte_CDS_StHlthSigStc) / 2];
        }
    }
}

static void _main_gen_init_sym_CCT_Range_01_Address(void)
{
    extern __PST__g__31 CCT_Range_01_Address;
    
    /* initialization with random value */
    {
        CCT_Range_01_Address = _main_gen_init_g31();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_StHlthSigStc */
    _main_gen_init_sym_Rte_Inst_StHlthSigStc();
    
    /* init for variable CCT_Range_01_Address */
    _main_gen_init_sym_CCT_Range_01_Address();
    
}
