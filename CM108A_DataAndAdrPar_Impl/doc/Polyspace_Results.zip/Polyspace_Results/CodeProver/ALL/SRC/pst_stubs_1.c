#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern union __PST__g__147 _main_gen_init_g147(void);

extern __PST__g__127 _main_gen_init_g127(void);

extern union __PST__g__115 _main_gen_init_g115(void);

extern union __PST__g__113 _main_gen_init_g113(void);

extern union __PST__g__110 _main_gen_init_g110(void);

extern __PST__g__107 _main_gen_init_g107(void);

extern struct __PST__g__103 _main_gen_init_g103(void);

extern union __PST__g__102 _main_gen_init_g102(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern struct __PST__g__101 _main_gen_init_g101(void);

extern union __PST__g__100 _main_gen_init_g100(void);

extern __PST__g__98 _main_gen_init_g98(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern union __PST__g__74 _main_gen_init_g74(void);

extern union __PST__g__71 _main_gen_init_g71(void);

extern union __PST__g__67 _main_gen_init_g67(void);

extern union __PST__g__63 _main_gen_init_g63(void);

extern __PST__g__46 _main_gen_init_g46(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern union __PST__g__33 _main_gen_init_g33(void);

extern __PST__g__23 _main_gen_init_g23(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

union __PST__g__33 _main_gen_init_g33(void)
{
    static union __PST__g__33 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__23 _main_gen_init_g23(void)
{
    __PST__g__23 x;
    /* struct/union type */
    x.ESSTR0 = _main_gen_init_g33();
    return x;
}

union __PST__g__63 _main_gen_init_g63(void)
{
    static union __PST__g__63 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__67 _main_gen_init_g67(void)
{
    static union __PST__g__67 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__71 _main_gen_init_g71(void)
{
    static union __PST__g__71 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

union __PST__g__74 _main_gen_init_g74(void)
{
    static union __PST__g__74 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__46 _main_gen_init_g46(void)
{
    __PST__g__46 x;
    /* struct/union type */
    x.EMK0 = _main_gen_init_g63();
    x.ESSTC0 = _main_gen_init_g67();
    x.PCMD1 = _main_gen_init_g71();
    x.PS = _main_gen_init_g74();
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

struct __PST__g__101 _main_gen_init_g101(void)
{
    static struct __PST__g__101 x;
    /* struct/union type */
    {
        __PST__UINT16 bitf;
        bitf = _main_gen_init_g7();
        unchecked_assert(bitf <= 1);
        x.VCIE = bitf;
    }
    return x;
}

union __PST__g__100 _main_gen_init_g100(void)
{
    static union __PST__g__100 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g101();
    x.UINT16 = _main_gen_init_g7();
    return x;
}

struct __PST__g__103 _main_gen_init_g103(void)
{
    static struct __PST__g__103 x;
    /* struct/union type */
    {
        __PST__UINT16 bitf;
        bitf = _main_gen_init_g7();
        unchecked_assert(bitf <= 1);
        x.VCIF = bitf;
    }
    return x;
}

union __PST__g__102 _main_gen_init_g102(void)
{
    static union __PST__g__102 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g103();
    return x;
}

__PST__g__98 _main_gen_init_g98(void)
{
    __PST__g__98 x;
    /* struct/union type */
    x.CONT = _main_gen_init_g100();
    x.FLAG = _main_gen_init_g102();
    return x;
}

union __PST__g__110 _main_gen_init_g110(void)
{
    static union __PST__g__110 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__113 _main_gen_init_g113(void)
{
    static union __PST__g__113 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__115 _main_gen_init_g115(void)
{
    static union __PST__g__115 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__107 _main_gen_init_g107(void)
{
    __PST__g__107 x;
    /* struct/union type */
    x.ERRST_CHBB0 = _main_gen_init_g110();
    x.ERRSTC_CHBB0 = _main_gen_init_g113();
    x.TMC_CHBB0 = _main_gen_init_g115();
    return x;
}

union __PST__g__147 _main_gen_init_g147(void)
{
    static union __PST__g__147 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__127 _main_gen_init_g127(void)
{
    __PST__g__127 x;
    /* struct/union type */
    x.BCTL0 = _main_gen_init_g147();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_ECMM(void)
{
    extern __PST__g__23 ECMM;
    
    /* initialization with random value */
    {
        ECMM = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_ECM(void)
{
    extern __PST__g__46 ECM;
    
    /* initialization with random value */
    {
        ECM = _main_gen_init_g46();
    }
}

static void _main_gen_init_sym_SEG(void)
{
    extern __PST__g__98 SEG;
    
    /* initialization with random value */
    {
        SEG = _main_gen_init_g98();
    }
}

static void _main_gen_init_sym_APDP(void)
{
    extern __PST__g__107 APDP;
    
    /* initialization with random value */
    {
        APDP = _main_gen_init_g107();
    }
}

static void _main_gen_init_sym_CSIG0(void)
{
    extern __PST__g__127 CSIG0;
    
    /* initialization with random value */
    {
        CSIG0 = _main_gen_init_g127();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable ECMM */
    _main_gen_init_sym_ECMM();
    
    /* init for variable ECM */
    _main_gen_init_sym_ECM();
    
    /* init for variable SEG */
    _main_gen_init_sym_SEG();
    
    /* init for variable APDP */
    _main_gen_init_sym_APDP();
    
    /* init for variable CSIG0 */
    _main_gen_init_sym_CSIG0();
    
}
