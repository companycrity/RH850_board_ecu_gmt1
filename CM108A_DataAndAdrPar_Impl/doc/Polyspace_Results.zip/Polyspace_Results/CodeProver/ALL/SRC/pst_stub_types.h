typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__VOID __PST__g__15(void);
typedef __PST__FLOAT64 __PST__g__16(void);
typedef __PST__g__11 *__PST__g__18;
typedef volatile __PST__FLOAT64 __PST__g__19;
typedef __PST__SINT8 *__PST__g__21;
typedef volatile __PST__g__21 __PST__g__20;
typedef __PST__VOID __PST__g__22(__PST__SINT32);
typedef __PST__SINT8 __PST__g__231[1];
typedef __PST__SINT8 __PST__g__97[3];
typedef __PST__SINT32 __PST__g__233[1];
union __PST__g__33
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__33 __PST__g__32;
typedef __PST__SINT8 __PST__g__232[4];
struct __PST__g__24
  {
    __PST__g__231 __pst_unused_field_0;
    __PST__g__97 __pst_unused_field_1;
    __PST__g__231 __pst_unused_field_2;
    __PST__g__97 __pst_unused_field_3;
    __PST__g__32 ESSTR0;
    __PST__g__232 __pst_unused_field_5;
    __PST__g__232 __pst_unused_field_6;
  };
typedef volatile struct __PST__g__24 __PST__g__23;
union __PST__g__25
  {
    __PST__g__231 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__26
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef __PST__UINT8 __PST__g__29[3];
union __PST__g__30
  {
    __PST__g__231 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__31
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
struct __PST__g__35
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    const __PST__UINT32 __pst_unused_field_3 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    const __PST__UINT32 __pst_unused_field_6 : 1;
    const __PST__UINT32 __pst_unused_field_7 : 1;
    const __PST__UINT32 __pst_unused_field_8 : 1;
    const __PST__UINT32 __pst_unused_field_9 : 1;
    const __PST__UINT32 __pst_unused_field_10 : 1;
    const __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    const __PST__UINT32 __pst_unused_field_13 : 1;
    const __PST__UINT32 __pst_unused_field_14 : 1;
    const __PST__UINT32 __pst_unused_field_15 : 1;
    const __PST__UINT32 __pst_unused_field_16 : 1;
    const __PST__UINT32 __pst_unused_field_17 : 1;
    const __PST__UINT32 __pst_unused_field_18 : 1;
    const __PST__UINT32 __pst_unused_field_19 : 1;
    const __PST__UINT32 __pst_unused_field_20 : 1;
    const __PST__UINT32 __pst_unused_field_21 : 1;
    const __PST__UINT32 __pst_unused_field_22 : 1;
    const __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    const __PST__UINT32 __pst_unused_field_25 : 1;
    const __PST__UINT32 __pst_unused_field_26 : 1;
    const __PST__UINT32 __pst_unused_field_27 : 1;
    const __PST__UINT32 __pst_unused_field_28 : 1;
    const __PST__UINT32 __pst_unused_field_29 : 1;
    const __PST__UINT32 __pst_unused_field_30 : 1;
  };
typedef const struct __PST__g__35 __PST__g__34;
union __PST__g__39
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__39 __PST__g__38;
struct __PST__g__41
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    const __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    const __PST__UINT32 __pst_unused_field_6 : 1;
    const __PST__UINT32 __pst_unused_field_7 : 1;
    const __PST__UINT32 __pst_unused_field_8 : 1;
    const __PST__UINT32 __pst_unused_field_9 : 1;
    const __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    const __PST__UINT32 __pst_unused_field_12 : 1;
    const __PST__UINT32 __pst_unused_field_13 : 1;
    const __PST__UINT32 __pst_unused_field_14 : 1;
  };
typedef const struct __PST__g__41 __PST__g__40;
union __PST__g__43
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__44
  {
    __PST__UINT32 __pst_unused_field_0 : 8;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 24;
  };
union __PST__g__63
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__67
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__71
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__74
  {
    __PST__g__231 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef const union __PST__g__74 __PST__g__73;
typedef const __PST__UINT16 __PST__g__84;
typedef __PST__SINT8 __PST__g__234[2];
typedef __PST__SINT8 __PST__g__235[4008];
struct __PST__g__47
  {
    __PST__g__231 __pst_unused_field_0;
    __PST__g__97 __pst_unused_field_1;
    __PST__g__232 __pst_unused_field_2;
    __PST__g__232 __pst_unused_field_3;
    __PST__g__232 __pst_unused_field_4;
    __PST__g__232 __pst_unused_field_5;
    __PST__g__232 __pst_unused_field_6;
    __PST__g__232 __pst_unused_field_7;
    union __PST__g__63 EMK0;
    __PST__g__232 __pst_unused_field_9;
    union __PST__g__67 ESSTC0;
    __PST__g__232 __pst_unused_field_11;
    union __PST__g__71 PCMD1;
    __PST__g__73 PS;
    __PST__g__97 __pst_unused_field_14;
    __PST__g__232 __pst_unused_field_15;
    __PST__g__232 __pst_unused_field_16;
    __PST__g__231 __pst_unused_field_17;
    __PST__g__97 __pst_unused_field_18;
    __PST__g__84 __pst_unused_field_19;
    __PST__g__234 __pst_unused_field_20;
    __PST__UINT16 __pst_unused_field_21;
    __PST__g__234 __pst_unused_field_22;
    __PST__g__232 __pst_unused_field_23;
    __PST__g__232 __pst_unused_field_24;
    __PST__g__232 __pst_unused_field_25;
    __PST__g__232 __pst_unused_field_26;
    __PST__g__235 __pst_unused_field_27;
    __PST__g__231 __pst_unused_field_28;
    __PST__g__97 __pst_unused_field___pstfiller;
  };
typedef volatile struct __PST__g__47 __PST__g__46;
union __PST__g__48
  {
    __PST__g__231 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__49
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
union __PST__g__50
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__51
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__52
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__53
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
union __PST__g__55
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__56
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__57
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__58
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
union __PST__g__59
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__60
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__61
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__62
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 2;
  };
struct __PST__g__64
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__65
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__66
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 2;
  };
struct __PST__g__68
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__69
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__70
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
  };
struct __PST__g__72
  {
    __PST__UINT32 __pst_unused_field_0 : 8;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 24;
  };
struct __PST__g__76
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef const struct __PST__g__76 __PST__g__75;
union __PST__g__77
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__78
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__79
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__80
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 2;
  };
union __PST__g__81
  {
    __PST__g__231 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__82
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 6;
  };
typedef __PST__UINT8 __PST__g__85[2];
union __PST__g__86
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__87
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__88
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__89
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
union __PST__g__90
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__91
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__92
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__93
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
typedef __PST__UINT8 __PST__g__94[4008];
union __PST__g__95
  {
    __PST__g__231 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__96
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
struct __PST__g__101
  {
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT16 __pst_unused_field_1 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT16 VCIE : 1;
    __PST__UINT16 __pst_unused_field_4 : 1;
    __PST__UINT16 __pst_unused_field_5 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT16 __pst_unused_field_7 : 1;
    __PST__UINT16 __pst_unused_field_8 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef4 : 6;
  };
union __PST__g__100
  {
    struct __PST__g__101 BIT;
    __PST__UINT16 UINT16;
  };
struct __PST__g__103
  {
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT16 __pst_unused_field_1 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT16 VCIF : 1;
    __PST__UINT16 __pst_unused_field_4 : 1;
    __PST__UINT16 __pst_unused_field_5 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT16 __pst_unused_field_7 : 1;
    __PST__UINT16 __pst_unused_field_8 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef4 : 6;
  };
union __PST__g__102
  {
    struct __PST__g__103 BIT;
    __PST__UINT16 __pst_unused_field_1;
  };
struct __PST__g__99
  {
    union __PST__g__100 CONT;
    union __PST__g__102 FLAG;
    __PST__g__232 __pst_unused_field_2;
    __PST__g__232 __pst_unused_field_3;
  };
typedef volatile struct __PST__g__99 __PST__g__98;
typedef __PST__UINT8 __PST__g__104[4];
typedef __PST__SINT16 __PST__g__236[2];
union __PST__g__105
  {
    __PST__g__236 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef __PST__UINT16 __PST__g__106[2];
typedef __PST__SINT8 __PST__g__237[240];
typedef __PST__SINT8 __PST__g__238[95984];
typedef __PST__SINT8 __PST__g__239[1351648];
typedef __PST__SINT8 __PST__g__240[1883824];
union __PST__g__110
  {
    __PST__g__232 __pst_unused_field_0;
    __PST__g__236 __pst_unused_field_1;
    __PST__UINT32 UINT32;
    __PST__g__232 __pst_unused_field_3;
  };
typedef const union __PST__g__110 __PST__g__109;
union __PST__g__113
  {
    __PST__g__232 __pst_unused_field_0;
    __PST__g__236 __pst_unused_field_1;
    __PST__UINT32 UINT32;
    __PST__g__232 __pst_unused_field_3;
  };
union __PST__g__115
  {
    __PST__g__236 __pst_unused_field_0;
    __PST__g__236 __pst_unused_field_1;
    __PST__UINT32 UINT32;
  };
struct __PST__g__108
  {
    __PST__g__232 __pst_unused_field_0;
    __PST__g__232 __pst_unused_field_1;
    __PST__g__232 __pst_unused_field_2;
    __PST__g__232 __pst_unused_field_3;
    __PST__g__237 __pst_unused_field_4;
    __PST__g__232 __pst_unused_field_5;
    __PST__g__232 __pst_unused_field_6;
    __PST__g__232 __pst_unused_field_7;
    __PST__g__232 __pst_unused_field_8;
    __PST__g__238 __pst_unused_field_9;
    __PST__g__232 __pst_unused_field_10;
    __PST__g__232 __pst_unused_field_11;
    __PST__g__232 __pst_unused_field_12;
    __PST__g__232 __pst_unused_field_13;
    __PST__g__232 __pst_unused_field_14;
    __PST__g__232 __pst_unused_field_15;
    __PST__g__232 __pst_unused_field_16;
    __PST__g__232 __pst_unused_field_17;
    __PST__g__239 __pst_unused_field_18;
    __PST__g__232 __pst_unused_field_19;
    __PST__g__232 __pst_unused_field_20;
    __PST__g__232 __pst_unused_field_21;
    __PST__g__232 __pst_unused_field_22;
    __PST__g__232 __pst_unused_field_23;
    __PST__g__232 __pst_unused_field_24;
    __PST__g__232 __pst_unused_field_25;
    __PST__g__232 __pst_unused_field_26;
    __PST__g__232 __pst_unused_field_27;
    __PST__g__232 __pst_unused_field_28;
    __PST__g__232 __pst_unused_field_29;
    __PST__g__232 __pst_unused_field_30;
    __PST__g__232 __pst_unused_field_31;
    __PST__g__232 __pst_unused_field_32;
    __PST__g__232 __pst_unused_field_33;
    __PST__g__232 __pst_unused_field_34;
    __PST__g__232 __pst_unused_field_35;
    __PST__g__232 __pst_unused_field_36;
    __PST__g__232 __pst_unused_field_37;
    __PST__g__232 __pst_unused_field_38;
    __PST__g__232 __pst_unused_field_39;
    __PST__g__232 __pst_unused_field_40;
    __PST__g__232 __pst_unused_field_41;
    __PST__g__232 __pst_unused_field_42;
    __PST__g__232 __pst_unused_field_43;
    __PST__g__232 __pst_unused_field_44;
    __PST__g__232 __pst_unused_field_45;
    __PST__g__232 __pst_unused_field_46;
    __PST__g__232 __pst_unused_field_47;
    __PST__g__232 __pst_unused_field_48;
    __PST__g__232 __pst_unused_field_49;
    __PST__g__232 __pst_unused_field_50;
    __PST__g__232 __pst_unused_field_51;
    __PST__g__232 __pst_unused_field_52;
    __PST__g__232 __pst_unused_field_53;
    __PST__g__232 __pst_unused_field_54;
    __PST__g__232 __pst_unused_field_55;
    __PST__g__232 __pst_unused_field_56;
    __PST__g__232 __pst_unused_field_57;
    __PST__g__232 __pst_unused_field_58;
    __PST__g__232 __pst_unused_field_59;
    __PST__g__232 __pst_unused_field_60;
    __PST__g__232 __pst_unused_field_61;
    __PST__g__232 __pst_unused_field_62;
    __PST__g__232 __pst_unused_field_63;
    __PST__g__232 __pst_unused_field_64;
    __PST__g__232 __pst_unused_field_65;
    __PST__g__232 __pst_unused_field_66;
    __PST__g__232 __pst_unused_field_67;
    __PST__g__232 __pst_unused_field_68;
    __PST__g__232 __pst_unused_field_69;
    __PST__g__232 __pst_unused_field_70;
    __PST__g__232 __pst_unused_field_71;
    __PST__g__232 __pst_unused_field_72;
    __PST__g__232 __pst_unused_field_73;
    __PST__g__232 __pst_unused_field_74;
    __PST__g__232 __pst_unused_field_75;
    __PST__g__232 __pst_unused_field_76;
    __PST__g__232 __pst_unused_field_77;
    __PST__g__232 __pst_unused_field_78;
    __PST__g__232 __pst_unused_field_79;
    __PST__g__232 __pst_unused_field_80;
    __PST__g__232 __pst_unused_field_81;
    __PST__g__232 __pst_unused_field_82;
    __PST__g__232 __pst_unused_field_83;
    __PST__g__232 __pst_unused_field_84;
    __PST__g__232 __pst_unused_field_85;
    __PST__g__232 __pst_unused_field_86;
    __PST__g__232 __pst_unused_field_87;
    __PST__g__232 __pst_unused_field_88;
    __PST__g__232 __pst_unused_field_89;
    __PST__g__232 __pst_unused_field_90;
    __PST__g__232 __pst_unused_field_91;
    __PST__g__232 __pst_unused_field_92;
    __PST__g__232 __pst_unused_field_93;
    __PST__g__232 __pst_unused_field_94;
    __PST__g__232 __pst_unused_field_95;
    __PST__g__232 __pst_unused_field_96;
    __PST__g__232 __pst_unused_field_97;
    __PST__g__232 __pst_unused_field_98;
    __PST__g__232 __pst_unused_field_99;
    __PST__g__232 __pst_unused_field_100;
    __PST__g__232 __pst_unused_field_101;
    __PST__g__232 __pst_unused_field_102;
    __PST__g__240 __pst_unused_field_103;
    __PST__g__232 __pst_unused_field_104;
    __PST__g__232 __pst_unused_field_105;
    __PST__g__232 __pst_unused_field_106;
    __PST__g__232 __pst_unused_field_107;
    __PST__g__232 __pst_unused_field_108;
    __PST__g__232 __pst_unused_field_109;
    __PST__g__232 __pst_unused_field_110;
    __PST__g__232 __pst_unused_field_111;
    __PST__g__232 __pst_unused_field_112;
    __PST__g__232 __pst_unused_field_113;
    __PST__g__232 __pst_unused_field_114;
    __PST__g__232 __pst_unused_field_115;
    __PST__g__232 __pst_unused_field_116;
    __PST__g__232 __pst_unused_field_117;
    __PST__g__232 __pst_unused_field_118;
    __PST__g__232 __pst_unused_field_119;
    __PST__g__232 __pst_unused_field_120;
    __PST__g__232 __pst_unused_field_121;
    __PST__g__232 __pst_unused_field_122;
    __PST__g__232 __pst_unused_field_123;
    __PST__g__232 __pst_unused_field_124;
    __PST__g__232 __pst_unused_field_125;
    __PST__g__232 __pst_unused_field_126;
    __PST__g__232 __pst_unused_field_127;
    __PST__g__232 __pst_unused_field_128;
    __PST__g__232 __pst_unused_field_129;
    __PST__g__232 __pst_unused_field_130;
    __PST__g__232 __pst_unused_field_131;
    __PST__g__232 __pst_unused_field_132;
    __PST__g__232 __pst_unused_field_133;
    __PST__g__232 __pst_unused_field_134;
    __PST__g__232 __pst_unused_field_135;
    __PST__g__232 __pst_unused_field_136;
    __PST__g__232 __pst_unused_field_137;
    __PST__g__232 __pst_unused_field_138;
    __PST__g__232 __pst_unused_field_139;
    __PST__g__232 __pst_unused_field_140;
    __PST__g__232 __pst_unused_field_141;
    __PST__g__232 __pst_unused_field_142;
    __PST__g__232 __pst_unused_field_143;
    __PST__g__109 ERRST_CHBB0;
    union __PST__g__113 ERRSTC_CHBB0;
    union __PST__g__115 TMC_CHBB0;
    __PST__g__232 __pst_unused_field_147;
    __PST__g__232 __pst_unused_field_148;
    __PST__g__232 __pst_unused_field_149;
    __PST__g__232 __pst_unused_field_150;
    __PST__g__232 __pst_unused_field_151;
    __PST__g__232 __pst_unused_field_152;
    __PST__g__232 __pst_unused_field_153;
    __PST__g__232 __pst_unused_field_154;
    __PST__g__232 __pst_unused_field_155;
    __PST__g__232 __pst_unused_field_156;
    __PST__g__232 __pst_unused_field_157;
    __PST__g__232 __pst_unused_field_158;
    __PST__g__232 __pst_unused_field_159;
    __PST__g__232 __pst_unused_field_160;
    __PST__g__232 __pst_unused_field_161;
    __PST__g__232 __pst_unused_field_162;
    __PST__g__232 __pst_unused_field_163;
  };
typedef volatile struct __PST__g__108 __PST__g__107;
struct __PST__g__112
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef4 : 8;
  };
typedef const struct __PST__g__112 __PST__g__111;
struct __PST__g__114
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef4 : 8;
  };
struct __PST__g__116
  {
    __PST__UINT16 __pst_unused_field_0 : 1;
    __PST__UINT16 __pst_unused_field_1 : 1;
    __PST__UINT16 __pst_unused_field_2 : 1;
    __PST__UINT16 __pst_unused_field_3 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 10;
    __PST__UINT16 __pst_unused_field_5 : 2;
    __PST__UINT16 __pst_unused_field_pstnonamef2 : 16;
  };
union __PST__g__119
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__119 __PST__g__118;
struct __PST__g__121
  {
    const __PST__UINT32 __pst_unused_field_0 : 32;
  };
typedef const struct __PST__g__121 __PST__g__120;
typedef const __PST__UINT32 __PST__g__122;
typedef __PST__UINT8 __PST__g__123[240];
typedef __PST__UINT8 __PST__g__124[95984];
typedef __PST__UINT8 __PST__g__125[1351648];
typedef __PST__UINT8 __PST__g__126[1883824];
typedef __PST__SINT8 __PST__g__241[6];
typedef __PST__SINT8 __PST__g__242[4074];
union __PST__g__147
  {
    __PST__g__231 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
struct __PST__g__128
  {
    __PST__g__231 __pst_unused_field_0;
    __PST__g__97 __pst_unused_field_1;
    __PST__g__232 __pst_unused_field_2;
    __PST__g__234 __pst_unused_field_3;
    __PST__g__241 __pst_unused_field_4;
    __PST__g__232 __pst_unused_field_5;
    __PST__g__234 __pst_unused_field_6;
    __PST__g__242 __pst_unused_field_7;
    union __PST__g__147 BCTL0;
    __PST__g__97 __pst_unused_field_9;
    __PST__g__232 __pst_unused_field_10;
    __PST__g__234 __pst_unused_field_11;
    __PST__g__234 __pst_unused_field_12;
    __PST__g__234 __pst_unused_field_13;
    __PST__g__234 __pst_unused_field_14;
    __PST__g__232 __pst_unused_field_15;
  };
typedef volatile struct __PST__g__128 __PST__g__127;
union __PST__g__129
  {
    __PST__g__231 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__130
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
  };
union __PST__g__133
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__133 __PST__g__132;
struct __PST__g__135
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    const __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 3;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 24;
  };
typedef const struct __PST__g__135 __PST__g__134;
typedef __PST__SINT16 __PST__g__243[1];
union __PST__g__137
  {
    __PST__g__243 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
  };
struct __PST__g__138
  {
    __PST__UINT16 __pst_unused_field_0 : 1;
    __PST__UINT16 __pst_unused_field_1 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT16 __pst_unused_field_3 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef2 : 12;
  };
typedef __PST__UINT8 __PST__g__140[6];
union __PST__g__141
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__142
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef4 : 8;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef5 : 14;
  };
union __PST__g__144
  {
    __PST__g__243 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
  };
struct __PST__g__145
  {
    __PST__UINT16 __pst_unused_field_0 : 12;
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT16 __pst_unused_field_2 : 3;
  };
typedef __PST__UINT8 __PST__g__146[4074];
struct __PST__g__148
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
union __PST__g__149
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__150
  {
    __PST__UINT32 __pst_unused_field_0 : 16;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 13;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 2;
  };
union __PST__g__152
  {
    __PST__g__243 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
  };
struct __PST__g__153
  {
    __PST__UINT16 __pst_unused_field_0 : 16;
  };
union __PST__g__155
  {
    __PST__g__243 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
  };
typedef const union __PST__g__155 __PST__g__154;
struct __PST__g__157
  {
    const __PST__UINT16 __pst_unused_field_0 : 16;
  };
typedef const struct __PST__g__157 __PST__g__156;
union __PST__g__158
  {
    __PST__g__233 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__159
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 16;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 5;
    __PST__UINT32 __pst_unused_field_5 : 4;
    __PST__UINT32 __pst_unused_field_6 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef4 : 2;
  };
typedef __PST__VOID __PST__g__161(__PST__UINT32, __PST__UINT32);
typedef __PST__UINT8 *__PST__g__163;
typedef __PST__VOID __PST__g__162(__PST__g__163);
typedef __PST__UINT32 *__PST__g__165;
typedef __PST__VOID __PST__g__164(__PST__g__165);
typedef __PST__VOID __PST__g__166(__PST__UINT32, __PST__g__165);
typedef const __PST__UINT8 __PST__g__167;
typedef volatile __PST__UINT32 __PST__g__168;
typedef __PST__g__168 *__PST__g__169;
typedef __PST__VOID __PST__g__170(__PST__UINT32, __PST__g__169);
typedef __PST__g__15 *__PST__g__171;
typedef volatile __PST__g__122 __PST__g__172;
typedef __PST__g__172 *__PST__g__173;
typedef volatile __PST__UINT8 __PST__g__174;
typedef __PST__g__174 *__PST__g__175;
typedef volatile __PST__g__73 __PST__g__176;
typedef __PST__g__176 *__PST__g__177;
typedef volatile __PST__g__167 __PST__g__178;
typedef __PST__g__178 *__PST__g__179;
typedef __PST__g__23 *__PST__g__180;
typedef __PST__g__46 *__PST__g__181;
typedef volatile union __PST__g__71 __PST__g__182;
typedef __PST__g__182 *__PST__g__183;
typedef volatile __PST__UINT16 __PST__g__184;
typedef __PST__g__184 *__PST__g__185;
typedef __PST__g__161 *__PST__g__186;
typedef __PST__g__170 *__PST__g__187;
typedef volatile union __PST__g__67 __PST__g__188;
typedef __PST__g__188 *__PST__g__189;
typedef volatile union __PST__g__63 __PST__g__190;
typedef __PST__g__190 *__PST__g__191;
typedef __PST__g__98 *__PST__g__192;
typedef volatile union __PST__g__100 __PST__g__193;
typedef __PST__g__193 *__PST__g__194;
typedef __PST__g__162 *__PST__g__195;
typedef volatile union __PST__g__102 __PST__g__196;
typedef __PST__g__196 *__PST__g__197;
typedef volatile struct __PST__g__103 __PST__g__198;
typedef __PST__g__198 *__PST__g__199;
typedef volatile __PST__g__32 __PST__g__202;
typedef __PST__g__202 *__PST__g__203;
typedef __PST__g__22 *__PST__g__204;
typedef volatile struct __PST__g__101 __PST__g__205;
typedef __PST__g__205 *__PST__g__206;
typedef __PST__g__166 *__PST__g__207;
typedef __PST__g__127 *__PST__g__208;
typedef volatile union __PST__g__147 __PST__g__209;
typedef __PST__g__209 *__PST__g__210;
typedef __PST__UINT8 __PST__g__211(void);
typedef __PST__g__211 *__PST__g__212;
typedef __PST__g__107 *__PST__g__213;
typedef volatile __PST__g__109 __PST__g__214;
typedef __PST__g__214 *__PST__g__215;
typedef volatile union __PST__g__113 __PST__g__216;
typedef __PST__g__216 *__PST__g__217;
typedef __PST__g__164 *__PST__g__218;
typedef volatile union __PST__g__115 __PST__g__219;
typedef __PST__g__219 *__PST__g__220;
typedef volatile __PST__SINT32 __PST__g__221;
typedef __PST__SINT8 __PST__g__227(void);
typedef volatile __PST__SINT8 __PST__g__228;
typedef __PST__SINT32 __PST__g__229(void);
typedef __PST__UINT32 __PST__g__230(void);
