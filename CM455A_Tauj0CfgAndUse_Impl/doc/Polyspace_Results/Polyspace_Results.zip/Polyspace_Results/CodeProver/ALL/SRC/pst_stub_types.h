typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__VOID __PST__g__15(void);
typedef __PST__FLOAT64 __PST__g__16(void);
typedef __PST__g__11 *__PST__g__18;
typedef volatile __PST__FLOAT64 __PST__g__19;
typedef __PST__SINT8 *__PST__g__21;
typedef volatile __PST__g__21 __PST__g__20;
typedef const struct Rte_CDS_CDD_Tauj0CfgAndUse __PST__g__24;
typedef __PST__g__24 *__PST__g__23;
typedef const __PST__g__23 __PST__g__22;
typedef __PST__UINT32 *__PST__g__26;
struct Rte_CDS_CDD_Tauj0CfgAndUse
  {
    __PST__g__26 Pim_PhaOnTiCntrAPrev;
    __PST__g__26 Pim_PhaOnTiCntrBPrev;
    __PST__g__26 Pim_PhaOnTiCntrCPrev;
  };
typedef const __PST__UINT32 __PST__g__29;
typedef __PST__SINT8 __PST__g__117[1];
union __PST__g__30
  {
    __PST__g__117 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef __PST__SINT8 __PST__g__116[3];
union __PST__g__49
  {
    __PST__g__117 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef __PST__SINT8 __PST__g__118[19];
typedef __PST__SINT16 __PST__g__121[1];
union __PST__g__66
  {
    __PST__g__121 __pst_unused_field_0;
    __PST__UINT16 UINT16;
  };
typedef __PST__SINT8 __PST__g__119[2];
union __PST__g__71
  {
    __PST__g__121 __pst_unused_field_0;
    __PST__UINT16 UINT16;
  };
typedef __PST__SINT8 __PST__g__120[3931];
struct __PST__g__28
  {
    __PST__UINT32 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
    __PST__UINT32 __pst_unused_field_2;
    __PST__UINT32 __pst_unused_field_3;
    __PST__g__29 CNT0;
    __PST__g__29 CNT1;
    __PST__g__29 __pst_unused_field_6;
    __PST__g__29 CNT3;
    union __PST__g__30 CMUR0;
    __PST__g__116 __pst_unused_field_9;
    union __PST__g__30 CMUR1;
    __PST__g__116 __pst_unused_field_11;
    __PST__g__117 __pst_unused_field_12;
    __PST__g__116 __pst_unused_field_13;
    union __PST__g__30 CMUR3;
    __PST__g__116 __pst_unused_field_15;
    __PST__g__117 __pst_unused_field_16;
    __PST__g__116 __pst_unused_field_17;
    __PST__g__117 __pst_unused_field_18;
    __PST__g__116 __pst_unused_field_19;
    __PST__g__117 __pst_unused_field_20;
    __PST__g__116 __pst_unused_field_21;
    __PST__g__117 __pst_unused_field_22;
    __PST__g__116 __pst_unused_field_23;
    __PST__g__117 __pst_unused_field_24;
    __PST__g__116 __pst_unused_field_25;
    __PST__g__117 __pst_unused_field_26;
    __PST__g__116 __pst_unused_field_27;
    __PST__g__117 __pst_unused_field_28;
    __PST__g__116 __pst_unused_field_29;
    __PST__g__117 __pst_unused_field_30;
    __PST__g__116 __pst_unused_field_31;
    __PST__g__117 __pst_unused_field_32;
    __PST__g__116 __pst_unused_field_33;
    union __PST__g__49 TS;
    __PST__g__116 __pst_unused_field_35;
    __PST__g__117 __pst_unused_field_36;
    __PST__g__116 __pst_unused_field_37;
    __PST__g__117 __pst_unused_field_38;
    __PST__g__116 __pst_unused_field_39;
    __PST__g__117 __pst_unused_field_40;
    __PST__g__116 __pst_unused_field_41;
    __PST__g__117 __pst_unused_field_42;
    __PST__g__116 __pst_unused_field_43;
    __PST__g__117 __pst_unused_field_44;
    __PST__g__116 __pst_unused_field_45;
    __PST__g__117 __pst_unused_field_46;
    __PST__g__118 __pst_unused_field_47;
    union __PST__g__66 CMOR0;
    __PST__g__119 __pst_unused_field_49;
    union __PST__g__66 CMOR1;
    __PST__g__119 __pst_unused_field_51;
    __PST__g__119 __pst_unused_field_52;
    __PST__g__119 __pst_unused_field_53;
    union __PST__g__66 CMOR3;
    __PST__g__119 __pst_unused_field_55;
    union __PST__g__71 TPS;
    __PST__g__119 __pst_unused_field_57;
    __PST__UINT8 BRS;
    __PST__g__116 __pst_unused_field_59;
    __PST__g__117 __pst_unused_field_60;
    __PST__g__116 __pst_unused_field_61;
    __PST__g__117 __pst_unused_field_62;
    __PST__g__116 __pst_unused_field_63;
    __PST__g__117 __pst_unused_field_64;
    __PST__g__116 __pst_unused_field_65;
    __PST__g__117 __pst_unused_field_66;
    __PST__g__120 __pst_unused_field_67;
  };
typedef volatile struct __PST__g__28 __PST__g__27;
struct __PST__g__31
  {
    __PST__UINT8 __pst_unused_field_0 : 2;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 6;
  };
typedef __PST__UINT8 __PST__g__34[3];
union __PST__g__36
  {
    __PST__g__117 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef const union __PST__g__36 __PST__g__35;
struct __PST__g__38
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef const struct __PST__g__38 __PST__g__37;
union __PST__g__42
  {
    __PST__g__117 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__43
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
union __PST__g__45
  {
    __PST__g__117 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef const union __PST__g__45 __PST__g__44;
struct __PST__g__47
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    const __PST__UINT8 __pst_unused_field_1 : 1;
    const __PST__UINT8 __pst_unused_field_2 : 1;
    const __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
typedef const struct __PST__g__47 __PST__g__46;
struct __PST__g__50
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__51
  {
    __PST__g__117 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__52
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__53
  {
    __PST__g__117 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__54
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__55
  {
    __PST__g__117 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__56
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__57
  {
    __PST__g__117 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__58
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__59
  {
    __PST__g__117 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__60
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__62
  {
    __PST__g__117 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef const union __PST__g__62 __PST__g__61;
struct __PST__g__64
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    const __PST__UINT8 __pst_unused_field_1 : 1;
    const __PST__UINT8 __pst_unused_field_2 : 1;
    const __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
typedef const struct __PST__g__64 __PST__g__63;
typedef __PST__UINT8 __PST__g__65[19];
struct __PST__g__67
  {
    __PST__UINT16 __pst_unused_field_0 : 5;
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT16 __pst_unused_field_2 : 2;
    __PST__UINT16 __pst_unused_field_3 : 3;
    __PST__UINT16 __pst_unused_field_4 : 1;
    __PST__UINT16 __pst_unused_field_5 : 2;
    __PST__UINT16 __pst_unused_field_6 : 2;
  };
typedef __PST__UINT8 __PST__g__70[2];
struct __PST__g__72
  {
    __PST__UINT16 __pst_unused_field_0 : 4;
    __PST__UINT16 __pst_unused_field_1 : 4;
    __PST__UINT16 __pst_unused_field_2 : 4;
    __PST__UINT16 __pst_unused_field_3 : 4;
  };
union __PST__g__73
  {
    __PST__g__117 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__74
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__75
  {
    __PST__g__117 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__76
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__77
  {
    __PST__g__117 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__78
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__79
  {
    __PST__g__117 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__80
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
typedef __PST__UINT8 __PST__g__81[3931];
typedef __PST__VOID __PST__g__82(__PST__SINT32);
typedef __PST__UINT8 __PST__g__83(__PST__UINT32);
typedef __PST__UINT32 __PST__g__84(__PST__UINT32, __PST__UINT32, __PST__UINT32);
typedef __PST__g__27 *__PST__g__85;
typedef volatile union __PST__g__71 __PST__g__86;
typedef __PST__g__86 *__PST__g__87;
typedef volatile __PST__UINT16 __PST__g__88;
typedef __PST__g__88 *__PST__g__89;
typedef volatile __PST__UINT8 __PST__g__90;
typedef __PST__g__90 *__PST__g__91;
typedef volatile union __PST__g__30 __PST__g__92;
typedef __PST__g__92 *__PST__g__93;
typedef volatile union __PST__g__66 __PST__g__94;
typedef __PST__g__94 *__PST__g__95;
typedef volatile union __PST__g__49 __PST__g__96;
typedef __PST__g__96 *__PST__g__97;
typedef volatile __PST__g__29 __PST__g__98;
typedef __PST__g__98 *__PST__g__99;
typedef const __PST__g__26 __PST__g__100;
typedef __PST__g__100 *__PST__g__101;
typedef __PST__g__84 *__PST__g__102;
typedef __PST__g__83 *__PST__g__103;
typedef volatile __PST__SINT32 __PST__g__104;
typedef __PST__SINT8 __PST__g__110(void);
typedef volatile __PST__SINT8 __PST__g__111;
typedef __PST__UINT8 __PST__g__112(void);
typedef __PST__SINT32 __PST__g__113(void);
typedef __PST__UINT32 __PST__g__114(void);
typedef volatile __PST__UINT32 __PST__g__115;
