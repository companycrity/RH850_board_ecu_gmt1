
#ifndef CDD_HWTQ1MEAS_CFG_H     /* Multiple include preventer */
#define CDD_HWTQ1MEAS_CFG_H

#include "Rte_CDD_HwTq1Meas.h"

#define HWTQ1MEAS_HWTQ1MFGNTCNR_ULS_U16                 NTCNR_0X1E1
#define HWTQ1MEAS_HWTQ1PRTCLNTCNR_ULS_U16               NTCNR_0X075


#endif
