#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__107 _main_gen_init_g107(void);

extern union __PST__g__105 _main_gen_init_g105(void);

extern union __PST__g__81 _main_gen_init_g81(void);

extern struct __PST__g__74 _main_gen_init_g74(void);

extern union __PST__g__73 _main_gen_init_g73(void);

extern struct __PST__g__71 _main_gen_init_g71(void);

extern union __PST__g__69 _main_gen_init_g69(void);

extern union __PST__g__64 _main_gen_init_g64(void);

extern union __PST__g__60 _main_gen_init_g60(void);

extern union __PST__g__57 _main_gen_init_g57(void);

extern union __PST__g__54 _main_gen_init_g54(void);

extern union __PST__g__50 _main_gen_init_g50(void);

extern union __PST__g__45 _main_gen_init_g45(void);

extern union __PST__g__37 _main_gen_init_g37(void);

extern __PST__g__35 _main_gen_init_g35(void);

extern struct __PST__g__33 _main_gen_init_g33(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct Rte_CDS_CDD_HwTq1Meas _main_gen_init_g30(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

struct __PST__g__33 _main_gen_init_g33(void)
{
    static struct __PST__g__33 x;
    /* struct/union type */
    x.OffsTrim = _main_gen_init_g10();
    x.OffsTrimPrfmdSts = _main_gen_init_g6();
    return x;
}

struct Rte_CDS_CDD_HwTq1Meas _main_gen_init_g30(void)
{
    static struct Rte_CDS_CDD_HwTq1Meas x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g6();
        }
        x.Pim_HwTq1ComStsErrCntr = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g6();
        }
        x.Pim_HwTq1IntSnsrErrCntr = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_10[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g10();
        }
        x.Pim_HwTq1MeasPrevHwTq1 = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g6();
        }
        x.Pim_HwTq1MeasPrevRollgCntr = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g8();
        }
        x.Pim_HwTq1MsgMissRxCnt = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__33 _main_gen_tmp_16[ARRAY_NBELEM(struct __PST__g__33)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(struct __PST__g__33); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g33();
        }
        x.Pim_HwTq1Offs = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(struct __PST__g__33) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_18[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g10();
        }
        x.Pim_RackLimrCcwEot1 = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_20[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g10();
        }
        x.Pim_RackLimrCwEot1 = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g6();
        }
        x.Pim_RackLimrEot1Avl = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_25;
        for (_i_main_gen_tmp_25 = 0; _i_main_gen_tmp_25 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_25++)
        {
            _main_gen_tmp_24[_i_main_gen_tmp_25] = _main_gen_init_g6();
        }
        x.Pim_RackLimrEot1Data0 = PST_TRUE() ? 0 : &_main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_27;
        for (_i_main_gen_tmp_27 = 0; _i_main_gen_tmp_27 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_27++)
        {
            _main_gen_tmp_26[_i_main_gen_tmp_27] = _main_gen_init_g6();
        }
        x.Pim_RackLimrEot1Data1 = PST_TRUE() ? 0 : &_main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_28[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_29;
        for (_i_main_gen_tmp_29 = 0; _i_main_gen_tmp_29 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_29++)
        {
            _main_gen_tmp_28[_i_main_gen_tmp_29] = _main_gen_init_g6();
        }
        x.Pim_RackLimrEot1Data2 = PST_TRUE() ? 0 : &_main_gen_tmp_28[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_30[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_31;
        for (_i_main_gen_tmp_31 = 0; _i_main_gen_tmp_31 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_31++)
        {
            _main_gen_tmp_30[_i_main_gen_tmp_31] = _main_gen_init_g6();
        }
        x.Pim_RackLimrEot1Id2DataReadCmpl = PST_TRUE() ? 0 : &_main_gen_tmp_30[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_32[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_33;
        for (_i_main_gen_tmp_33 = 0; _i_main_gen_tmp_33 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_33++)
        {
            _main_gen_tmp_32[_i_main_gen_tmp_33] = _main_gen_init_g6();
        }
        x.Pim_RackLimrEot1Id3DataReadCmpl = PST_TRUE() ? 0 : &_main_gen_tmp_32[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_34[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_35;
        for (_i_main_gen_tmp_35 = 0; _i_main_gen_tmp_35 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_35++)
        {
            _main_gen_tmp_34[_i_main_gen_tmp_35] = _main_gen_init_g6();
        }
        x.Pim_RackLimrEot1Id4DataReadCmpl = PST_TRUE() ? 0 : &_main_gen_tmp_34[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    return x;
}

union __PST__g__37 _main_gen_init_g37(void)
{
    static union __PST__g__37 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__45 _main_gen_init_g45(void)
{
    static union __PST__g__45 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__50 _main_gen_init_g50(void)
{
    static union __PST__g__50 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__54 _main_gen_init_g54(void)
{
    static union __PST__g__54 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__57 _main_gen_init_g57(void)
{
    static union __PST__g__57 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__60 _main_gen_init_g60(void)
{
    static union __PST__g__60 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__64 _main_gen_init_g64(void)
{
    static union __PST__g__64 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__71 _main_gen_init_g71(void)
{
    static struct __PST__g__71 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.FRS = bitf;
    }
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.NRS = bitf;
    }
    return x;
}

union __PST__g__69 _main_gen_init_g69(void)
{
    static union __PST__g__69 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g71();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__74 _main_gen_init_g74(void)
{
    static struct __PST__g__74 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.NRC = bitf;
    }
    return x;
}

union __PST__g__73 _main_gen_init_g73(void)
{
    static union __PST__g__73 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g74();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__81 _main_gen_init_g81(void)
{
    static union __PST__g__81 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__107 _main_gen_init_g107(void)
{
    static struct __PST__g__107 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.FND = bitf;
    }
    return x;
}

union __PST__g__105 _main_gen_init_g105(void)
{
    static union __PST__g__105 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g107();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__35 _main_gen_init_g35(void)
{
    __PST__g__35 x;
    /* struct/union type */
    x.TSPC = _main_gen_init_g37();
    x._CC = _main_gen_init_g45();
    x.BRP = _main_gen_init_g50();
    x.IDE = _main_gen_init_g54();
    x.MDC = _main_gen_init_g57();
    x.SPCT = _main_gen_init_g60();
    x.MST = _main_gen_init_g64();
    x.CS = _main_gen_init_g69();
    x.CSC = _main_gen_init_g73();
    x.SRXD = _main_gen_init_g81();
    x.FRXD = _main_gen_init_g105();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_HwTq1Meas(void)
{
    extern __PST__g__27 Rte_Inst_CDD_HwTq1Meas;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_HwTq1Meas _main_gen_tmp_4[ARRAY_NBELEM(struct Rte_CDS_CDD_HwTq1Meas)];
            __PST__UINT32 _i_main_gen_tmp_5;
            for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(struct Rte_CDS_CDD_HwTq1Meas); _i_main_gen_tmp_5++)
            {
                _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g30();
            }
            Rte_Inst_CDD_HwTq1Meas = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(struct Rte_CDS_CDD_HwTq1Meas) / 2];
        }
    }
}

static void _main_gen_init_sym_RSENT1(void)
{
    extern __PST__g__35 RSENT1;
    
    /* initialization with random value */
    {
        RSENT1 = _main_gen_init_g35();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_CDD_HwTq1Meas */
    _main_gen_init_sym_Rte_Inst_CDD_HwTq1Meas();
    
    /* init for variable RSENT1 */
    _main_gen_init_sym_RSENT1();
    
}
