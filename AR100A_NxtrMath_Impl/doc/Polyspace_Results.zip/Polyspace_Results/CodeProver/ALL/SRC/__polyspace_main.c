#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__SINT32 pst_random_g_4;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__SINT32 _main_gen_init_g4(void);

extern __PST__SINT16 _main_gen_init_g3(void);

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__SINT16 _main_gen_init_g3(void)
{
    __PST__SINT16 x;
    /* base type */
    x = pst_random_g_3;
    return x;
}

__PST__SINT32 _main_gen_init_g4(void)
{
    __PST__SINT32 x;
    /* base type */
    x = pst_random_g_4;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */


/* Definition of functions */

static void _main_gen_call_Test_Blnd_f32(void)
{
    extern __PST__FLOAT32 Test_Blnd_f32(__PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    __PST__FLOAT32 __arg__1;
    __PST__FLOAT32 __arg__2;
    
    __arg__0 = _main_gen_init_g10();
    __arg__1 = _main_gen_init_g10();
    __arg__2 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Test_Blnd_f32(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_Test_Abslt_u08_s08(void)
{
    extern __PST__UINT8 Test_Abslt_u08_s08(__PST__SINT8);

    __PST__UINT8 __ret__;
    __PST__SINT8 __arg__0;
    
    __arg__0 = _main_gen_init_g2();
    
    /* call it */
    __ret__ = Test_Abslt_u08_s08(__arg__0);
}

static void _main_gen_call_Test_Abslt_u16_s16(void)
{
    extern __PST__UINT16 Test_Abslt_u16_s16(__PST__SINT16);

    __PST__UINT16 __ret__;
    __PST__SINT16 __arg__0;
    
    __arg__0 = _main_gen_init_g3();
    
    /* call it */
    __ret__ = Test_Abslt_u16_s16(__arg__0);
}

static void _main_gen_call_Test_Abslt_u32_s32(void)
{
    extern __PST__UINT32 Test_Abslt_u32_s32(__PST__SINT32);

    __PST__UINT32 __ret__;
    __PST__SINT32 __arg__0;
    
    __arg__0 = _main_gen_init_g4();
    
    /* call it */
    __ret__ = Test_Abslt_u32_s32(__arg__0);
}

static void _main_gen_call_Test_Abslt_f32_f32(void)
{
    extern __PST__FLOAT32 Test_Abslt_f32_f32(__PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    
    __arg__0 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Test_Abslt_f32_f32(__arg__0);
}

static void _main_gen_call_Test_Sign_s08_s08(void)
{
    extern __PST__SINT8 Test_Sign_s08_s08(__PST__SINT8);

    __PST__SINT8 __ret__;
    __PST__SINT8 __arg__0;
    
    __arg__0 = _main_gen_init_g2();
    
    /* call it */
    __ret__ = Test_Sign_s08_s08(__arg__0);
}

static void _main_gen_call_Test_Sign_s08_s16(void)
{
    extern __PST__SINT8 Test_Sign_s08_s16(__PST__SINT16);

    __PST__SINT8 __ret__;
    __PST__SINT16 __arg__0;
    
    __arg__0 = _main_gen_init_g3();
    
    /* call it */
    __ret__ = Test_Sign_s08_s16(__arg__0);
}

static void _main_gen_call_Test_Sign_s08_s32(void)
{
    extern __PST__SINT8 Test_Sign_s08_s32(__PST__SINT32);

    __PST__SINT8 __ret__;
    __PST__SINT32 __arg__0;
    
    __arg__0 = _main_gen_init_g4();
    
    /* call it */
    __ret__ = Test_Sign_s08_s32(__arg__0);
}

static void _main_gen_call_Test_Sign_s08_f32(void)
{
    extern __PST__SINT8 Test_Sign_s08_f32(__PST__FLOAT32);

    __PST__SINT8 __ret__;
    __PST__FLOAT32 __arg__0;
    
    __arg__0 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Test_Sign_s08_f32(__arg__0);
}

static void _main_gen_call_Test_Min_s08(void)
{
    extern __PST__SINT8 Test_Min_s08(__PST__SINT8, __PST__SINT8);

    __PST__SINT8 __ret__;
    __PST__SINT8 __arg__0;
    __PST__SINT8 __arg__1;
    
    __arg__0 = _main_gen_init_g2();
    __arg__1 = _main_gen_init_g2();
    
    /* call it */
    __ret__ = Test_Min_s08(__arg__0, __arg__1);
}

static void _main_gen_call_Test_Min_u08(void)
{
    extern __PST__UINT8 Test_Min_u08(__PST__UINT8, __PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__UINT8 __arg__0;
    __PST__UINT8 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = Test_Min_u08(__arg__0, __arg__1);
}

static void _main_gen_call_Test_Min_s16(void)
{
    extern __PST__SINT16 Test_Min_s16(__PST__SINT16, __PST__SINT16);

    __PST__SINT16 __ret__;
    __PST__SINT16 __arg__0;
    __PST__SINT16 __arg__1;
    
    __arg__0 = _main_gen_init_g3();
    __arg__1 = _main_gen_init_g3();
    
    /* call it */
    __ret__ = Test_Min_s16(__arg__0, __arg__1);
}

static void _main_gen_call_Test_Min_u16(void)
{
    extern __PST__UINT16 Test_Min_u16(__PST__UINT16, __PST__UINT16);

    __PST__UINT16 __ret__;
    __PST__UINT16 __arg__0;
    __PST__UINT16 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = Test_Min_u16(__arg__0, __arg__1);
}

static void _main_gen_call_Test_Min_s32(void)
{
    extern __PST__SINT32 Test_Min_s32(__PST__SINT32, __PST__SINT32);

    __PST__SINT32 __ret__;
    __PST__SINT32 __arg__0;
    __PST__SINT32 __arg__1;
    
    __arg__0 = _main_gen_init_g4();
    __arg__1 = _main_gen_init_g4();
    
    /* call it */
    __ret__ = Test_Min_s32(__arg__0, __arg__1);
}

static void _main_gen_call_Test_Min_u32(void)
{
    extern __PST__UINT32 Test_Min_u32(__PST__UINT32, __PST__UINT32);

    __PST__UINT32 __ret__;
    __PST__UINT32 __arg__0;
    __PST__UINT32 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    __arg__1 = _main_gen_init_g8();
    
    /* call it */
    __ret__ = Test_Min_u32(__arg__0, __arg__1);
}

static void _main_gen_call_Test_Min_f32(void)
{
    extern __PST__FLOAT32 Test_Min_f32(__PST__FLOAT32, __PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    __PST__FLOAT32 __arg__1;
    
    __arg__0 = _main_gen_init_g10();
    __arg__1 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Test_Min_f32(__arg__0, __arg__1);
}

static void _main_gen_call_Test_Max_s08(void)
{
    extern __PST__SINT8 Test_Max_s08(__PST__SINT8, __PST__SINT8);

    __PST__SINT8 __ret__;
    __PST__SINT8 __arg__0;
    __PST__SINT8 __arg__1;
    
    __arg__0 = _main_gen_init_g2();
    __arg__1 = _main_gen_init_g2();
    
    /* call it */
    __ret__ = Test_Max_s08(__arg__0, __arg__1);
}

static void _main_gen_call_Test_Max_u08(void)
{
    extern __PST__UINT8 Test_Max_u08(__PST__UINT8, __PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__UINT8 __arg__0;
    __PST__UINT8 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = Test_Max_u08(__arg__0, __arg__1);
}

static void _main_gen_call_Test_Max_s16(void)
{
    extern __PST__SINT16 Test_Max_s16(__PST__SINT16, __PST__SINT16);

    __PST__SINT16 __ret__;
    __PST__SINT16 __arg__0;
    __PST__SINT16 __arg__1;
    
    __arg__0 = _main_gen_init_g3();
    __arg__1 = _main_gen_init_g3();
    
    /* call it */
    __ret__ = Test_Max_s16(__arg__0, __arg__1);
}

static void _main_gen_call_Test_Max_u16(void)
{
    extern __PST__UINT16 Test_Max_u16(__PST__UINT16, __PST__UINT16);

    __PST__UINT16 __ret__;
    __PST__UINT16 __arg__0;
    __PST__UINT16 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = Test_Max_u16(__arg__0, __arg__1);
}

static void _main_gen_call_Test_Max_s32(void)
{
    extern __PST__SINT32 Test_Max_s32(__PST__SINT32, __PST__SINT32);

    __PST__SINT32 __ret__;
    __PST__SINT32 __arg__0;
    __PST__SINT32 __arg__1;
    
    __arg__0 = _main_gen_init_g4();
    __arg__1 = _main_gen_init_g4();
    
    /* call it */
    __ret__ = Test_Max_s32(__arg__0, __arg__1);
}

static void _main_gen_call_Test_Max_u32(void)
{
    extern __PST__UINT32 Test_Max_u32(__PST__UINT32, __PST__UINT32);

    __PST__UINT32 __ret__;
    __PST__UINT32 __arg__0;
    __PST__UINT32 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    __arg__1 = _main_gen_init_g8();
    
    /* call it */
    __ret__ = Test_Max_u32(__arg__0, __arg__1);
}

static void _main_gen_call_Test_Max_f32(void)
{
    extern __PST__FLOAT32 Test_Max_f32(__PST__FLOAT32, __PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    __PST__FLOAT32 __arg__1;
    
    __arg__0 = _main_gen_init_g10();
    __arg__1 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Test_Max_f32(__arg__0, __arg__1);
}

static void _main_gen_call_Test_Lim_s08(void)
{
    extern __PST__SINT8 Test_Lim_s08(__PST__SINT8, __PST__SINT8, __PST__SINT8);

    __PST__SINT8 __ret__;
    __PST__SINT8 __arg__0;
    __PST__SINT8 __arg__1;
    __PST__SINT8 __arg__2;
    
    __arg__0 = _main_gen_init_g2();
    __arg__1 = _main_gen_init_g2();
    __arg__2 = _main_gen_init_g2();
    
    /* call it */
    __ret__ = Test_Lim_s08(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_Test_Lim_u08(void)
{
    extern __PST__UINT8 Test_Lim_u08(__PST__UINT8, __PST__UINT8, __PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__UINT8 __arg__0;
    __PST__UINT8 __arg__1;
    __PST__UINT8 __arg__2;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g6();
    __arg__2 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = Test_Lim_u08(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_Test_Lim_s16(void)
{
    extern __PST__SINT16 Test_Lim_s16(__PST__SINT16, __PST__SINT16, __PST__SINT16);

    __PST__SINT16 __ret__;
    __PST__SINT16 __arg__0;
    __PST__SINT16 __arg__1;
    __PST__SINT16 __arg__2;
    
    __arg__0 = _main_gen_init_g3();
    __arg__1 = _main_gen_init_g3();
    __arg__2 = _main_gen_init_g3();
    
    /* call it */
    __ret__ = Test_Lim_s16(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_Test_Lim_u16(void)
{
    extern __PST__UINT16 Test_Lim_u16(__PST__UINT16, __PST__UINT16, __PST__UINT16);

    __PST__UINT16 __ret__;
    __PST__UINT16 __arg__0;
    __PST__UINT16 __arg__1;
    __PST__UINT16 __arg__2;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g7();
    __arg__2 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = Test_Lim_u16(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_Test_Lim_s32(void)
{
    extern __PST__SINT32 Test_Lim_s32(__PST__SINT32, __PST__SINT32, __PST__SINT32);

    __PST__SINT32 __ret__;
    __PST__SINT32 __arg__0;
    __PST__SINT32 __arg__1;
    __PST__SINT32 __arg__2;
    
    __arg__0 = _main_gen_init_g4();
    __arg__1 = _main_gen_init_g4();
    __arg__2 = _main_gen_init_g4();
    
    /* call it */
    __ret__ = Test_Lim_s32(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_Test_Lim_u32(void)
{
    extern __PST__UINT32 Test_Lim_u32(__PST__UINT32, __PST__UINT32, __PST__UINT32);

    __PST__UINT32 __ret__;
    __PST__UINT32 __arg__0;
    __PST__UINT32 __arg__1;
    __PST__UINT32 __arg__2;
    
    __arg__0 = _main_gen_init_g8();
    __arg__1 = _main_gen_init_g8();
    __arg__2 = _main_gen_init_g8();
    
    /* call it */
    __ret__ = Test_Lim_u32(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_Test_Lim_f32(void)
{
    extern __PST__FLOAT32 Test_Lim_f32(__PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    __PST__FLOAT32 __arg__1;
    __PST__FLOAT32 __arg__2;
    
    __arg__0 = _main_gen_init_g10();
    __arg__1 = _main_gen_init_g10();
    __arg__2 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Test_Lim_f32(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_Test_Arctan2_f32(void)
{
    extern __PST__FLOAT32 Test_Arctan2_f32(__PST__FLOAT32, __PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    __PST__FLOAT32 __arg__1;
    
    __arg__0 = _main_gen_init_g10();
    __arg__1 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Test_Arctan2_f32(__arg__0, __arg__1);
}

static void _main_gen_call_Test_Sin_f32(void)
{
    extern __PST__FLOAT32 Test_Sin_f32(__PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    
    __arg__0 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Test_Sin_f32(__arg__0);
}

static void _main_gen_call_Test_Cos_f32(void)
{
    extern __PST__FLOAT32 Test_Cos_f32(__PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    
    __arg__0 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Test_Cos_f32(__arg__0);
}

static void _main_gen_call_Test_Exp_f32(void)
{
    extern __PST__FLOAT32 Test_Exp_f32(__PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    
    __arg__0 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Test_Exp_f32(__arg__0);
}

static void _main_gen_call_Test_Sqrt_f32(void)
{
    extern __PST__FLOAT32 Test_Sqrt_f32(__PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    
    __arg__0 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Test_Sqrt_f32(__arg__0);
}

static void _main_gen_call_Test_Mod_f32(void)
{
    extern __PST__FLOAT32 Test_Mod_f32(__PST__FLOAT32, __PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    __PST__FLOAT32 __arg__1;
    
    __arg__0 = _main_gen_init_g10();
    __arg__1 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Test_Mod_f32(__arg__0, __arg__1);
}


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function Test_Blnd_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Blnd_f32();
        }
        
        /* call of function Test_Abslt_u08_s08 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Abslt_u08_s08();
        }
        
        /* call of function Test_Abslt_u16_s16 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Abslt_u16_s16();
        }
        
        /* call of function Test_Abslt_u32_s32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Abslt_u32_s32();
        }
        
        /* call of function Test_Abslt_f32_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Abslt_f32_f32();
        }
        
        /* call of function Test_Sign_s08_s08 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Sign_s08_s08();
        }
        
        /* call of function Test_Sign_s08_s16 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Sign_s08_s16();
        }
        
        /* call of function Test_Sign_s08_s32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Sign_s08_s32();
        }
        
        /* call of function Test_Sign_s08_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Sign_s08_f32();
        }
        
        /* call of function Test_Min_s08 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Min_s08();
        }
        
        /* call of function Test_Min_u08 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Min_u08();
        }
        
        /* call of function Test_Min_s16 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Min_s16();
        }
        
        /* call of function Test_Min_u16 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Min_u16();
        }
        
        /* call of function Test_Min_s32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Min_s32();
        }
        
        /* call of function Test_Min_u32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Min_u32();
        }
        
        /* call of function Test_Min_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Min_f32();
        }
        
        /* call of function Test_Max_s08 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Max_s08();
        }
        
        /* call of function Test_Max_u08 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Max_u08();
        }
        
        /* call of function Test_Max_s16 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Max_s16();
        }
        
        /* call of function Test_Max_u16 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Max_u16();
        }
        
        /* call of function Test_Max_s32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Max_s32();
        }
        
        /* call of function Test_Max_u32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Max_u32();
        }
        
        /* call of function Test_Max_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Max_f32();
        }
        
        /* call of function Test_Lim_s08 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Lim_s08();
        }
        
        /* call of function Test_Lim_u08 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Lim_u08();
        }
        
        /* call of function Test_Lim_s16 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Lim_s16();
        }
        
        /* call of function Test_Lim_u16 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Lim_u16();
        }
        
        /* call of function Test_Lim_s32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Lim_s32();
        }
        
        /* call of function Test_Lim_u32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Lim_u32();
        }
        
        /* call of function Test_Lim_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Lim_f32();
        }
        
        /* call of function Test_Arctan2_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Arctan2_f32();
        }
        
        /* call of function Test_Sin_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Sin_f32();
        }
        
        /* call of function Test_Cos_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Cos_f32();
        }
        
        /* call of function Test_Exp_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Exp_f32();
        }
        
        /* call of function Test_Sqrt_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Sqrt_f32();
        }
        
        /* call of function Test_Mod_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_Mod_f32();
        }
        
    }
}
