 #ifndef ELECGLBPRM_H
#define ELECGLBPRM_H

extern uint8 ELECGLBPRM_IVTRCNT_CNT_U08;

#endif
