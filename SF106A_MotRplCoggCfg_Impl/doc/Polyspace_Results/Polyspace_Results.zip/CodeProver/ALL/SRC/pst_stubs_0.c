#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * Rte_Read_MotRplCoggCfg_MotBackEmfConEstimd_Val
 */


__PST__UINT8 Rte_Read_MotRplCoggCfg_MotBackEmfConEstimd_Val(__PST__g__35 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_MotRplCoggCfg_MotCurrDaxCmd_Val
 */


__PST__UINT8 Rte_Read_MotRplCoggCfg_MotCurrDaxCmd_Val(__PST__g__35 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_MotRplCoggCfg_MotCurrQaxCmd_Val
 */


__PST__UINT8 Rte_Read_MotRplCoggCfg_MotCurrQaxCmd_Val(__PST__g__35 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_MotRplCoggCfg_MotInduDaxEstimd_Val
 */


__PST__UINT8 Rte_Read_MotRplCoggCfg_MotInduDaxEstimd_Val(__PST__g__35 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_MotRplCoggCfg_MotInduQaxEstimd_Val
 */


__PST__UINT8 Rte_Read_MotRplCoggCfg_MotInduQaxEstimd_Val(__PST__g__35 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_MotRplCoggCfg_MotTqCmdMrfScad_Val
 */


__PST__UINT8 Rte_Read_MotRplCoggCfg_MotTqCmdMrfScad_Val(__PST__g__35 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_MotRplCoggCfg_MotVelMrf_Val
 */


__PST__UINT8 Rte_Read_MotRplCoggCfg_MotVelMrf_Val(__PST__g__35 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_MotRplCoggCfg_MotAgElecDlyRpl_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_MotRplCoggCfg_MotAgElecDlyRpl_Val"


__PST__UINT8 Rte_Write_MotRplCoggCfg_MotAgElecDlyRpl_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_MotRplCoggCfg_MotCurrQaxToMotTqGain_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_MotRplCoggCfg_MotCurrQaxToMotTqGain_Val"


__PST__UINT8 Rte_Write_MotRplCoggCfg_MotCurrQaxToMotTqGain_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_MotRplCoggCfg_MotTqRplCoggOrder1Mgn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_MotRplCoggCfg_MotTqRplCoggOrder1Mgn_Val"


__PST__UINT8 Rte_Write_MotRplCoggCfg_MotTqRplCoggOrder1Mgn_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_MotRplCoggCfg_MotTqRplCoggOrder1Pha_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_MotRplCoggCfg_MotTqRplCoggOrder1Pha_Val"


__PST__UINT8 Rte_Write_MotRplCoggCfg_MotTqRplCoggOrder1Pha_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_MotRplCoggCfg_MotTqRplCoggOrder2Mgn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_MotRplCoggCfg_MotTqRplCoggOrder2Mgn_Val"


__PST__UINT8 Rte_Write_MotRplCoggCfg_MotTqRplCoggOrder2Mgn_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_MotRplCoggCfg_MotTqRplCoggOrder2Pha_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_MotRplCoggCfg_MotTqRplCoggOrder2Pha_Val"


__PST__UINT8 Rte_Write_MotRplCoggCfg_MotTqRplCoggOrder2Pha_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_MotRplCoggCfg_MotTqRplCoggOrder3Mgn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_MotRplCoggCfg_MotTqRplCoggOrder3Mgn_Val"


__PST__UINT8 Rte_Write_MotRplCoggCfg_MotTqRplCoggOrder3Mgn_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_MotRplCoggCfg_MotTqRplCoggOrder3Pha_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_MotRplCoggCfg_MotTqRplCoggOrder3Pha_Val"


__PST__UINT8 Rte_Write_MotRplCoggCfg_MotTqRplCoggOrder3Pha_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_MotRplCoggCfg_MotRplCoggPrm_GetErrorStatus
 */


__PST__UINT8 Rte_Call_MotRplCoggCfg_MotRplCoggPrm_GetErrorStatus(__PST__g__40 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_MotRplCoggCfg_MotRplCoggPrm_SetRamBlockStatus
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_MotRplCoggCfg_MotRplCoggPrm_SetRamBlockStatus"


__PST__UINT8 Rte_Call_MotRplCoggCfg_MotRplCoggPrm_SetRamBlockStatus(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotRplCoggCfg_MotCtrlPrmEstimnMotBackEmfConNom_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotRplCoggCfg_MotCtrlPrmEstimnMotBackEmfConNom_Val"


__PST__FLOAT32 Rte_Prm_MotRplCoggCfg_MotCtrlPrmEstimnMotBackEmfConNom_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotAgTiDly_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotAgTiDly_Val"


__PST__FLOAT32 Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotAgTiDly_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotRplCoggCfg_MotRplCoggCmdHrmncOrder1Elec_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotRplCoggCfg_MotRplCoggCmdHrmncOrder1Elec_Val"


__PST__UINT8 Rte_Prm_MotRplCoggCfg_MotRplCoggCmdHrmncOrder1Elec_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotRplCoggCfg_MotRplCoggCmdHrmncOrder2Elec_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotRplCoggCfg_MotRplCoggCmdHrmncOrder2Elec_Val"


__PST__UINT8 Rte_Prm_MotRplCoggCfg_MotRplCoggCmdHrmncOrder2Elec_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotRplCoggCfg_MotRplCoggCmdHrmncOrder3Elec_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotRplCoggCfg_MotRplCoggCmdHrmncOrder3Elec_Val"


__PST__UINT8 Rte_Prm_MotRplCoggCfg_MotRplCoggCmdHrmncOrder3Elec_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotRplCoggCfg_SysGlbPrmMotPoleCnt_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotRplCoggCfg_SysGlbPrmMotPoleCnt_Val"


__PST__UINT8 Rte_Prm_MotRplCoggCfg_SysGlbPrmMotPoleCnt_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotCurrDaxRplBilnrSeln_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotCurrDaxRplBilnrSeln_Ary1D"


__PST__g__45 Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotCurrDaxRplBilnrSeln_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__45 real_random_for_return ;
        __PST__g__45 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotCurrQaxRpl_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotCurrQaxRpl_Ary1D"


__PST__g__45 Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotCurrQaxRpl_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__45 real_random_for_return ;
        __PST__g__45 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqCmdCurrRgltrBwCmpMgnY_Ary2D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqCmdCurrRgltrBwCmpMgnY_Ary2D"


__PST__g__45 Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqCmdCurrRgltrBwCmpMgnY_Ary2D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__45 real_random_for_return ;
        __PST__g__45 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqCmdCurrRgltrBwCmpPhaY_Ary2D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqCmdCurrRgltrBwCmpPhaY_Ary2D"


__PST__g__45 Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqCmdCurrRgltrBwCmpPhaY_Ary2D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__45 real_random_for_return ;
        __PST__g__45 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqCmdCurrRgltrBwCmpX_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqCmdCurrRgltrBwCmpX_Ary1D"


__PST__g__45 Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqCmdCurrRgltrBwCmpX_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__45 real_random_for_return ;
        __PST__g__45 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqRplOrder1X_Ary2D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqRplOrder1X_Ary2D"


__PST__g__48 Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqRplOrder1X_Ary2D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__48 real_random_for_return ;
        __PST__g__48 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqRplOrder1Y_Ary2D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqRplOrder1Y_Ary2D"


__PST__g__48 Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqRplOrder1Y_Ary2D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__48 real_random_for_return ;
        __PST__g__48 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqRplOrder2X_Ary2D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqRplOrder2X_Ary2D"


__PST__g__48 Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqRplOrder2X_Ary2D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__48 real_random_for_return ;
        __PST__g__48 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqRplOrder2Y_Ary2D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqRplOrder2Y_Ary2D"


__PST__g__48 Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqRplOrder2Y_Ary2D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__48 real_random_for_return ;
        __PST__g__48 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqRplOrder3X_Ary2D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqRplOrder3X_Ary2D"


__PST__g__48 Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqRplOrder3X_Ary2D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__48 real_random_for_return ;
        __PST__g__48 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqRplOrder3Y_Ary2D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqRplOrder3Y_Ary2D"


__PST__g__48 Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotTqRplOrder3Y_Ary2D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__48 real_random_for_return ;
        __PST__g__48 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotVelBilnrSeln_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotVelBilnrSeln_Ary1D"


__PST__g__45 Rte_Prm_MotRplCoggCfg_MotRplCoggCfgMotVelBilnrSeln_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__45 real_random_for_return ;
        __PST__g__45 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * atan2f
 */

#pragma POLYSPACE_POLYMORPHIC "atan2f"


__PST__FLOAT32 atan2f(__PST__FLOAT32 P_0, __PST__FLOAT32 P_1)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * sqrtf
 */

#pragma POLYSPACE_POLYMORPHIC "sqrtf"


__PST__FLOAT32 sqrtf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * fabsf
 */

#pragma POLYSPACE_POLYMORPHIC "fabsf"


__PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * BilnrIntrpnWithRound_u16_u16CmnXu16MplY
 */

#pragma POLYSPACE_POLYMORPHIC "BilnrIntrpnWithRound_u16_u16CmnXu16MplY"


__PST__UINT16 BilnrIntrpnWithRound_u16_u16CmnXu16MplY(__PST__UINT16 P_0, __PST__UINT16 P_1, __PST__g__45 P_2, __PST__UINT16 P_3, __PST__g__45 P_4, __PST__g__45 P_5, __PST__UINT16 P_6)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * BilnrIntrpnWithRound_s16_u16CmnXs16MplY
 */

#pragma POLYSPACE_POLYMORPHIC "BilnrIntrpnWithRound_s16_u16CmnXs16MplY"


__PST__SINT16 BilnrIntrpnWithRound_s16_u16CmnXs16MplY(__PST__UINT16 P_0, __PST__UINT16 P_1, __PST__g__45 P_2, __PST__UINT16 P_3, __PST__g__45 P_4, __PST__g__48 P_5, __PST__UINT16 P_6)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__SINT16 real_random_for_return  = 0;
        __PST__SINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

