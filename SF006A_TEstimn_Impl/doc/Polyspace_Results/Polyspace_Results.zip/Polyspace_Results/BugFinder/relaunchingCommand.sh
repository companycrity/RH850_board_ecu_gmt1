#!/bin/sh
polyspace-bug-finder-nodesktop -options-file server-options.opt
