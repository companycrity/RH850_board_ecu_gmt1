/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function expf
//
// #pragma POLYSPACE_PURE "expf"
// #pragma POLYSPACE_CLEAN "expf"
// #pragma POLYSPACE_WORST "expf"
//
// __PST__FLOAT32 expf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_TEstimn_AmbT_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_TEstimn_AmbT_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_TEstimn_AmbT_Val"
// #pragma POLYSPACE_WORST "Rte_Read_TEstimn_AmbT_Val"
//
// __PST__UINT8 Rte_Read_TEstimn_AmbT_Val(__PST__g__29 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_TEstimn_AmbTVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_TEstimn_AmbTVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_TEstimn_AmbTVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_TEstimn_AmbTVld_Logl"
//
// __PST__UINT8 Rte_Read_TEstimn_AmbTVld_Logl(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_TEstimn_AssiMechTEstimnDi_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_TEstimn_AssiMechTEstimnDi_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_TEstimn_AssiMechTEstimnDi_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_TEstimn_AssiMechTEstimnDi_Logl"
//
// __PST__UINT8 Rte_Read_TEstimn_AssiMechTEstimnDi_Logl(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_TEstimn_EcuTFild_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_TEstimn_EcuTFild_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_TEstimn_EcuTFild_Val"
// #pragma POLYSPACE_WORST "Rte_Read_TEstimn_EcuTFild_Val"
//
// __PST__UINT8 Rte_Read_TEstimn_EcuTFild_Val(__PST__g__29 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_TEstimn_EngOilT_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_TEstimn_EngOilT_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_TEstimn_EngOilT_Val"
// #pragma POLYSPACE_WORST "Rte_Read_TEstimn_EngOilT_Val"
//
// __PST__UINT8 Rte_Read_TEstimn_EngOilT_Val(__PST__g__29 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_TEstimn_EngOilTVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_TEstimn_EngOilTVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_TEstimn_EngOilTVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_TEstimn_EngOilTVld_Logl"
//
// __PST__UINT8 Rte_Read_TEstimn_EngOilTVld_Logl(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_TEstimn_HwVel_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_TEstimn_HwVel_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_TEstimn_HwVel_Val"
// #pragma POLYSPACE_WORST "Rte_Read_TEstimn_HwVel_Val"
//
// __PST__UINT8 Rte_Read_TEstimn_HwVel_Val(__PST__g__29 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_TEstimn_MotCurrPeakEstimd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_TEstimn_MotCurrPeakEstimd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_TEstimn_MotCurrPeakEstimd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_TEstimn_MotCurrPeakEstimd_Val"
//
// __PST__UINT8 Rte_Read_TEstimn_MotCurrPeakEstimd_Val(__PST__g__29 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_TEstimn_AssiMechT_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_TEstimn_AssiMechT_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_TEstimn_AssiMechT_Val"
// #pragma POLYSPACE_WORST "Rte_Write_TEstimn_AssiMechT_Val"
//
// __PST__UINT8 Rte_Write_TEstimn_AssiMechT_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_TEstimn_MotFetT_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_TEstimn_MotFetT_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_TEstimn_MotFetT_Val"
// #pragma POLYSPACE_WORST "Rte_Write_TEstimn_MotFetT_Val"
//
// __PST__UINT8 Rte_Write_TEstimn_MotFetT_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_TEstimn_MotMagT_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_TEstimn_MotMagT_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_TEstimn_MotMagT_Val"
// #pragma POLYSPACE_WORST "Rte_Write_TEstimn_MotMagT_Val"
//
// __PST__UINT8 Rte_Write_TEstimn_MotMagT_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_TEstimn_MotWidgT_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_TEstimn_MotWidgT_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_TEstimn_MotWidgT_Val"
// #pragma POLYSPACE_WORST "Rte_Write_TEstimn_MotWidgT_Val"
//
// __PST__UINT8 Rte_Write_TEstimn_MotWidgT_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnAmbPwrMplr_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnAmbPwrMplr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnAmbPwrMplr_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnAmbPwrMplr_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnAmbPwrMplr_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnAmbTSca_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnAmbTSca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnAmbTSca_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnAmbTSca_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnAmbTSca_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnAssiMechAmbLpFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnAssiMechAmbLpFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnAssiMechAmbLpFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnAssiMechAmbLpFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnAssiMechAmbLpFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnAssiMechAmbMplr_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnAssiMechAmbMplr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnAssiMechAmbMplr_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnAssiMechAmbMplr_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnAssiMechAmbMplr_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnAssiMechCorrLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnAssiMechCorrLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnAssiMechCorrLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnAssiMechCorrLim_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnAssiMechCorrLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnAssiMechDampgSca_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnAssiMechDampgSca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnAssiMechDampgSca_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnAssiMechDampgSca_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnAssiMechDampgSca_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnAssiMechDftT_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnAssiMechDftT_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnAssiMechDftT_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnAssiMechDftT_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnAssiMechDftT_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnAssiMechLLFilCoeffA1_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnAssiMechLLFilCoeffA1_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnAssiMechLLFilCoeffA1_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnAssiMechLLFilCoeffA1_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnAssiMechLLFilCoeffA1_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnAssiMechLLFilCoeffB0_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnAssiMechLLFilCoeffB0_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnAssiMechLLFilCoeffB0_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnAssiMechLLFilCoeffB0_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnAssiMechLLFilCoeffB0_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnAssiMechLLFilCoeffB1_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnAssiMechLLFilCoeffB1_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnAssiMechLLFilCoeffB1_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnAssiMechLLFilCoeffB1_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnAssiMechLLFilCoeffB1_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnAssiMechSlew_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnAssiMechSlew_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnAssiMechSlew_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnAssiMechSlew_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnAssiMechSlew_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnCorrnTAssiMech_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnCorrnTAssiMech_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnCorrnTAssiMech_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnCorrnTAssiMech_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnCorrnTAssiMech_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnCorrnTCu_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnCorrnTCu_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnCorrnTCu_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnCorrnTCu_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnCorrnTCu_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnCorrnTMag_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnCorrnTMag_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnCorrnTMag_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnCorrnTMag_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnCorrnTMag_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnCorrnTSi_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnCorrnTSi_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnCorrnTSi_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnCorrnTSi_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnCorrnTSi_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnCuAmbLpFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnCuAmbLpFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnCuAmbLpFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnCuAmbLpFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnCuAmbLpFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnCuAmbMplr_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnCuAmbMplr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnCuAmbMplr_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnCuAmbMplr_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnCuAmbMplr_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnCuCorrnLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnCuCorrnLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnCuCorrnLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnCuCorrnLim_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnCuCorrnLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnCuLLFilCoeffA1_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnCuLLFilCoeffA1_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnCuLLFilCoeffA1_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnCuLLFilCoeffA1_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnCuLLFilCoeffA1_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnCuLLFilCoeffB0_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnCuLLFilCoeffB0_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnCuLLFilCoeffB0_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnCuLLFilCoeffB0_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnCuLLFilCoeffB0_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnCuLLFilCoeffB1_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnCuLLFilCoeffB1_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnCuLLFilCoeffB1_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnCuLLFilCoeffB1_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnCuLLFilCoeffB1_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnEngTSca_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnEngTSca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnEngTSca_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnEngTSca_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnEngTSca_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnMagAmbLpFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnMagAmbLpFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnMagAmbLpFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnMagAmbLpFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnMagAmbLpFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnMagAmbMplr_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnMagAmbMplr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnMagAmbMplr_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnMagAmbMplr_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnMagAmbMplr_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnMagCorrnLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnMagCorrnLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnMagCorrnLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnMagCorrnLim_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnMagCorrnLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnMagLLFilCoeffA1_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnMagLLFilCoeffA1_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnMagLLFilCoeffA1_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnMagLLFilCoeffA1_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnMagLLFilCoeffA1_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnMagLLFilCoeffB0_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnMagLLFilCoeffB0_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnMagLLFilCoeffB0_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnMagLLFilCoeffB0_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnMagLLFilCoeffB0_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnMagLLFilCoeffB1_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnMagLLFilCoeffB1_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnMagLLFilCoeffB1_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnMagLLFilCoeffB1_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnMagLLFilCoeffB1_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnSiAmbLpFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnSiAmbLpFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnSiAmbLpFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnSiAmbLpFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnSiAmbLpFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnSiAmbMplr_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnSiAmbMplr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnSiAmbMplr_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnSiAmbMplr_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnSiAmbMplr_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnSiCorrnLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnSiCorrnLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnSiCorrnLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnSiCorrnLim_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnSiCorrnLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnSiLLFilCoeffA1_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnSiLLFilCoeffA1_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnSiLLFilCoeffA1_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnSiLLFilCoeffA1_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnSiLLFilCoeffA1_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnSiLLFilCoeffB0_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnSiLLFilCoeffB0_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnSiLLFilCoeffB0_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnSiLLFilCoeffB0_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnSiLLFilCoeffB0_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnSiLLFilCoeffB1_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnSiLLFilCoeffB1_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnSiLLFilCoeffB1_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnSiLLFilCoeffB1_Val"
//
// __PST__FLOAT32 Rte_Prm_TEstimn_TEstimnSiLLFilCoeffB1_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_TEstimn_TEstimnWghtAvrgTDi_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_TEstimn_TEstimnWghtAvrgTDi_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_TEstimn_TEstimnWghtAvrgTDi_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_TEstimn_TEstimnWghtAvrgTDi_Logl"
//
// __PST__UINT8 Rte_Prm_TEstimn_TEstimnWghtAvrgTDi_Logl(__PST__VOID)
// {
//    ...
// }

