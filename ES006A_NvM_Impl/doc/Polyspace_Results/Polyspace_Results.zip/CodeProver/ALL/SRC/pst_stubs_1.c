#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */

/*
 * _stub_p_g_54
 */

#pragma POLYSPACE_POLYMORPHIC "_stub_p_g_54"


static __PST__VOID _stub_p_g_54(__PST__VOID)
{
    /* function is pure */

    return;
}


/* Definition of init procedures */

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct Rte_CDS_CDD_NvMProxy _main_gen_init_g34(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

struct Rte_CDS_CDD_NvMProxy _main_gen_init_g34(void)
{
    static struct Rte_CDS_CDD_NvMProxy x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__g__36 _main_gen_tmp_30[ARRAY_NBELEM(__PST__g__36)];
        __PST__UINT32 _i_main_gen_tmp_31;
        for (_i_main_gen_tmp_31 = 0; _i_main_gen_tmp_31 < ARRAY_NBELEM(__PST__g__36); _i_main_gen_tmp_31++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_32_0;
                
                for (_main_gen_tmp_32_0 = 0; _main_gen_tmp_32_0 < 5; _main_gen_tmp_32_0++)
                {
                    /* struct/union type */
                    _main_gen_tmp_30[_i_main_gen_tmp_31][_main_gen_tmp_32_0].Sts = _main_gen_init_g6();
                    _main_gen_tmp_30[_i_main_gen_tmp_31][_main_gen_tmp_32_0].Prm = _main_gen_init_g6();
                }
            }
        }
        x.Pim_BlkFltTbl = PST_TRUE() ? 0 : &_main_gen_tmp_30[ARRAY_NBELEM(__PST__g__36) / 2];
    }
    /* pointer */
    {
        static __PST__g__39 _main_gen_tmp_33[ARRAY_NBELEM(__PST__g__39)];
        __PST__UINT32 _i_main_gen_tmp_34;
        for (_i_main_gen_tmp_34 = 0; _i_main_gen_tmp_34 < ARRAY_NBELEM(__PST__g__39); _i_main_gen_tmp_34++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_35_0;
                
                for (_main_gen_tmp_35_0 = 0; _main_gen_tmp_35_0 < 30; _main_gen_tmp_35_0++)
                {
                    /* struct/union type */
                    _main_gen_tmp_33[_i_main_gen_tmp_34][_main_gen_tmp_35_0].StdRtn = _main_gen_init_g6();
                    _main_gen_tmp_33[_i_main_gen_tmp_34][_main_gen_tmp_35_0].ReqRes = _main_gen_init_g6();
                }
            }
        }
        x.Pim_CmdRtnBuf = PST_TRUE() ? 0 : &_main_gen_tmp_33[ARRAY_NBELEM(__PST__g__39) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_36[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_37;
        for (_i_main_gen_tmp_37 = 0; _i_main_gen_tmp_37 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_37++)
        {
            _main_gen_tmp_36[_i_main_gen_tmp_37] = _main_gen_init_g8();
        }
        x.Pim_ShtdwnClsChk = PST_TRUE() ? 0 : &_main_gen_tmp_36[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_NvMProxy(void)
{
    extern __PST__g__31 Rte_Inst_CDD_NvMProxy;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_NvMProxy _main_gen_tmp_28[ARRAY_NBELEM(struct Rte_CDS_CDD_NvMProxy)];
            __PST__UINT32 _i_main_gen_tmp_29;
            for (_i_main_gen_tmp_29 = 0; _i_main_gen_tmp_29 < ARRAY_NBELEM(struct Rte_CDS_CDD_NvMProxy); _i_main_gen_tmp_29++)
            {
                _main_gen_tmp_28[_i_main_gen_tmp_29] = _main_gen_init_g34();
            }
            Rte_Inst_CDD_NvMProxy = PST_TRUE() ? 0 : &_main_gen_tmp_28[ARRAY_NBELEM(struct Rte_CDS_CDD_NvMProxy) / 2];
        }
    }
}

static void _main_gen_init_sym_NvMProxy_CrcFltDescrTbl(void)
{
    extern __PST__g__50 NvMProxy_CrcFltDescrTbl;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_38_0;
            
            for (_main_gen_tmp_38_0 = 0; _main_gen_tmp_38_0 < pst_random_g_8; _main_gen_tmp_38_0++)
            {
                /* struct/union type */
                /* function pointer */
                NvMProxy_CrcFltDescrTbl[_main_gen_tmp_38_0].FctCallBack = PST_TRUE() ? 0 : _stub_p_g_54;
                NvMProxy_CrcFltDescrTbl[_main_gen_tmp_38_0].NvmBlkId = _main_gen_init_g7();
                NvMProxy_CrcFltDescrTbl[_main_gen_tmp_38_0].FltResp = _main_gen_init_g6();
            }
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_CDD_NvMProxy */
    _main_gen_init_sym_Rte_Inst_CDD_NvMProxy();
    
    /* init for variable NvMProxy_CrcFltDescrTbl */
    _main_gen_init_sym_NvMProxy_CrcFltDescrTbl();
    
}
