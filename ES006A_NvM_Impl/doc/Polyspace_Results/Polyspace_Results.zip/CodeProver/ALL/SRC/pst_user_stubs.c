/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Rte_Call_CDD_NvMProxy_SetNtcSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_NvMProxy_SetNtcSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_NvMProxy_SetNtcSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_NvMProxy_SetNtcSts_Oper"
//
// __PST__UINT8 Rte_Call_CDD_NvMProxy_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
// {
//    ...
// }


// Pragmas for function osGetApplicationID
//
// #pragma POLYSPACE_PURE "osGetApplicationID"
// #pragma POLYSPACE_CLEAN "osGetApplicationID"
// #pragma POLYSPACE_WORST "osGetApplicationID"
//
// __PST__UINT8 osGetApplicationID(__PST__VOID)
// {
//    ...
// }


// Pragmas for function osPsysCallNonTrustedFunction
//
// #pragma POLYSPACE_PURE "osPsysCallNonTrustedFunction"
// #pragma POLYSPACE_CLEAN "osPsysCallNonTrustedFunction"
// #pragma POLYSPACE_WORST "osPsysCallNonTrustedFunction"
//
// __PST__UINT8 osPsysCallNonTrustedFunction(__PST__UINT16 P_0, __PST__g__11 P_1)
// {
//    ...
// }


// Pragmas for function NvM_SetDataIndex
//
// #pragma POLYSPACE_PURE "NvM_SetDataIndex"
// #pragma POLYSPACE_CLEAN "NvM_SetDataIndex"
// #pragma POLYSPACE_WORST "NvM_SetDataIndex"
//
// __PST__UINT8 NvM_SetDataIndex(__PST__UINT16 P_0, __PST__UINT8 P_1)
// {
//    ...
// }


// Pragmas for function NvM_GetDataIndex
//
// #pragma POLYSPACE_PURE "NvM_GetDataIndex"
// #pragma POLYSPACE_CLEAN "NvM_GetDataIndex"
// #pragma POLYSPACE_WORST "NvM_GetDataIndex"
//
// __PST__UINT8 NvM_GetDataIndex(__PST__UINT16 P_0, __PST__g__18 P_1)
// {
//    ...
// }


// Pragmas for function NvM_SetBlockProtection
//
// #pragma POLYSPACE_PURE "NvM_SetBlockProtection"
// #pragma POLYSPACE_CLEAN "NvM_SetBlockProtection"
// #pragma POLYSPACE_WORST "NvM_SetBlockProtection"
//
// __PST__UINT8 NvM_SetBlockProtection(__PST__UINT16 P_0, __PST__UINT8 P_1)
// {
//    ...
// }


// Pragmas for function NvM_GetErrorStatus
//
// #pragma POLYSPACE_PURE "NvM_GetErrorStatus"
// #pragma POLYSPACE_CLEAN "NvM_GetErrorStatus"
// #pragma POLYSPACE_WORST "NvM_GetErrorStatus"
//
// __PST__UINT8 NvM_GetErrorStatus(__PST__UINT16 P_0, __PST__g__18 P_1)
// {
//    ...
// }


// Pragmas for function NvM_SetRamBlockStatus
//
// #pragma POLYSPACE_PURE "NvM_SetRamBlockStatus"
// #pragma POLYSPACE_CLEAN "NvM_SetRamBlockStatus"
// #pragma POLYSPACE_WORST "NvM_SetRamBlockStatus"
//
// __PST__UINT8 NvM_SetRamBlockStatus(__PST__UINT16 P_0, __PST__UINT8 P_1)
// {
//    ...
// }


// Pragmas for function NvM_ReadBlock
//
// #pragma POLYSPACE_PURE "NvM_ReadBlock"
// #pragma POLYSPACE_CLEAN "NvM_ReadBlock"
// #pragma POLYSPACE_WORST "NvM_ReadBlock"
//
// __PST__UINT8 NvM_ReadBlock(__PST__UINT16 P_0, __PST__g__11 P_1)
// {
//    ...
// }


// Pragmas for function NvM_WriteBlock
//
// #pragma POLYSPACE_PURE "NvM_WriteBlock"
// #pragma POLYSPACE_CLEAN "NvM_WriteBlock"
// #pragma POLYSPACE_WORST "NvM_WriteBlock"
//
// __PST__UINT8 NvM_WriteBlock(__PST__UINT16 P_0, __PST__g__48 P_1)
// {
//    ...
// }


// Pragmas for function NvM_EraseNvBlock
//
// #pragma POLYSPACE_PURE "NvM_EraseNvBlock"
// #pragma POLYSPACE_CLEAN "NvM_EraseNvBlock"
// #pragma POLYSPACE_WORST "NvM_EraseNvBlock"
//
// __PST__UINT8 NvM_EraseNvBlock(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function NvM_InvalidateNvBlock
//
// #pragma POLYSPACE_PURE "NvM_InvalidateNvBlock"
// #pragma POLYSPACE_CLEAN "NvM_InvalidateNvBlock"
// #pragma POLYSPACE_WORST "NvM_InvalidateNvBlock"
//
// __PST__UINT8 NvM_InvalidateNvBlock(__PST__UINT16 P_0)
// {
//    ...
// }

