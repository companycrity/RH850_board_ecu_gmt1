#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__SINT8 pst_random_g_2;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT16 _main_gen_init_g7(void);

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}


/* Definition of variables init procedures */


/* Definition of functions */

static void _main_gen_call_NvMProxy_EraseNvBlock(void)
{
    extern __PST__UINT8 NvMProxy_EraseNvBlock(__PST__UINT16);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    
    __arg__0 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = NvMProxy_EraseNvBlock(__arg__0);
}

static void _main_gen_call_NvMProxy_GetDataIndex(void)
{
    extern __PST__UINT8 NvMProxy_GetDataIndex(__PST__UINT16, __PST__g__18);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    __PST__g__18 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_1;
        for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_1++)
        {
            _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    __ret__ = NvMProxy_GetDataIndex(__arg__0, __arg__1);
}

static void _main_gen_call_NvMProxy_GetErrorStatus(void)
{
    extern __PST__UINT8 NvMProxy_GetErrorStatus(__PST__UINT16, __PST__g__18);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    __PST__g__18 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    __ret__ = NvMProxy_GetErrorStatus(__arg__0, __arg__1);
}

static void _main_gen_call_NvMProxy_InvalidateNvBlock(void)
{
    extern __PST__UINT8 NvMProxy_InvalidateNvBlock(__PST__UINT16);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    
    __arg__0 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = NvMProxy_InvalidateNvBlock(__arg__0);
}

static void _main_gen_call_NvMProxy_ReadBlock(void)
{
    extern __PST__UINT8 NvMProxy_ReadBlock(__PST__UINT16, __PST__g__18);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    __PST__g__18 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    __ret__ = NvMProxy_ReadBlock(__arg__0, __arg__1);
}

static void _main_gen_call_NvMProxy_RestoreBlockDefaults(void)
{
    extern __PST__UINT8 NvMProxy_RestoreBlockDefaults(__PST__UINT16, __PST__g__18);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    __PST__g__18 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    __ret__ = NvMProxy_RestoreBlockDefaults(__arg__0, __arg__1);
}

static void _main_gen_call_NvMProxy_SetBlockProtection(void)
{
    extern __PST__UINT8 NvMProxy_SetBlockProtection(__PST__UINT16, __PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    __PST__UINT8 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = NvMProxy_SetBlockProtection(__arg__0, __arg__1);
}

static void _main_gen_call_NvMProxy_SetDataIndex(void)
{
    extern __PST__UINT8 NvMProxy_SetDataIndex(__PST__UINT16, __PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    __PST__UINT8 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = NvMProxy_SetDataIndex(__arg__0, __arg__1);
}

static void _main_gen_call_NvMProxy_SetRamBlockStatus(void)
{
    extern __PST__UINT8 NvMProxy_SetRamBlockStatus(__PST__UINT16, __PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    __PST__UINT8 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = NvMProxy_SetRamBlockStatus(__arg__0, __arg__1);
}

static void _main_gen_call_NvMProxy_WriteBlock(void)
{
    extern __PST__UINT8 NvMProxy_WriteBlock(__PST__UINT16, __PST__g__21);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    __PST__g__21 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    __ret__ = NvMProxy_WriteBlock(__arg__0, __arg__1);
}

static void _main_gen_call_NONTRUSTED_NtWrapS_NvM_EraseNvBlock(void)
{
    extern __PST__VOID NONTRUSTED_NtWrapS_NvM_EraseNvBlock(__PST__UINT16, __PST__g__11);

    __PST__UINT16 __arg__0;
    __PST__g__11 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT8 _main_gen_tmp_10[ARRAY_NBELEM(__PST__SINT8)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g2();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__SINT8) / 2];
    }
    
    /* call it */
    NONTRUSTED_NtWrapS_NvM_EraseNvBlock(__arg__0, __arg__1);
}

static void _main_gen_call_NONTRUSTED_NtWrapS_NvM_GetErrorStatus(void)
{
    extern __PST__VOID NONTRUSTED_NtWrapS_NvM_GetErrorStatus(__PST__UINT16, __PST__g__11);

    __PST__UINT16 __arg__0;
    __PST__g__11 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT8 _main_gen_tmp_12[ARRAY_NBELEM(__PST__SINT8)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g2();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__SINT8) / 2];
    }
    
    /* call it */
    NONTRUSTED_NtWrapS_NvM_GetErrorStatus(__arg__0, __arg__1);
}

static void _main_gen_call_NONTRUSTED_NtWrapS_NvM_InvalidateNvBlock(void)
{
    extern __PST__VOID NONTRUSTED_NtWrapS_NvM_InvalidateNvBlock(__PST__UINT16, __PST__g__11);

    __PST__UINT16 __arg__0;
    __PST__g__11 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT8 _main_gen_tmp_14[ARRAY_NBELEM(__PST__SINT8)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g2();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(__PST__SINT8) / 2];
    }
    
    /* call it */
    NONTRUSTED_NtWrapS_NvM_InvalidateNvBlock(__arg__0, __arg__1);
}

static void _main_gen_call_NONTRUSTED_NtWrapS_NvM_ReadBlock(void)
{
    extern __PST__VOID NONTRUSTED_NtWrapS_NvM_ReadBlock(__PST__UINT16, __PST__g__11);

    __PST__UINT16 __arg__0;
    __PST__g__11 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT8 _main_gen_tmp_16[ARRAY_NBELEM(__PST__SINT8)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g2();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__SINT8) / 2];
    }
    
    /* call it */
    NONTRUSTED_NtWrapS_NvM_ReadBlock(__arg__0, __arg__1);
}

static void _main_gen_call_NONTRUSTED_NtWrapS_NvM_SetBlockProtection(void)
{
    extern __PST__VOID NONTRUSTED_NtWrapS_NvM_SetBlockProtection(__PST__UINT16, __PST__g__11);

    __PST__UINT16 __arg__0;
    __PST__g__11 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT8 _main_gen_tmp_18[ARRAY_NBELEM(__PST__SINT8)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g2();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(__PST__SINT8) / 2];
    }
    
    /* call it */
    NONTRUSTED_NtWrapS_NvM_SetBlockProtection(__arg__0, __arg__1);
}

static void _main_gen_call_NONTRUSTED_NtWrapS_NvM_SetRamBlockStatus(void)
{
    extern __PST__VOID NONTRUSTED_NtWrapS_NvM_SetRamBlockStatus(__PST__UINT16, __PST__g__11);

    __PST__UINT16 __arg__0;
    __PST__g__11 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT8 _main_gen_tmp_20[ARRAY_NBELEM(__PST__SINT8)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g2();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(__PST__SINT8) / 2];
    }
    
    /* call it */
    NONTRUSTED_NtWrapS_NvM_SetRamBlockStatus(__arg__0, __arg__1);
}

static void _main_gen_call_NONTRUSTED_NtWrapS_NvM_SetDataIndex(void)
{
    extern __PST__VOID NONTRUSTED_NtWrapS_NvM_SetDataIndex(__PST__UINT16, __PST__g__11);

    __PST__UINT16 __arg__0;
    __PST__g__11 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT8 _main_gen_tmp_22[ARRAY_NBELEM(__PST__SINT8)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g2();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__SINT8) / 2];
    }
    
    /* call it */
    NONTRUSTED_NtWrapS_NvM_SetDataIndex(__arg__0, __arg__1);
}

static void _main_gen_call_NONTRUSTED_NtWrapS_NvM_GetDataIndex(void)
{
    extern __PST__VOID NONTRUSTED_NtWrapS_NvM_GetDataIndex(__PST__UINT16, __PST__g__11);

    __PST__UINT16 __arg__0;
    __PST__g__11 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT8 _main_gen_tmp_24[ARRAY_NBELEM(__PST__SINT8)];
        __PST__UINT32 _i_main_gen_tmp_25;
        for (_i_main_gen_tmp_25 = 0; _i_main_gen_tmp_25 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_25++)
        {
            _main_gen_tmp_24[_i_main_gen_tmp_25] = _main_gen_init_g2();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_24[ARRAY_NBELEM(__PST__SINT8) / 2];
    }
    
    /* call it */
    NONTRUSTED_NtWrapS_NvM_GetDataIndex(__arg__0, __arg__1);
}

static void _main_gen_call_NONTRUSTED_NtWrapS_NvM_WriteBlock(void)
{
    extern __PST__VOID NONTRUSTED_NtWrapS_NvM_WriteBlock(__PST__UINT16, __PST__g__11);

    __PST__UINT16 __arg__0;
    __PST__g__11 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT8 _main_gen_tmp_26[ARRAY_NBELEM(__PST__SINT8)];
        __PST__UINT32 _i_main_gen_tmp_27;
        for (_i_main_gen_tmp_27 = 0; _i_main_gen_tmp_27 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_27++)
        {
            _main_gen_tmp_26[_i_main_gen_tmp_27] = _main_gen_init_g2();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_26[ARRAY_NBELEM(__PST__SINT8) / 2];
    }
    
    /* call it */
    NONTRUSTED_NtWrapS_NvM_WriteBlock(__arg__0, __arg__1);
}

static void _main_gen_call_NvMProxy_ClsChkWr_Oper(void)
{
    extern __PST__UINT8 NvMProxy_ClsChkWr_Oper(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = NvMProxy_ClsChkWr_Oper();
}


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function NvMProxyInit1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID NvMProxyInit1(__PST__VOID);

            NvMProxyInit1();
        }
        
        /* call of function NvMProxy_EraseNvBlock */
        if (PST_TRUE())
        {
            _main_gen_call_NvMProxy_EraseNvBlock();
        }
        
        /* call of function NvMProxy_GetDataIndex */
        if (PST_TRUE())
        {
            _main_gen_call_NvMProxy_GetDataIndex();
        }
        
        /* call of function NvMProxy_GetErrorStatus */
        if (PST_TRUE())
        {
            _main_gen_call_NvMProxy_GetErrorStatus();
        }
        
        /* call of function NvMProxy_InvalidateNvBlock */
        if (PST_TRUE())
        {
            _main_gen_call_NvMProxy_InvalidateNvBlock();
        }
        
        /* call of function NvMProxy_ReadBlock */
        if (PST_TRUE())
        {
            _main_gen_call_NvMProxy_ReadBlock();
        }
        
        /* call of function NvMProxy_RestoreBlockDefaults */
        if (PST_TRUE())
        {
            _main_gen_call_NvMProxy_RestoreBlockDefaults();
        }
        
        /* call of function NvMProxy_SetBlockProtection */
        if (PST_TRUE())
        {
            _main_gen_call_NvMProxy_SetBlockProtection();
        }
        
        /* call of function NvMProxy_SetDataIndex */
        if (PST_TRUE())
        {
            _main_gen_call_NvMProxy_SetDataIndex();
        }
        
        /* call of function NvMProxy_SetRamBlockStatus */
        if (PST_TRUE())
        {
            _main_gen_call_NvMProxy_SetRamBlockStatus();
        }
        
        /* call of function NvMProxy_WriteBlock */
        if (PST_TRUE())
        {
            _main_gen_call_NvMProxy_WriteBlock();
        }
        
        /* call of function NONTRUSTED_NtWrapS_NvM_EraseNvBlock */
        if (PST_TRUE())
        {
            _main_gen_call_NONTRUSTED_NtWrapS_NvM_EraseNvBlock();
        }
        
        /* call of function NONTRUSTED_NtWrapS_NvM_GetErrorStatus */
        if (PST_TRUE())
        {
            _main_gen_call_NONTRUSTED_NtWrapS_NvM_GetErrorStatus();
        }
        
        /* call of function NONTRUSTED_NtWrapS_NvM_InvalidateNvBlock */
        if (PST_TRUE())
        {
            _main_gen_call_NONTRUSTED_NtWrapS_NvM_InvalidateNvBlock();
        }
        
        /* call of function NONTRUSTED_NtWrapS_NvM_ReadBlock */
        if (PST_TRUE())
        {
            _main_gen_call_NONTRUSTED_NtWrapS_NvM_ReadBlock();
        }
        
        /* call of function NONTRUSTED_NtWrapS_NvM_SetBlockProtection */
        if (PST_TRUE())
        {
            _main_gen_call_NONTRUSTED_NtWrapS_NvM_SetBlockProtection();
        }
        
        /* call of function NONTRUSTED_NtWrapS_NvM_SetRamBlockStatus */
        if (PST_TRUE())
        {
            _main_gen_call_NONTRUSTED_NtWrapS_NvM_SetRamBlockStatus();
        }
        
        /* call of function NONTRUSTED_NtWrapS_NvM_SetDataIndex */
        if (PST_TRUE())
        {
            _main_gen_call_NONTRUSTED_NtWrapS_NvM_SetDataIndex();
        }
        
        /* call of function NONTRUSTED_NtWrapS_NvM_GetDataIndex */
        if (PST_TRUE())
        {
            _main_gen_call_NONTRUSTED_NtWrapS_NvM_GetDataIndex();
        }
        
        /* call of function NONTRUSTED_NtWrapS_NvM_WriteBlock */
        if (PST_TRUE())
        {
            _main_gen_call_NONTRUSTED_NtWrapS_NvM_WriteBlock();
        }
        
        /* call of function NvMProxy_Init0 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID NvMProxy_Init0(__PST__VOID);

            NvMProxy_Init0();
        }
        
        /* call of function NvMProxy_MainFunction */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID NvMProxy_MainFunction(__PST__VOID);

            NvMProxy_MainFunction();
        }
        
        /* call of function NvMProxy_ClsChkWr_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_NvMProxy_ClsChkWr_Oper();
        }
        
    }
}
