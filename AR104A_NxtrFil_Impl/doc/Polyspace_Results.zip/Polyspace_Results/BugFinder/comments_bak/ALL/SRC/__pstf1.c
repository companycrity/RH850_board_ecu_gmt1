
#ifndef NXTRFIL_TESTHARNESS_H
#define NXTRFIL_TESTHARNESS_H

/************************************************ Include Statements *************************************************/
#include "Std_Types.h"

FUNC(void, NXTRFIL_CODE) Test_FilLpUpdGain(float32 FrqPole, 
                                                                                        float32 TiStep, 
                                                                                        P2VAR(FilLpRec1, AUTOMATIC, NXTRFIL_APPL_VAR) FilLpRecPtr);

FUNC(float32, NXTRFIL_CODE) Test_FilLpUpdOutp(float32 Inp, 
                                                                                                P2VAR(FilLpRec1, AUTOMATIC, NXTRFIL_APPL_VAR) FilLpRecPtr);

FUNC(void, NXTRFIL_CODE) Test_FilLpInit(float32 Inp,
                                                                                float32 FrqPole, 
                                                                                float32 TiStep, 
                                                                                P2VAR(FilLpRec1, AUTOMATIC, NXTRFIL_APPL_VAR) FilLpRecPtr);

FUNC(void, NXTRFIL_CODE) Test_FilHpUpdGain(float32 FrqPole, 
                                                                                        float32 TiStep, 
                                                                                        P2VAR(FilHpRec1, AUTOMATIC, NXTRFIL_APPL_VAR) FilHpRecPtr);

FUNC(float32, NXTRFIL_CODE) Test_FilHpUpdOutp(float32 Inp, 
                                                                                                P2VAR(FilHpRec1, AUTOMATIC, NXTRFIL_APPL_VAR) FilHpRecPtr);

FUNC(void, NXTRFIL_CODE) Test_FilHpInit(float32 Inp,
                                                                                float32 FrqPole, 
                                                                                float32 TiStep, 
                                                                                P2VAR(FilHpRec1, AUTOMATIC, NXTRFIL_APPL_VAR) FilHpRecPtr);

#endif
