
/************************************************ Include Statements *************************************************/
#include "Std_Types.h"
#include "NxtrFil.h"
#include "NxtrFil_TestHarness.h"

FUNC(void, NXTRFIL_CODE) Test_FilLpUpdGain(float32 FrqPole, 
                                                                                        float32 TiStep, 
                                                                                        P2VAR(FilLpRec1, AUTOMATIC, NXTRFIL_APPL_VAR) FilLpRecPtr)
{
        FilLpUpdGain (FrqPole, TiStep, FilLpRecPtr);
}

FUNC(float32, NXTRFIL_CODE) Test_FilLpUpdOutp(float32 Inp, 
                                                                                                P2VAR(FilLpRec1, AUTOMATIC, NXTRFIL_APPL_VAR) FilLpRecPtr)
{
        return(FilLpUpdOutp(Inp, FilLpRecPtr));
}

FUNC(void, NXTRFIL_CODE) Test_FilLpInit(float32 Inp,
                                                                                float32 FrqPole, 
                                                                                float32 TiStep, 
                                                                                P2VAR(FilLpRec1, AUTOMATIC, NXTRFIL_APPL_VAR) FilLpRecPtr)
{
        FilLpInit(Inp, FrqPole, TiStep, FilLpRecPtr);
}

FUNC(void, NXTRFIL_CODE) Test_FilHpUpdGain(float32 FrqPole, 
                                                                                        float32 TiStep, 
                                                                                        P2VAR(FilHpRec1, AUTOMATIC, NXTRFIL_APPL_VAR) FilHpRecPtr)
{
        FilHpUpdGain (FrqPole, TiStep, FilHpRecPtr);
}

FUNC(float32, NXTRFIL_CODE) Test_FilHpUpdOutp(float32 Inp, 
                                                                                                P2VAR(FilHpRec1, AUTOMATIC, NXTRFIL_APPL_VAR) FilHpRecPtr)
{
        return(FilHpUpdOutp(Inp, FilHpRecPtr));
}

FUNC(void, NXTRFIL_CODE) Test_FilHpInit(float32 Inp,
                                                                                float32 FrqPole, 
                                                                                float32 TiStep, 
                                                                                P2VAR(FilHpRec1, AUTOMATIC, NXTRFIL_APPL_VAR) FilHpRecPtr)
{
        FilHpInit(Inp, FrqPole, TiStep, FilHpRecPtr);
}


