#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct __PST__g__70 _main_gen_init_g70(void);

extern union __PST__g__69 _main_gen_init_g69(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern union __PST__g__64 _main_gen_init_g64(void);

extern struct __PST__g__48 _main_gen_init_g48(void);

extern union __PST__g__47 _main_gen_init_g47(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct __PST__g__45 _main_gen_init_g45(void);

extern union __PST__g__43 _main_gen_init_g43(void);

extern __PST__g__25 _main_gen_init_g25(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__45 _main_gen_init_g45(void)
{
    static struct __PST__g__45 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.TE03 = bitf;
    }
    return x;
}

union __PST__g__43 _main_gen_init_g43(void)
{
    static union __PST__g__43 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g45();
    return x;
}

struct __PST__g__48 _main_gen_init_g48(void)
{
    static struct __PST__g__48 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.TS03 = bitf;
    }
    return x;
}

union __PST__g__47 _main_gen_init_g47(void)
{
    static union __PST__g__47 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g48();
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

union __PST__g__64 _main_gen_init_g64(void)
{
    static union __PST__g__64 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

struct __PST__g__70 _main_gen_init_g70(void)
{
    static struct __PST__g__70 x;
    /* struct/union type */
    {
        __PST__UINT16 bitf;
        bitf = _main_gen_init_g7();
        unchecked_assert(bitf <= 15);
        x.PRS3 = bitf;
    }
    return x;
}

union __PST__g__69 _main_gen_init_g69(void)
{
    static union __PST__g__69 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g70();
    return x;
}

__PST__g__25 _main_gen_init_g25(void)
{
    __PST__g__25 x;
    /* struct/union type */
    x.TE = _main_gen_init_g43();
    x.TS = _main_gen_init_g47();
    x.CMOR3 = _main_gen_init_g64();
    x.TPS = _main_gen_init_g69();
    x.CDR3 = _main_gen_init_g8();
    x.CNT3 = _main_gen_init_g8();
    x.BRS = _main_gen_init_g6();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_TAUJ1(void)
{
    extern __PST__g__25 TAUJ1;
    
    /* initialization with random value */
    {
        TAUJ1 = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_TAUJ2(void)
{
    extern __PST__g__25 TAUJ2;
    
    /* initialization with random value */
    {
        TAUJ2 = _main_gen_init_g25();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable TAUJ1 */
    _main_gen_init_sym_TAUJ1();
    
    /* init for variable TAUJ2 */
    _main_gen_init_sym_TAUJ2();
    
}
