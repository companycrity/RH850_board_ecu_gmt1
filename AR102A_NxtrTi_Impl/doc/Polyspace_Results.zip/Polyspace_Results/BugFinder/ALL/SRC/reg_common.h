/**********************************************************************************************************************
* Module File Name  : reg_common.h
* Module Description: Common defines for register headers
* Project           : CBD
* Author            : Lucas Wendling
***********************************************************************************************************************
* Version Control:
* %version:          1 %
* %derived_by:       czgng4 %
*----------------------------------------------------------------------------
* Date      Rev      Author         Change Description
* -------   -------  --------  ----------------------------------------------
* 12/16/14  1        LWW       Initial version derived from dr7f701311.dvf.h v1 in tools directory
**********************************************************************************************************************/

#ifndef REG_COMMON_H
#define REG_COMMON_H

/**********************************************************************************************************************
* Include files
 *********************************************************************************************************************/
#include "Std_Types.h"

#ifndef _GHS_PRAGMA_IO_TYPEDEF_
#define _GHS_PRAGMA_IO_TYPEDEF_
#define PRAGMA(x) _Pragma(#x)
#define __READ volatile const
#define __WRITE volatile
#define __READ_WRITE volatile
#define __IOREG(reg, addr, attrib, type) PRAGMA(ghs io reg addr) \
extern attrib type reg;
#define __IOREGARRAY(reg, array, addr, attrib, type) PRAGMA(ghs io reg addr) \
extern attrib type reg[array];
#endif

typedef struct
{
    uint8 bit00:1;
    uint8 bit01:1;
    uint8 bit02:1;
    uint8 bit03:1;
    uint8 bit04:1;
    uint8 bit05:1;
    uint8 bit06:1;
    uint8 bit07:1;
} __bitf_T;

#define  L 0
#define  H 1
#define LL 0
#define LH 1
#define HL 2
#define HH 3

typedef struct 
{                                                          /* Bit Access       */
    const uint8  PRERR:1;                                  /* PRERR            */
    uint8  :7;                                             /* Reserved Bits    */
} __type462;

typedef struct 
{                                                          /* Bit Access       */
    const uint8  TE:1;                                     /* TE               */
    uint8  :7;                                             /* Reserved Bits    */
} __type531;
typedef struct 
{                                                          /* Bit Access       */
    uint8  TS:1;                                           /* TS               */
    uint8  :7;                                             /* Reserved Bits    */
} __type532;
typedef struct 
{                                                          /* Bit Access       */
    uint8  TT:1;                                           /* TT               */
    uint8  :7;                                             /* Reserved Bits    */
} __type533;
typedef struct 
{                                                          /* Bit Access       */
    uint8  TIS:2;                                          /* TIS[1:0]         */
    uint8  :6;                                             /* Reserved Bits    */
} __type714;
typedef struct 
{                                                          /* Bit Access       */
    uint8  CLOV:1;                                         /* CLOV             */
    uint8  :7;                                             /* Reserved Bits    */
} __type716;
typedef struct 
{                                                          /* Bit Access       */
    uint16 MD:5;                                           /* MD[4:0]          */
    uint16 :1;                                             /* Reserved Bits    */
    uint16 COS:2;                                          /* COS[7:6]         */
    uint16 STS:3;                                          /* STS[10:8]        */
    uint16 MAS:1;                                          /* MAS              */
    uint16 CCS:2;                                          /* CCS[13:12]       */
    uint16 CKS:2;                                          /* CKS[15:14]       */
} __type720;
typedef struct 
{                                                          /* Bit Access       */
    uint16 PRS0:4;                                         /* PRS0[3:0]        */
    uint16 PRS1:4;                                         /* PRS1[7:4]        */
    uint16 PRS2:4;                                         /* PRS2[11:8]       */
    uint16 PRS3:4;                                         /* PRS3[15:12]      */
} __type721;

typedef union
{                                                          /* IOR              */
    uint8  UINT8;                                          /* 8-bit Access     */
    const __type462 BIT;                                   /* Bit Access       */
} __type1732;

typedef union
{                                                          /* IOR              */
    uint8  UINT8;                                          /* 8-bit Access     */
    const __type531 BIT;                                   /* Bit Access       */
} __type1801;
typedef union
{                                                          /* IOR              */
    uint8  UINT8;                                          /* 8-bit Access     */
    __type532 BIT;                                         /* Bit Access       */
} __type1802;
typedef union
{                                                          /* IOR              */
    uint8  UINT8;                                          /* 8-bit Access     */
    __type533 BIT;                                         /* Bit Access       */
} __type1803;
typedef union
{                                                          /* IOR              */
    uint8  UINT8;                                          /* 8-bit Access     */
    __type714 BIT;                                         /* Bit Access       */
} __type1984;
typedef union
{                                                          /* IOR              */
    uint8  UINT8;                                          /* 8-bit Access     */
    __type716 BIT;                                         /* Bit Access       */
} __type1986;
typedef union
{                                                          /* IOR              */
    uint16 UINT16;                                         /* 16-bit Access    */
    __type720 BIT;                                         /* Bit Access       */
} __type1990;
typedef union
{                                                          /* IOR              */
    uint16 UINT16;                                         /* 16-bit Access    */
    __type721 BIT;                                         /* Bit Access       */
} __type1991;
#endif
