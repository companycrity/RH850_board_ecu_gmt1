#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__SINT8 pst_random_g_2;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct Rte_CDS_CDD_CurrMeasArbn _main_gen_init_g27(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct Rte_CDS_CDD_CurrMeasArbn _main_gen_init_g27(void)
{
    static struct Rte_CDS_CDD_CurrMeasArbn x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g6();
        }
        x.Pim_CurrMeasArbnSens0RollgCntPrev = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g6();
        }
        x.Pim_CurrMeasArbnSens0StallCntPrev = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g6();
        }
        x.Pim_CurrMeasArbnSens1RollgCntPrev = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g6();
        }
        x.Pim_CurrMeasArbnSens1StallCntPrev = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_CurrMeasArbn(void)
{
    extern __PST__g__24 Rte_Inst_CDD_CurrMeasArbn;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_CurrMeasArbn _main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_CDD_CurrMeasArbn)];
            __PST__UINT32 _i_main_gen_tmp_1;
            for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(struct Rte_CDS_CDD_CurrMeasArbn); _i_main_gen_tmp_1++)
            {
                _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g27();
            }
            Rte_Inst_CDD_CurrMeasArbn = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_CDD_CurrMeasArbn) / 2];
        }
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlCurrMeasCorrlnSts(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlCurrMeasCorrlnSts;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlCurrMeasCorrlnSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlCurrMeasMotAgCorrd(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlCurrMeasMotAgCorrd;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlCurrMeasMotAgCorrd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdA(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrCorrdA;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrCorrdA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdB(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrCorrdB;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrCorrdB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdC(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrCorrdC;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrCorrdC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdD(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrCorrdD;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrCorrdD = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdE(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrCorrdE;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrCorrdE = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdF(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrCorrdF;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrCorrdF = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQlfr1(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotCurrQlfr1;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrQlfr1 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQlfr2(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotCurrQlfr2;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrQlfr2 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrRollgCntr1(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotCurrRollgCntr1;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrRollgCntr1 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrRollgCntr2(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotCurrRollgCntr2;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrRollgCntr2 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotElecMeclPolarity(void)
{
    extern __PST__SINT8 MOTCTRLMGR_MotCtrlMotElecMeclPolarity;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotElecMeclPolarity = _main_gen_init_g2();
    }
}


/* Definition of functions */


/* Main */

void main(void)
{
    /* Initialization of global variables */

    /* init for variable Rte_Inst_CDD_CurrMeasArbn */
    _main_gen_init_sym_Rte_Inst_CDD_CurrMeasArbn();
    
    /* init for variable MOTCTRLMGR_MotCtrlCurrMeasCorrlnSts */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlCurrMeasCorrlnSts();
    
    /* init for variable MOTCTRLMGR_MotCtrlCurrMeasMotAgCorrd */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlCurrMeasMotAgCorrd();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrCorrdA */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdA();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrCorrdB */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdB();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrCorrdC */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdC();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrCorrdD */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdD();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrCorrdE */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdE();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrCorrdF */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdF();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrQlfr1 */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQlfr1();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrQlfr2 */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQlfr2();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrRollgCntr1 */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrRollgCntr1();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrRollgCntr2 */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrRollgCntr2();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotElecMeclPolarity */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotElecMeclPolarity();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrDax : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotCurrQax : useless (never read) */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function CurrMeasArbnInit1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID CurrMeasArbnInit1(__PST__VOID);

            CurrMeasArbnInit1();
        }
        
        /* call of function CurrMeasArbnPer1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID CurrMeasArbnPer1(__PST__VOID);

            CurrMeasArbnPer1();
        }
        
    }
}
