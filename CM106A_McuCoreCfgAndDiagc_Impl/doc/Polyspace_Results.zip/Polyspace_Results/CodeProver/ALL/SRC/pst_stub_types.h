typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__VOID __PST__g__15(void);
typedef __PST__FLOAT64 __PST__g__16(void);
typedef __PST__g__11 *__PST__g__18;
typedef volatile __PST__FLOAT64 __PST__g__19;
typedef __PST__SINT8 *__PST__g__21;
typedef volatile __PST__g__21 __PST__g__20;
typedef __PST__VOID __PST__g__22(__PST__SINT32);
typedef const struct Rte_CDS_CDD_McuCoreCfgAndDiagc __PST__g__25;
typedef __PST__g__25 *__PST__g__24;
typedef const __PST__g__24 __PST__g__23;
typedef __PST__UINT32 *__PST__g__27;
struct Rte_CDS_CDD_McuCoreCfgAndDiagc
  {
    __PST__g__27 Pim_CoreCompTestRegRead;
  };
typedef __PST__SINT8 __PST__g__401[1];
typedef __PST__SINT8 __PST__g__102[3];
struct __PST__g__40
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 SSE001 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    const __PST__UINT32 __pst_unused_field_3 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    const __PST__UINT32 __pst_unused_field_6 : 1;
    const __PST__UINT32 __pst_unused_field_7 : 1;
    const __PST__UINT32 __pst_unused_field_8 : 1;
    const __PST__UINT32 __pst_unused_field_9 : 1;
    const __PST__UINT32 __pst_unused_field_10 : 1;
    const __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    const __PST__UINT32 __pst_unused_field_13 : 1;
    const __PST__UINT32 __pst_unused_field_14 : 1;
    const __PST__UINT32 __pst_unused_field_15 : 1;
    const __PST__UINT32 __pst_unused_field_16 : 1;
    const __PST__UINT32 __pst_unused_field_17 : 1;
    const __PST__UINT32 __pst_unused_field_18 : 1;
    const __PST__UINT32 __pst_unused_field_19 : 1;
    const __PST__UINT32 __pst_unused_field_20 : 1;
    const __PST__UINT32 __pst_unused_field_21 : 1;
    const __PST__UINT32 __pst_unused_field_22 : 1;
    const __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    const __PST__UINT32 __pst_unused_field_25 : 1;
    const __PST__UINT32 __pst_unused_field_26 : 1;
    const __PST__UINT32 __pst_unused_field_27 : 1;
    const __PST__UINT32 __pst_unused_field_28 : 1;
    const __PST__UINT32 __pst_unused_field_29 : 1;
    const __PST__UINT32 __pst_unused_field_30 : 1;
  };
typedef const struct __PST__g__40 __PST__g__39;
union __PST__g__38
  {
    __PST__g__39 BIT;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__38 __PST__g__37;
struct __PST__g__46
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    const __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    const __PST__UINT32 __pst_unused_field_6 : 1;
    const __PST__UINT32 __pst_unused_field_7 : 1;
    const __PST__UINT32 SSE108 : 1;
    const __PST__UINT32 SSE109 : 1;
    const __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    const __PST__UINT32 __pst_unused_field_12 : 1;
    const __PST__UINT32 __pst_unused_field_13 : 1;
    const __PST__UINT32 __pst_unused_field_14 : 1;
  };
typedef const struct __PST__g__46 __PST__g__45;
union __PST__g__44
  {
    __PST__g__45 BIT;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__44 __PST__g__43;
typedef __PST__SINT8 __PST__g__402[4];
struct __PST__g__29
  {
    __PST__g__401 __pst_unused_field_0;
    __PST__g__102 __pst_unused_field_1;
    __PST__g__401 __pst_unused_field_2;
    __PST__g__102 __pst_unused_field_3;
    __PST__g__37 ESSTR0;
    __PST__g__43 ESSTR1;
    __PST__g__402 __pst_unused_field_6;
  };
typedef volatile struct __PST__g__29 __PST__g__28;
union __PST__g__30
  {
    __PST__g__401 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__31
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef __PST__UINT8 __PST__g__34[3];
union __PST__g__35
  {
    __PST__g__401 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__36
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef __PST__SINT32 __PST__g__403[1];
union __PST__g__48
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__49
  {
    __PST__UINT32 __pst_unused_field_0 : 8;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 24;
  };
union __PST__g__55
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__60
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__64
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__68
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__72
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__76
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__79
  {
    __PST__g__401 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef const union __PST__g__79 __PST__g__78;
typedef const __PST__UINT16 __PST__g__89;
typedef __PST__SINT8 __PST__g__404[2];
typedef __PST__SINT8 __PST__g__405[4008];
struct __PST__g__52
  {
    __PST__g__401 __pst_unused_field_0;
    __PST__g__102 __pst_unused_field_1;
    union __PST__g__55 MICFG0;
    __PST__g__402 __pst_unused_field_3;
    union __PST__g__60 NMICFG0;
    __PST__g__402 __pst_unused_field_5;
    union __PST__g__64 IRCFG0;
    __PST__g__402 __pst_unused_field_7;
    union __PST__g__68 EMK0;
    __PST__g__402 __pst_unused_field_9;
    union __PST__g__72 ESSTC0;
    __PST__g__402 __pst_unused_field_11;
    union __PST__g__76 PCMD1;
    __PST__g__78 PS;
    __PST__g__102 __pst_unused_field_14;
    __PST__g__402 __pst_unused_field_15;
    __PST__g__402 __pst_unused_field_16;
    __PST__g__401 __pst_unused_field_17;
    __PST__g__102 __pst_unused_field_18;
    __PST__g__89 __pst_unused_field_19;
    __PST__g__404 __pst_unused_field_20;
    __PST__UINT16 __pst_unused_field_21;
    __PST__g__404 __pst_unused_field_22;
    __PST__g__402 __pst_unused_field_23;
    __PST__g__402 __pst_unused_field_24;
    __PST__g__402 __pst_unused_field_25;
    __PST__g__402 __pst_unused_field_26;
    __PST__g__405 __pst_unused_field_27;
    __PST__g__401 __pst_unused_field_28;
    __PST__g__102 __pst_unused_field___pstfiller;
  };
typedef volatile struct __PST__g__52 __PST__g__51;
union __PST__g__53
  {
    __PST__g__401 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__54
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
struct __PST__g__56
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__57
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__58
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
struct __PST__g__61
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__62
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__63
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
struct __PST__g__65
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__66
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__67
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 2;
  };
struct __PST__g__69
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__70
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__71
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 2;
  };
struct __PST__g__73
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__74
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__75
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
  };
struct __PST__g__77
  {
    __PST__UINT32 __pst_unused_field_0 : 8;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 24;
  };
struct __PST__g__81
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef const struct __PST__g__81 __PST__g__80;
union __PST__g__82
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__83
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__84
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__85
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 2;
  };
union __PST__g__86
  {
    __PST__g__401 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__87
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 6;
  };
typedef __PST__UINT8 __PST__g__90[2];
union __PST__g__91
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__92
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__93
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__94
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
union __PST__g__95
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__96
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__97
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__98
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
typedef __PST__UINT8 __PST__g__99[4008];
union __PST__g__100
  {
    __PST__g__401 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__101
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef __PST__SINT8 __PST__g__406[8180];
union __PST__g__114
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__118
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__120
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__122
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__124
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__126
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef __PST__SINT8 __PST__g__407[8];
struct __PST__g__132
  {
    const __PST__UINT32 BIST_RESULT : 3;
    const __PST__UINT32 DEBUGMODE : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 28;
  };
typedef const struct __PST__g__132 __PST__g__131;
union __PST__g__130
  {
    __PST__g__131 BIT;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__130 __PST__g__129;
struct __PST__g__139
  {
    const __PST__UINT32 BIST_RESULTB : 3;
    const __PST__UINT32 DEBUGMODEB : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 28;
  };
typedef const struct __PST__g__139 __PST__g__138;
union __PST__g__137
  {
    __PST__g__138 BIT;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__137 __PST__g__136;
typedef __PST__SINT8 __PST__g__408[2201560];
typedef __PST__SINT8 __PST__g__409[20];
typedef __PST__SINT8 __PST__g__410[7];
typedef __PST__SINT8 __PST__g__411[956];
typedef __PST__SINT8 __PST__g__412[1036];
typedef __PST__SINT8 __PST__g__413[24680];
typedef __PST__SINT8 __PST__g__414[56];
typedef __PST__SINT8 __PST__g__415[24];
typedef __PST__SINT8 __PST__g__416[112];
typedef __PST__SINT8 __PST__g__417[4664];
typedef __PST__SINT8 __PST__g__418[1996];
typedef __PST__SINT8 __PST__g__419[996];
struct __PST__g__104
  {
    __PST__g__402 __pst_unused_field_0;
    __PST__g__402 __pst_unused_field_1;
    __PST__g__402 __pst_unused_field_2;
    __PST__g__406 __pst_unused_field_3;
    union __PST__g__114 LBISTREF1;
    union __PST__g__118 LBISTREF2;
    union __PST__g__120 MBISTREF;
    union __PST__g__122 LBISTSIG1;
    union __PST__g__124 LBISTSIG2;
    union __PST__g__126 MBISTSIG;
    __PST__g__407 __pst_unused_field_10;
    __PST__g__129 BSEQ0ST;
    __PST__g__136 BSEQ0STB;
    __PST__g__408 __pst_unused_field_13;
    __PST__g__402 __pst_unused_field_14;
    __PST__g__402 __pst_unused_field_15;
    __PST__g__402 __pst_unused_field_16;
    __PST__g__409 __pst_unused_field_17;
    __PST__g__401 __pst_unused_field_18;
    __PST__g__102 __pst_unused_field_19;
    __PST__g__401 __pst_unused_field_20;
    __PST__g__410 __pst_unused_field_21;
    __PST__g__401 __pst_unused_field_22;
    __PST__g__102 __pst_unused_field_23;
    __PST__g__401 __pst_unused_field_24;
    __PST__g__102 __pst_unused_field_25;
    __PST__g__401 __pst_unused_field_26;
    __PST__g__102 __pst_unused_field_27;
    __PST__g__401 __pst_unused_field_28;
    __PST__g__102 __pst_unused_field_29;
    __PST__g__401 __pst_unused_field_30;
    __PST__g__102 __pst_unused_field_31;
    __PST__g__402 __pst_unused_field_32;
    __PST__g__411 __pst_unused_field_33;
    __PST__g__402 __pst_unused_field_34;
    __PST__g__412 __pst_unused_field_35;
    __PST__g__402 __pst_unused_field_36;
    __PST__g__402 __pst_unused_field_37;
    __PST__g__413 __pst_unused_field_38;
    __PST__g__402 __pst_unused_field_39;
    __PST__g__402 __pst_unused_field_40;
    __PST__g__414 __pst_unused_field_41;
    __PST__g__402 __pst_unused_field_42;
    __PST__g__402 __pst_unused_field_43;
    __PST__g__414 __pst_unused_field_44;
    __PST__g__402 __pst_unused_field_45;
    __PST__g__402 __pst_unused_field_46;
    __PST__g__402 __pst_unused_field_47;
    __PST__g__402 __pst_unused_field_48;
    __PST__g__402 __pst_unused_field_49;
    __PST__g__402 __pst_unused_field_50;
    __PST__g__402 __pst_unused_field_51;
    __PST__g__402 __pst_unused_field_52;
    __PST__g__402 __pst_unused_field_53;
    __PST__g__402 __pst_unused_field_54;
    __PST__g__402 __pst_unused_field_55;
    __PST__g__402 __pst_unused_field_56;
    __PST__g__402 __pst_unused_field_57;
    __PST__g__402 __pst_unused_field_58;
    __PST__g__402 __pst_unused_field_59;
    __PST__g__402 __pst_unused_field_60;
    __PST__g__402 __pst_unused_field_61;
    __PST__g__402 __pst_unused_field_62;
    __PST__g__402 __pst_unused_field_63;
    __PST__g__402 __pst_unused_field_64;
    __PST__g__402 __pst_unused_field_65;
    __PST__g__402 __pst_unused_field_66;
    __PST__g__402 __pst_unused_field_67;
    __PST__g__402 __pst_unused_field_68;
    __PST__g__402 __pst_unused_field_69;
    __PST__g__402 __pst_unused_field_70;
    __PST__g__415 __pst_unused_field_71;
    __PST__g__402 __pst_unused_field_72;
    __PST__g__402 __pst_unused_field_73;
    __PST__g__402 __pst_unused_field_74;
    __PST__g__402 __pst_unused_field_75;
    __PST__g__416 __pst_unused_field_76;
    __PST__g__402 __pst_unused_field_77;
    __PST__g__402 __pst_unused_field_78;
    __PST__g__417 __pst_unused_field_79;
    __PST__g__402 __pst_unused_field_80;
    __PST__g__418 __pst_unused_field_81;
    __PST__g__402 __pst_unused_field_82;
    __PST__g__402 __pst_unused_field_83;
    __PST__g__402 __pst_unused_field_84;
    __PST__g__419 __pst_unused_field_85;
    __PST__g__402 __pst_unused_field_86;
    __PST__g__402 __pst_unused_field_87;
  };
typedef volatile struct __PST__g__104 __PST__g__103;
union __PST__g__106
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__106 __PST__g__105;
struct __PST__g__108
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    const __PST__UINT32 __pst_unused_field_2 : 1;
    const __PST__UINT32 __pst_unused_field_3 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 26;
  };
typedef const struct __PST__g__108 __PST__g__107;
typedef __PST__UINT8 __PST__g__110[4];
union __PST__g__111
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__112
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 26;
  };
typedef __PST__UINT8 __PST__g__113[8180];
struct __PST__g__115
  {
    __PST__UINT32 __pst_unused_field_0 : 20;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 12;
  };
struct __PST__g__119
  {
    __PST__UINT32 __pst_unused_field_0 : 20;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 12;
  };
struct __PST__g__121
  {
    __PST__UINT32 __pst_unused_field_0 : 20;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 12;
  };
struct __PST__g__123
  {
    __PST__UINT32 __pst_unused_field_0 : 20;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 12;
  };
struct __PST__g__125
  {
    __PST__UINT32 __pst_unused_field_0 : 20;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 12;
  };
struct __PST__g__127
  {
    __PST__UINT32 __pst_unused_field_0 : 20;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 12;
  };
typedef __PST__UINT8 __PST__g__128[8];
typedef __PST__UINT8 __PST__g__140[2201560];
union __PST__g__142
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__142 __PST__g__141;
struct __PST__g__144
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    const __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__144 __PST__g__143;
union __PST__g__146
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__147
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef __PST__UINT8 __PST__g__148[20];
union __PST__g__150
  {
    __PST__g__401 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef const union __PST__g__150 __PST__g__149;
struct __PST__g__152
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    const __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 5;
    const __PST__UINT8 __pst_unused_field_3 : 1;
  };
typedef const struct __PST__g__152 __PST__g__151;
union __PST__g__155
  {
    __PST__g__401 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef const union __PST__g__155 __PST__g__154;
struct __PST__g__157
  {
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    const __PST__UINT8 __pst_unused_field_1 : 1;
    const __PST__UINT8 __pst_unused_field_2 : 1;
    const __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 3;
  };
typedef const struct __PST__g__157 __PST__g__156;
typedef __PST__UINT8 __PST__g__158[7];
union __PST__g__159
  {
    __PST__g__401 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__160
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
union __PST__g__161
  {
    __PST__g__401 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__162
  {
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
  };
union __PST__g__165
  {
    __PST__g__401 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef const union __PST__g__165 __PST__g__164;
struct __PST__g__167
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef const struct __PST__g__167 __PST__g__166;
union __PST__g__168
  {
    __PST__g__401 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__169
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 5;
    __PST__UINT8 __pst_unused_field_3 : 1;
  };
union __PST__g__170
  {
    __PST__g__401 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__171
  {
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 3;
  };
union __PST__g__172
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__173
  {
    __PST__UINT32 __pst_unused_field_0 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 30;
  };
typedef __PST__UINT8 __PST__g__175[956];
union __PST__g__176
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__177
  {
    __PST__UINT32 __pst_unused_field_0 : 2;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef __PST__UINT8 __PST__g__178[1036];
union __PST__g__179
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__180
  {
    __PST__UINT32 __pst_unused_field_0 : 8;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 24;
  };
union __PST__g__182
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__182 __PST__g__181;
struct __PST__g__184
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 31;
  };
typedef const struct __PST__g__184 __PST__g__183;
typedef __PST__UINT8 __PST__g__186[24680];
union __PST__g__187
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__188
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 29;
  };
union __PST__g__190
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__190 __PST__g__189;
struct __PST__g__192
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__192 __PST__g__191;
typedef __PST__UINT8 __PST__g__194[56];
union __PST__g__195
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__196
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 29;
  };
union __PST__g__198
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__198 __PST__g__197;
struct __PST__g__200
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__200 __PST__g__199;
union __PST__g__201
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__202
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 29;
  };
union __PST__g__204
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__204 __PST__g__203;
struct __PST__g__206
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__206 __PST__g__205;
union __PST__g__207
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__208
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 29;
  };
union __PST__g__210
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__210 __PST__g__209;
struct __PST__g__212
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__212 __PST__g__211;
union __PST__g__213
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__214
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 29;
  };
union __PST__g__216
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__216 __PST__g__215;
struct __PST__g__218
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__218 __PST__g__217;
union __PST__g__219
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__220
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 29;
  };
union __PST__g__222
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__222 __PST__g__221;
struct __PST__g__224
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__224 __PST__g__223;
union __PST__g__225
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__226
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 29;
  };
union __PST__g__228
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__228 __PST__g__227;
struct __PST__g__230
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__230 __PST__g__229;
union __PST__g__231
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__232
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 29;
  };
union __PST__g__234
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__234 __PST__g__233;
struct __PST__g__236
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__236 __PST__g__235;
union __PST__g__237
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__238
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 29;
  };
union __PST__g__240
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__240 __PST__g__239;
struct __PST__g__242
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__242 __PST__g__241;
union __PST__g__243
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__244
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 29;
  };
union __PST__g__246
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__246 __PST__g__245;
struct __PST__g__248
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__248 __PST__g__247;
union __PST__g__249
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__250
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 29;
  };
union __PST__g__252
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__252 __PST__g__251;
struct __PST__g__254
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__254 __PST__g__253;
union __PST__g__255
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__256
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 29;
  };
union __PST__g__258
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__258 __PST__g__257;
struct __PST__g__260
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__260 __PST__g__259;
union __PST__g__261
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__262
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 29;
  };
union __PST__g__264
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__264 __PST__g__263;
struct __PST__g__266
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__266 __PST__g__265;
union __PST__g__267
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__268
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 29;
  };
union __PST__g__270
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__270 __PST__g__269;
struct __PST__g__272
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__272 __PST__g__271;
typedef __PST__UINT8 __PST__g__273[24];
union __PST__g__274
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__275
  {
    __PST__UINT32 __pst_unused_field_0 : 9;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 23;
  };
union __PST__g__279
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__279 __PST__g__278;
struct __PST__g__281
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 30;
  };
typedef const struct __PST__g__281 __PST__g__280;
union __PST__g__282
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__283
  {
    __PST__UINT32 __pst_unused_field_0 : 9;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 23;
  };
union __PST__g__285
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__285 __PST__g__284;
struct __PST__g__287
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 30;
  };
typedef const struct __PST__g__287 __PST__g__286;
typedef __PST__UINT8 __PST__g__288[112];
union __PST__g__289
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__290
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 29;
  };
union __PST__g__292
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__292 __PST__g__291;
struct __PST__g__294
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__294 __PST__g__293;
typedef __PST__UINT8 __PST__g__295[4664];
union __PST__g__296
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__297
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 31;
  };
typedef __PST__UINT8 __PST__g__298[1996];
union __PST__g__300
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__300 __PST__g__299;
struct __PST__g__302
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 31;
  };
typedef const struct __PST__g__302 __PST__g__301;
union __PST__g__303
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__304
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 31;
  };
union __PST__g__305
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__306
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 31;
  };
typedef __PST__UINT8 __PST__g__307[996];
union __PST__g__310
  {
    __PST__g__403 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
struct __PST__g__309
  {
    union __PST__g__310 PDMA_COMP_CNTRL;
  };
typedef volatile struct __PST__g__309 __PST__g__308;
struct __PST__g__311
  {
    __PST__UINT32 __pst_unused_field_0 : 30;
    __PST__UINT32 __pst_unused_field_1 : 2;
  };
typedef __PST__SINT16 __PST__g__420[2];
union __PST__g__314
  {
    __PST__g__420 __pst_unused_field_0;
    __PST__UINT32 UINT32;
    __PST__g__402 __pst_unused_field_2;
  };
struct __PST__g__313
  {
    union __PST__g__314 REG0;
    union __PST__g__314 REG1;
  };
typedef volatile struct __PST__g__313 __PST__g__312;
typedef __PST__UINT16 __PST__g__315[2];
typedef __PST__VOID __PST__g__316(__PST__UINT32, __PST__UINT32);
typedef __PST__VOID __PST__g__317(__PST__g__27);
typedef __PST__UINT8 *__PST__g__319;
typedef __PST__VOID __PST__g__318(__PST__g__319);
typedef const __PST__UINT8 __PST__g__320;
typedef volatile __PST__UINT32 __PST__g__321;
typedef __PST__g__321 *__PST__g__322;
typedef __PST__VOID __PST__g__323(__PST__UINT32, __PST__g__322);
typedef __PST__g__15 *__PST__g__324;
typedef __PST__g__103 *__PST__g__325;
typedef volatile __PST__g__78 __PST__g__326;
typedef __PST__g__326 *__PST__g__327;
typedef volatile __PST__g__320 __PST__g__328;
typedef __PST__g__328 *__PST__g__329;
typedef __PST__g__28 *__PST__g__330;
typedef __PST__g__51 *__PST__g__331;
typedef volatile union __PST__g__76 __PST__g__332;
typedef __PST__g__332 *__PST__g__333;
typedef __PST__g__316 *__PST__g__334;
typedef __PST__g__323 *__PST__g__335;
typedef volatile union __PST__g__72 __PST__g__336;
typedef __PST__g__336 *__PST__g__337;
typedef __PST__g__317 *__PST__g__338;
typedef volatile __PST__g__129 __PST__g__339;
typedef __PST__g__339 *__PST__g__340;
typedef volatile __PST__g__131 __PST__g__341;
typedef __PST__g__341 *__PST__g__342;
typedef volatile __PST__g__136 __PST__g__345;
typedef __PST__g__345 *__PST__g__346;
typedef volatile __PST__g__138 __PST__g__347;
typedef __PST__g__347 *__PST__g__348;
typedef __PST__g__22 *__PST__g__349;
typedef volatile __PST__g__43 __PST__g__350;
typedef __PST__g__350 *__PST__g__351;
typedef volatile __PST__g__45 __PST__g__352;
typedef __PST__g__352 *__PST__g__353;
typedef volatile union __PST__g__122 __PST__g__356;
typedef __PST__g__356 *__PST__g__357;
typedef volatile union __PST__g__114 __PST__g__358;
typedef __PST__g__358 *__PST__g__359;
typedef volatile union __PST__g__124 __PST__g__360;
typedef __PST__g__360 *__PST__g__361;
typedef volatile union __PST__g__118 __PST__g__362;
typedef __PST__g__362 *__PST__g__363;
typedef volatile union __PST__g__120 __PST__g__364;
typedef __PST__g__364 *__PST__g__365;
typedef volatile union __PST__g__126 __PST__g__366;
typedef __PST__g__366 *__PST__g__367;
typedef __PST__g__318 *__PST__g__368;
typedef volatile __PST__g__37 __PST__g__369;
typedef __PST__g__369 *__PST__g__370;
typedef volatile __PST__g__39 __PST__g__371;
typedef __PST__g__371 *__PST__g__372;
typedef volatile union __PST__g__68 __PST__g__373;
typedef __PST__g__373 *__PST__g__374;
typedef volatile union __PST__g__55 __PST__g__375;
typedef __PST__g__375 *__PST__g__376;
typedef volatile union __PST__g__60 __PST__g__377;
typedef __PST__g__377 *__PST__g__378;
typedef volatile union __PST__g__64 __PST__g__379;
typedef __PST__g__379 *__PST__g__380;
typedef __PST__g__308 *__PST__g__381;
typedef volatile union __PST__g__310 __PST__g__382;
typedef __PST__g__382 *__PST__g__383;
typedef __PST__g__312 *__PST__g__384;
typedef volatile union __PST__g__314 __PST__g__385;
typedef __PST__g__385 *__PST__g__386;
typedef const __PST__g__27 __PST__g__387;
typedef __PST__g__387 *__PST__g__388;
typedef volatile __PST__SINT32 __PST__g__389;
typedef __PST__SINT8 __PST__g__395(void);
typedef volatile __PST__SINT8 __PST__g__396;
typedef __PST__UINT8 __PST__g__397(void);
typedef volatile __PST__UINT8 __PST__g__398;
typedef __PST__SINT32 __PST__g__399(void);
typedef __PST__UINT32 __PST__g__400(void);
