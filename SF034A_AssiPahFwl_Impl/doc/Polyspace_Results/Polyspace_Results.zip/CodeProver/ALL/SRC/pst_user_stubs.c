/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function expf
//
// #pragma POLYSPACE_PURE "expf"
// #pragma POLYSPACE_CLEAN "expf"
// #pragma POLYSPACE_WORST "expf"
//
// __PST__FLOAT32 expf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function fabsf
//
// #pragma POLYSPACE_PURE "fabsf"
// #pragma POLYSPACE_CLEAN "fabsf"
// #pragma POLYSPACE_WORST "fabsf"
//
// __PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_AssiPahFwl_AssiCmdBas_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_AssiPahFwl_AssiCmdBas_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_AssiPahFwl_AssiCmdBas_Val"
// #pragma POLYSPACE_WORST "Rte_Read_AssiPahFwl_AssiCmdBas_Val"
//
// __PST__UINT8 Rte_Read_AssiPahFwl_AssiCmdBas_Val(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_AssiPahFwl_AssiHiFrqCmd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_AssiPahFwl_AssiHiFrqCmd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_AssiPahFwl_AssiHiFrqCmd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_AssiPahFwl_AssiHiFrqCmd_Val"
//
// __PST__UINT8 Rte_Read_AssiPahFwl_AssiHiFrqCmd_Val(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_AssiPahFwl_AssiLnrGainEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_AssiPahFwl_AssiLnrGainEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_AssiPahFwl_AssiLnrGainEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_AssiPahFwl_AssiLnrGainEna_Logl"
//
// __PST__UINT8 Rte_Read_AssiPahFwl_AssiLnrGainEna_Logl(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_AssiPahFwl_HwTq_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_AssiPahFwl_HwTq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_AssiPahFwl_HwTq_Val"
// #pragma POLYSPACE_WORST "Rte_Read_AssiPahFwl_HwTq_Val"
//
// __PST__UINT8 Rte_Read_AssiPahFwl_HwTq_Val(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_AssiPahFwl_HwTqOvrl_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_AssiPahFwl_HwTqOvrl_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_AssiPahFwl_HwTqOvrl_Val"
// #pragma POLYSPACE_WORST "Rte_Read_AssiPahFwl_HwTqOvrl_Val"
//
// __PST__UINT8 Rte_Read_AssiPahFwl_HwTqOvrl_Val(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_AssiPahFwl_HysCmpCmd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_AssiPahFwl_HysCmpCmd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_AssiPahFwl_HysCmpCmd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_AssiPahFwl_HysCmpCmd_Val"
//
// __PST__UINT8 Rte_Read_AssiPahFwl_HysCmpCmd_Val(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_AssiPahFwl_MfgEnaSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_AssiPahFwl_MfgEnaSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_AssiPahFwl_MfgEnaSt_Val"
// #pragma POLYSPACE_WORST "Rte_Read_AssiPahFwl_MfgEnaSt_Val"
//
// __PST__UINT8 Rte_Read_AssiPahFwl_MfgEnaSt_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_AssiPahFwl_VehSpd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_AssiPahFwl_VehSpd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_AssiPahFwl_VehSpd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_AssiPahFwl_VehSpd_Val"
//
// __PST__UINT8 Rte_Read_AssiPahFwl_VehSpd_Val(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_AssiPahFwl_AssiCmdSum_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_AssiPahFwl_AssiCmdSum_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_AssiPahFwl_AssiCmdSum_Val"
// #pragma POLYSPACE_WORST "Rte_Write_AssiPahFwl_AssiCmdSum_Val"
//
// __PST__UINT8 Rte_Write_AssiPahFwl_AssiCmdSum_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_AssiPahFwl_AssiPahLimrActv_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_AssiPahFwl_AssiPahLimrActv_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_AssiPahFwl_AssiPahLimrActv_Val"
// #pragma POLYSPACE_WORST "Rte_Write_AssiPahFwl_AssiPahLimrActv_Val"
//
// __PST__UINT8 Rte_Write_AssiPahFwl_AssiPahLimrActv_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_AssiPahFwl_GetNtcQlfrSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_AssiPahFwl_GetNtcQlfrSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_AssiPahFwl_GetNtcQlfrSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_AssiPahFwl_GetNtcQlfrSts_Oper"
//
// __PST__UINT8 Rte_Call_AssiPahFwl_GetNtcQlfrSts_Oper(__PST__UINT16 P_0, __PST__g__26 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_AssiPahFwl_SetNtcSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_AssiPahFwl_SetNtcSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_AssiPahFwl_SetNtcSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_AssiPahFwl_SetNtcSts_Oper"
//
// __PST__UINT8 Rte_Call_AssiPahFwl_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
// {
//    ...
// }


// Pragmas for function Rte_Prm_AssiPahFwl_AssiPahFwlCmdSplitLpFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_AssiPahFwl_AssiPahFwlCmdSplitLpFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_AssiPahFwl_AssiPahFwlCmdSplitLpFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_AssiPahFwl_AssiPahFwlCmdSplitLpFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_AssiPahFwl_AssiPahFwlCmdSplitLpFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_AssiPahFwl_AssiPahFwlFwlActvLpFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_AssiPahFwl_AssiPahFwlFwlActvLpFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_AssiPahFwl_AssiPahFwlFwlActvLpFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_AssiPahFwl_AssiPahFwlFwlActvLpFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_AssiPahFwl_AssiPahFwlFwlActvLpFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_AssiPahFwl_AssiPahFwlHysCmpLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_AssiPahFwl_AssiPahFwlHysCmpLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_AssiPahFwl_AssiPahFwlHysCmpLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_AssiPahFwl_AssiPahFwlHysCmpLim_Val"
//
// __PST__FLOAT32 Rte_Prm_AssiPahFwl_AssiPahFwlHysCmpLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_AssiPahFwl_AssiPahFwlRestoreThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_AssiPahFwl_AssiPahFwlRestoreThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_AssiPahFwl_AssiPahFwlRestoreThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_AssiPahFwl_AssiPahFwlRestoreThd_Val"
//
// __PST__FLOAT32 Rte_Prm_AssiPahFwl_AssiPahFwlRestoreThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_AssiPahFwl_BasAssiPahFwlOverLimDiagcFailStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_AssiPahFwl_BasAssiPahFwlOverLimDiagcFailStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_AssiPahFwl_BasAssiPahFwlOverLimDiagcFailStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_AssiPahFwl_BasAssiPahFwlOverLimDiagcFailStep_Val"
//
// __PST__UINT16 Rte_Prm_AssiPahFwl_BasAssiPahFwlOverLimDiagcFailStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_AssiPahFwl_BasAssiPahFwlOverLimDiagcPassStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_AssiPahFwl_BasAssiPahFwlOverLimDiagcPassStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_AssiPahFwl_BasAssiPahFwlOverLimDiagcPassStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_AssiPahFwl_BasAssiPahFwlOverLimDiagcPassStep_Val"
//
// __PST__UINT16 Rte_Prm_AssiPahFwl_BasAssiPahFwlOverLimDiagcPassStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_AssiPahFwl_HiFrqAssiPahFwlOverLimDiagcFailStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_AssiPahFwl_HiFrqAssiPahFwlOverLimDiagcFailStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_AssiPahFwl_HiFrqAssiPahFwlOverLimDiagcFailStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_AssiPahFwl_HiFrqAssiPahFwlOverLimDiagcFailStep_Val"
//
// __PST__UINT16 Rte_Prm_AssiPahFwl_HiFrqAssiPahFwlOverLimDiagcFailStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_AssiPahFwl_HiFrqAssiPahFwlOverLimDiagcPassStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_AssiPahFwl_HiFrqAssiPahFwlOverLimDiagcPassStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_AssiPahFwl_HiFrqAssiPahFwlOverLimDiagcPassStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_AssiPahFwl_HiFrqAssiPahFwlOverLimDiagcPassStep_Val"
//
// __PST__UINT16 Rte_Prm_AssiPahFwl_HiFrqAssiPahFwlOverLimDiagcPassStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_AssiPahFwl_AssiPahFwlDiRcvr_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_AssiPahFwl_AssiPahFwlDiRcvr_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_AssiPahFwl_AssiPahFwlDiRcvr_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_AssiPahFwl_AssiPahFwlDiRcvr_Logl"
//
// __PST__UINT8 Rte_Prm_AssiPahFwl_AssiPahFwlDiRcvr_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_AssiPahFwl_AssiPahFwlDftAssiX_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_AssiPahFwl_AssiPahFwlDftAssiX_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_AssiPahFwl_AssiPahFwlDftAssiX_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_AssiPahFwl_AssiPahFwlDftAssiX_Ary1D"
//
// __PST__g__41 Rte_Prm_AssiPahFwl_AssiPahFwlDftAssiX_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_AssiPahFwl_AssiPahFwlDftAssiY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_AssiPahFwl_AssiPahFwlDftAssiY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_AssiPahFwl_AssiPahFwlDftAssiY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_AssiPahFwl_AssiPahFwlDftAssiY_Ary1D"
//
// __PST__g__44 Rte_Prm_AssiPahFwl_AssiPahFwlDftAssiY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_AssiPahFwl_AssiPahFwlHiFrqUpprLimY_Ary2D
//
// #pragma POLYSPACE_PURE "Rte_Prm_AssiPahFwl_AssiPahFwlHiFrqUpprLimY_Ary2D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_AssiPahFwl_AssiPahFwlHiFrqUpprLimY_Ary2D"
// #pragma POLYSPACE_WORST "Rte_Prm_AssiPahFwl_AssiPahFwlHiFrqUpprLimY_Ary2D"
//
// __PST__g__44 Rte_Prm_AssiPahFwl_AssiPahFwlHiFrqUpprLimY_Ary2D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_AssiPahFwl_AssiPahFwlUpprLimX_Ary2D
//
// #pragma POLYSPACE_PURE "Rte_Prm_AssiPahFwl_AssiPahFwlUpprLimX_Ary2D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_AssiPahFwl_AssiPahFwlUpprLimX_Ary2D"
// #pragma POLYSPACE_WORST "Rte_Prm_AssiPahFwl_AssiPahFwlUpprLimX_Ary2D"
//
// __PST__g__44 Rte_Prm_AssiPahFwl_AssiPahFwlUpprLimX_Ary2D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_AssiPahFwl_AssiPahFwlUpprLimY_Ary2D
//
// #pragma POLYSPACE_PURE "Rte_Prm_AssiPahFwl_AssiPahFwlUpprLimY_Ary2D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_AssiPahFwl_AssiPahFwlUpprLimY_Ary2D"
// #pragma POLYSPACE_WORST "Rte_Prm_AssiPahFwl_AssiPahFwlUpprLimY_Ary2D"
//
// __PST__g__44 Rte_Prm_AssiPahFwl_AssiPahFwlUpprLimY_Ary2D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_AssiPahFwl_AssiPahFwlVehSpd_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_AssiPahFwl_AssiPahFwlVehSpd_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_AssiPahFwl_AssiPahFwlVehSpd_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_AssiPahFwl_AssiPahFwlVehSpd_Ary1D"
//
// __PST__g__41 Rte_Prm_AssiPahFwl_AssiPahFwlVehSpd_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function LnrIntrpn_s16_u16VariXs16VariY
//
// #pragma POLYSPACE_PURE "LnrIntrpn_s16_u16VariXs16VariY"
// #pragma POLYSPACE_CLEAN "LnrIntrpn_s16_u16VariXs16VariY"
// #pragma POLYSPACE_WORST "LnrIntrpn_s16_u16VariXs16VariY"
//
// __PST__SINT16 LnrIntrpn_s16_u16VariXs16VariY(__PST__g__41 P_0, __PST__g__44 P_1, __PST__UINT16 P_2, __PST__UINT16 P_3)
// {
//    ...
// }


// Pragmas for function BilnrIntrpnWithRound_s16_s16MplXs16MplY
//
// #pragma POLYSPACE_PURE "BilnrIntrpnWithRound_s16_s16MplXs16MplY"
// #pragma POLYSPACE_CLEAN "BilnrIntrpnWithRound_s16_s16MplXs16MplY"
// #pragma POLYSPACE_WORST "BilnrIntrpnWithRound_s16_s16MplXs16MplY"
//
// __PST__SINT16 BilnrIntrpnWithRound_s16_s16MplXs16MplY(__PST__UINT16 P_0, __PST__SINT16 P_1, __PST__g__41 P_2, __PST__UINT16 P_3, __PST__g__44 P_4, __PST__g__44 P_5, __PST__UINT16 P_6)
// {
//    ...
// }

