var gMsgMap = {
"NoSVGSupport":"<p><b>SVG Renderer Required</b>: Your browser does not support Scalable Vector Graphics.</p><p>Install the free <a href=\"http://www.adobe.com/svg/viewer/install/\">Adobe SVG Viewer</a> plugin or a <a href=\"http://www.mozilla.org/products/firefox/all\">SVG-compatible web browser</a> to view this Simulink model.</p><p>After the installation is complete, close this window and reopen Web view.</p>"
};
