/*Stub file only for UTP, QAC, Polysapce purpose*/ 

extern void Dummyfunc(unsigned int index);

#define osClearIMRmEI(index)    Dummyfunc(index) /* Clears Interrupt mask */



