#ifndef MOTCTRLRUNNABLE_H
#define MOTCTRLRUNNABLE_H

        extern void MotCtrlReadRunPer1(void);
        extern void MotCtrlWriteRunPer1(void);
        
#endif
