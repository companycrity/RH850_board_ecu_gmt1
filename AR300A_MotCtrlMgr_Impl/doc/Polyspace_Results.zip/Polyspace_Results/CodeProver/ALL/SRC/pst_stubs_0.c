#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__SINT32 pst_random_g_4;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsEnum_Val
 */


__PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsEnum_Val(__PST__g__39 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_8;
        }
        P_0[0] = pst_random_g_8;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsbool_Logl
 */


__PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsbool_Logl(__PST__g__41 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsf32_Val
 */


__PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsf32_Val(__PST__g__43 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss08_Val
 */


__PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss08_Val(__PST__g__36 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_2;
        }
        P_0[0] = pst_random_g_2;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss16_Val
 */


__PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss16_Val(__PST__g__46 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_3;
        }
        P_0[0] = pst_random_g_3;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss32_Val
 */


__PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss32_Val(__PST__g__48 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_4;
        }
        P_0[0] = pst_random_g_4;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss32Ary_Ary1D
 */


__PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss32Ary_Ary1D(__PST__g__48 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_4;
        }
        P_0[0] = pst_random_g_4;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu08_Val
 */


__PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu08_Val(__PST__g__41 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu16_Val
 */


__PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu16_Val(__PST__g__50 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_7;
        }
        P_0[0] = pst_random_g_7;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu32_Val
 */


__PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu32_Val(__PST__g__39 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_8;
        }
        P_0[0] = pst_random_g_8;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_MotCtrlMgr_Signal0_Logl
 */


__PST__UINT8 Rte_Read_CDD_MotCtrlMgr_Signal0_Logl(__PST__g__41 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_MotCtrlMgr_Signal5_Logl
 */


__PST__UINT8 Rte_Read_CDD_MotCtrlMgr_Signal5_Logl(__PST__g__41 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_Signal2_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_Signal2_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_Signal2_Val(__PST__SINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_Signal3_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_Signal3_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_Signal3_Val(__PST__SINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_Signal4_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_Signal4_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_Signal4_Val(__PST__SINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsEnum_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsEnum_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsEnum_Val(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsbool_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsbool_Logl"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsbool_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsf32_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsf32_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsf32_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss08_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss08_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss08_Val(__PST__SINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss16_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss16_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss16_Val(__PST__SINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss32_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss32_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss32_Val(__PST__SINT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu08_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu08_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu08_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu16_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu16_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu16_Val(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu16Ary_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu16Ary_Ary1D"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu16Ary_Ary1D(__PST__g__58 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu32_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu32_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu32_Val(__PST__UINT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsEnum_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsEnum_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsEnum_Val(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsbool_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsbool_Logl"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsbool_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsf32_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsf32_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsf32_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss08_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss08_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss08_Val(__PST__SINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss16_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss16_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss16_Val(__PST__SINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss32_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss32_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss32_Val(__PST__SINT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu08_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu08_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu08_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu16_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu16_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu16_Val(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu32_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu32_Val"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu32_Val(__PST__UINT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu32Ary_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu32Ary_Ary1D"


__PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu32Ary_Ary1D(__PST__g__62 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_CDD_MotCtrlMgr_DmaEna2MilliSecToMotCtrlTrf_Oper
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_CDD_MotCtrlMgr_DmaEna2MilliSecToMotCtrlTrf_Oper"


__PST__UINT8 Rte_Call_CDD_MotCtrlMgr_DmaEna2MilliSecToMotCtrlTrf_Oper(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_CDD_MotCtrlMgr_DmaWaitForMotCtrlTo2MilliSecTrf_Oper
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_CDD_MotCtrlMgr_DmaWaitForMotCtrlTo2MilliSecTrf_Oper"


__PST__UINT8 Rte_Call_CDD_MotCtrlMgr_DmaWaitForMotCtrlTo2MilliSecTrf_Oper(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * MotCtrlReadRunPer1
 */

#pragma POLYSPACE_POLYMORPHIC "MotCtrlReadRunPer1"


__PST__VOID MotCtrlReadRunPer1(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * MotCtrlWriteRunPer1
 */

#pragma POLYSPACE_POLYMORPHIC "MotCtrlWriteRunPer1"


__PST__VOID MotCtrlWriteRunPer1(__PST__VOID)
{
    /* function is pure */

    return;
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

