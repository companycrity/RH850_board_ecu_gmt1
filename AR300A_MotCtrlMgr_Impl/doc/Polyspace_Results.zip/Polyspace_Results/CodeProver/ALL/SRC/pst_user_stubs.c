/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsEnum_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsEnum_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsEnum_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsEnum_Val"
//
// __PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsEnum_Val(__PST__g__39 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsbool_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsbool_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsbool_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsbool_Logl"
//
// __PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsbool_Logl(__PST__g__41 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsf32_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsf32_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsf32_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsf32_Val"
//
// __PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsf32_Val(__PST__g__43 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss08_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss08_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss08_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss08_Val"
//
// __PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss08_Val(__PST__g__36 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss16_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss16_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss16_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss16_Val"
//
// __PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss16_Val(__PST__g__46 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss32_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss32_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss32_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss32_Val"
//
// __PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss32_Val(__PST__g__48 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss32Ary_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss32Ary_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss32Ary_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss32Ary_Ary1D"
//
// __PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMss32Ary_Ary1D(__PST__g__48 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu08_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu08_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu08_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu08_Val"
//
// __PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu08_Val(__PST__g__41 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu16_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu16_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu16_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu16_Val"
//
// __PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu16_Val(__PST__g__50 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu32_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu32_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu32_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu32_Val"
//
// __PST__UINT8 Rte_Read_CDD_MotCtrlMgr_ReadMotCtrlWriteTwoMsu32_Val(__PST__g__39 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_MotCtrlMgr_Signal0_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_MotCtrlMgr_Signal0_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_MotCtrlMgr_Signal0_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_MotCtrlMgr_Signal0_Logl"
//
// __PST__UINT8 Rte_Read_CDD_MotCtrlMgr_Signal0_Logl(__PST__g__41 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_MotCtrlMgr_Signal5_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_MotCtrlMgr_Signal5_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_MotCtrlMgr_Signal5_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_MotCtrlMgr_Signal5_Logl"
//
// __PST__UINT8 Rte_Read_CDD_MotCtrlMgr_Signal5_Logl(__PST__g__41 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_Signal2_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_Signal2_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_Signal2_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_Signal2_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_Signal2_Val(__PST__SINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_Signal3_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_Signal3_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_Signal3_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_Signal3_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_Signal3_Val(__PST__SINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_Signal4_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_Signal4_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_Signal4_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_Signal4_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_Signal4_Val(__PST__SINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsEnum_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsEnum_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsEnum_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsEnum_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsEnum_Val(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsbool_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsbool_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsbool_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsbool_Logl"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsbool_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsf32_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsf32_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsf32_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsf32_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsf32_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss08_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss08_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss08_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss08_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss08_Val(__PST__SINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss16_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss16_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss16_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss16_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss16_Val(__PST__SINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss32_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss32_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss32_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss32_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMss32_Val(__PST__SINT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu08_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu08_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu08_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu08_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu08_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu16_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu16_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu16_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu16_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu16_Val(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu16Ary_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu16Ary_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu16Ary_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu16Ary_Ary1D"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu16Ary_Ary1D(__PST__g__58 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu32_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu32_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu32_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu32_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadMotCtrlReadTwoMsu32_Val(__PST__UINT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsEnum_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsEnum_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsEnum_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsEnum_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsEnum_Val(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsbool_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsbool_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsbool_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsbool_Logl"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsbool_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsf32_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsf32_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsf32_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsf32_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsf32_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss08_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss08_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss08_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss08_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss08_Val(__PST__SINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss16_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss16_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss16_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss16_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss16_Val(__PST__SINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss32_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss32_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss32_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss32_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMss32_Val(__PST__SINT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu08_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu08_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu08_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu08_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu08_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu16_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu16_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu16_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu16_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu16_Val(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu32_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu32_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu32_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu32_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu32_Val(__PST__UINT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu32Ary_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu32Ary_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu32Ary_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu32Ary_Ary1D"
//
// __PST__UINT8 Rte_Write_CDD_MotCtrlMgr_WriteMotCtrlReadTwoMsu32Ary_Ary1D(__PST__g__62 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_MotCtrlMgr_DmaEna2MilliSecToMotCtrlTrf_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_MotCtrlMgr_DmaEna2MilliSecToMotCtrlTrf_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_MotCtrlMgr_DmaEna2MilliSecToMotCtrlTrf_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_MotCtrlMgr_DmaEna2MilliSecToMotCtrlTrf_Oper"
//
// __PST__UINT8 Rte_Call_CDD_MotCtrlMgr_DmaEna2MilliSecToMotCtrlTrf_Oper(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_MotCtrlMgr_DmaWaitForMotCtrlTo2MilliSecTrf_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_MotCtrlMgr_DmaWaitForMotCtrlTo2MilliSecTrf_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_MotCtrlMgr_DmaWaitForMotCtrlTo2MilliSecTrf_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_MotCtrlMgr_DmaWaitForMotCtrlTo2MilliSecTrf_Oper"
//
// __PST__UINT8 Rte_Call_CDD_MotCtrlMgr_DmaWaitForMotCtrlTo2MilliSecTrf_Oper(__PST__VOID)
// {
//    ...
// }


// Pragmas for function MotCtrlReadRunPer1
//
// #pragma POLYSPACE_PURE "MotCtrlReadRunPer1"
// #pragma POLYSPACE_CLEAN "MotCtrlReadRunPer1"
// #pragma POLYSPACE_WORST "MotCtrlReadRunPer1"
//
// __PST__VOID MotCtrlReadRunPer1(__PST__VOID)
// {
//    ...
// }


// Pragmas for function MotCtrlWriteRunPer1
//
// #pragma POLYSPACE_PURE "MotCtrlWriteRunPer1"
// #pragma POLYSPACE_CLEAN "MotCtrlWriteRunPer1"
// #pragma POLYSPACE_WORST "MotCtrlWriteRunPer1"
//
// __PST__VOID MotCtrlWriteRunPer1(__PST__VOID)
// {
//    ...
// }

