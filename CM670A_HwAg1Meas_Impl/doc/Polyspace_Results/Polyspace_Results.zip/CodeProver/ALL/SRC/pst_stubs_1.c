#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__108 _main_gen_init_g108(void);

extern union __PST__g__106 _main_gen_init_g106(void);

extern struct __PST__g__75 _main_gen_init_g75(void);

extern union __PST__g__74 _main_gen_init_g74(void);

extern struct __PST__g__72 _main_gen_init_g72(void);

extern union __PST__g__70 _main_gen_init_g70(void);

extern struct __PST__g__67 _main_gen_init_g67(void);

extern union __PST__g__65 _main_gen_init_g65(void);

extern union __PST__g__61 _main_gen_init_g61(void);

extern struct __PST__g__59 _main_gen_init_g59(void);

extern union __PST__g__58 _main_gen_init_g58(void);

extern union __PST__g__55 _main_gen_init_g55(void);

extern union __PST__g__51 _main_gen_init_g51(void);

extern union __PST__g__46 _main_gen_init_g46(void);

extern union __PST__g__38 _main_gen_init_g38(void);

extern __PST__g__36 _main_gen_init_g36(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern struct __PST__g__32 _main_gen_init_g32(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct Rte_CDS_HwAg1Meas _main_gen_init_g30(void);

struct __PST__g__32 _main_gen_init_g32(void)
{
    static struct __PST__g__32 x;
    /* struct/union type */
    x.OffsTrim = _main_gen_init_g10();
    x.OffsTrimPrfmdSts = _main_gen_init_g6();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

struct Rte_CDS_HwAg1Meas _main_gen_init_g30(void)
{
    static struct Rte_CDS_HwAg1Meas x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g6();
        }
        x.Pim_HwAg1InitStepSeqNrCmpl = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__32 _main_gen_tmp_8[ARRAY_NBELEM(struct __PST__g__32)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(struct __PST__g__32); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g32();
        }
        x.Pim_HwAg1Offs = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(struct __PST__g__32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_10[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g10();
        }
        x.Pim_HwAg1PrevHwAg1 = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g6();
        }
        x.Pim_HwAg1PrevRollCnt = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g6();
        }
        x.Pim_HwAg1PrevStepSeqNr = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g8();
        }
        x.Pim_HwAg1RawDataAvlStrtTi = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_18[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g6();
        }
        x.Pim_HwAg1Snsr0ComStsErrCntr = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_20[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g6();
        }
        x.Pim_HwAg1Snsr0IdErrCntr = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g6();
        }
        x.Pim_HwAg1Snsr0IntSnsrErrCntr = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_25;
        for (_i_main_gen_tmp_25 = 0; _i_main_gen_tmp_25 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_25++)
        {
            _main_gen_tmp_24[_i_main_gen_tmp_25] = _main_gen_init_g6();
        }
        x.Pim_HwAg1Snsr0NoMsgErrCntr = PST_TRUE() ? 0 : &_main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_27;
        for (_i_main_gen_tmp_27 = 0; _i_main_gen_tmp_27 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_27++)
        {
            _main_gen_tmp_26[_i_main_gen_tmp_27] = _main_gen_init_g6();
        }
        x.Pim_HwAg1Snsr1ComStsErrCntr = PST_TRUE() ? 0 : &_main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_28[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_29;
        for (_i_main_gen_tmp_29 = 0; _i_main_gen_tmp_29 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_29++)
        {
            _main_gen_tmp_28[_i_main_gen_tmp_29] = _main_gen_init_g6();
        }
        x.Pim_HwAg1Snsr1IdErrCntr = PST_TRUE() ? 0 : &_main_gen_tmp_28[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_30[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_31;
        for (_i_main_gen_tmp_31 = 0; _i_main_gen_tmp_31 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_31++)
        {
            _main_gen_tmp_30[_i_main_gen_tmp_31] = _main_gen_init_g6();
        }
        x.Pim_HwAg1Snsr1IntSnsrErrCntr = PST_TRUE() ? 0 : &_main_gen_tmp_30[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_32[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_33;
        for (_i_main_gen_tmp_33 = 0; _i_main_gen_tmp_33 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_33++)
        {
            _main_gen_tmp_32[_i_main_gen_tmp_33] = _main_gen_init_g6();
        }
        x.Pim_HwAg1Snsr1NoMsgErrCntr = PST_TRUE() ? 0 : &_main_gen_tmp_32[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_34[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_35;
        for (_i_main_gen_tmp_35 = 0; _i_main_gen_tmp_35 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_35++)
        {
            _main_gen_tmp_34[_i_main_gen_tmp_35] = _main_gen_init_g6();
        }
        x.Pim_HwAg1SnsrTrigNr = PST_TRUE() ? 0 : &_main_gen_tmp_34[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_36[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_37;
        for (_i_main_gen_tmp_37 = 0; _i_main_gen_tmp_37 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_37++)
        {
            _main_gen_tmp_36[_i_main_gen_tmp_37] = _main_gen_init_g10();
        }
        x.Pim_PrevHwAg1 = PST_TRUE() ? 0 : &_main_gen_tmp_36[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_38[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_39;
        for (_i_main_gen_tmp_39 = 0; _i_main_gen_tmp_39 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_39++)
        {
            _main_gen_tmp_38[_i_main_gen_tmp_39] = _main_gen_init_g6();
        }
        x.Pim_PrevHwAg1Qlfr = PST_TRUE() ? 0 : &_main_gen_tmp_38[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_40[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_41;
        for (_i_main_gen_tmp_41 = 0; _i_main_gen_tmp_41 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_41++)
        {
            _main_gen_tmp_40[_i_main_gen_tmp_41] = _main_gen_init_g7();
        }
        x.Pim_PrevHwAg1Snsr0Raw = PST_TRUE() ? 0 : &_main_gen_tmp_40[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_42[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_43;
        for (_i_main_gen_tmp_43 = 0; _i_main_gen_tmp_43 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_43++)
        {
            _main_gen_tmp_42[_i_main_gen_tmp_43] = _main_gen_init_g6();
        }
        x.Pim_PrevHwAg1Snsr0TestOk = PST_TRUE() ? 0 : &_main_gen_tmp_42[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_44[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_45;
        for (_i_main_gen_tmp_45 = 0; _i_main_gen_tmp_45 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_45++)
        {
            _main_gen_tmp_44[_i_main_gen_tmp_45] = _main_gen_init_g7();
        }
        x.Pim_PrevHwAg1Snsr1Raw = PST_TRUE() ? 0 : &_main_gen_tmp_44[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_46[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_47;
        for (_i_main_gen_tmp_47 = 0; _i_main_gen_tmp_47 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_47++)
        {
            _main_gen_tmp_46[_i_main_gen_tmp_47] = _main_gen_init_g6();
        }
        x.Pim_PrevHwAg1Snsr1TestOk = PST_TRUE() ? 0 : &_main_gen_tmp_46[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_48[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_49;
        for (_i_main_gen_tmp_49 = 0; _i_main_gen_tmp_49 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_49++)
        {
            _main_gen_tmp_48[_i_main_gen_tmp_49] = _main_gen_init_g10();
        }
        x.Pim_dHwAg1MeasSnsr0Abs = PST_TRUE() ? 0 : &_main_gen_tmp_48[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_50[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_51;
        for (_i_main_gen_tmp_51 = 0; _i_main_gen_tmp_51 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_51++)
        {
            _main_gen_tmp_50[_i_main_gen_tmp_51] = _main_gen_init_g8();
        }
        x.Pim_dHwAg1MeasSnsr0CS = PST_TRUE() ? 0 : &_main_gen_tmp_50[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_52[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_53;
        for (_i_main_gen_tmp_53 = 0; _i_main_gen_tmp_53 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_53++)
        {
            _main_gen_tmp_52[_i_main_gen_tmp_53] = _main_gen_init_g8();
        }
        x.Pim_dHwAg1MeasSnsr0FRXD = PST_TRUE() ? 0 : &_main_gen_tmp_52[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_54[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_55;
        for (_i_main_gen_tmp_55 = 0; _i_main_gen_tmp_55 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_55++)
        {
            _main_gen_tmp_54[_i_main_gen_tmp_55] = _main_gen_init_g10();
        }
        x.Pim_dHwAg1MeasSnsr0Rel = PST_TRUE() ? 0 : &_main_gen_tmp_54[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_56[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_57;
        for (_i_main_gen_tmp_57 = 0; _i_main_gen_tmp_57 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_57++)
        {
            _main_gen_tmp_56[_i_main_gen_tmp_57] = _main_gen_init_g10();
        }
        x.Pim_dHwAg1MeasSnsr1Abs = PST_TRUE() ? 0 : &_main_gen_tmp_56[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_58[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_59;
        for (_i_main_gen_tmp_59 = 0; _i_main_gen_tmp_59 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_59++)
        {
            _main_gen_tmp_58[_i_main_gen_tmp_59] = _main_gen_init_g8();
        }
        x.Pim_dHwAg1MeasSnsr1CS = PST_TRUE() ? 0 : &_main_gen_tmp_58[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_60[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_61;
        for (_i_main_gen_tmp_61 = 0; _i_main_gen_tmp_61 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_61++)
        {
            _main_gen_tmp_60[_i_main_gen_tmp_61] = _main_gen_init_g8();
        }
        x.Pim_dHwAg1MeasSnsr1FRXD = PST_TRUE() ? 0 : &_main_gen_tmp_60[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_62[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_63;
        for (_i_main_gen_tmp_63 = 0; _i_main_gen_tmp_63 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_63++)
        {
            _main_gen_tmp_62[_i_main_gen_tmp_63] = _main_gen_init_g10();
        }
        x.Pim_dHwAg1MeasSnsr1Rel = PST_TRUE() ? 0 : &_main_gen_tmp_62[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    return x;
}

union __PST__g__38 _main_gen_init_g38(void)
{
    static union __PST__g__38 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__46 _main_gen_init_g46(void)
{
    static union __PST__g__46 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__51 _main_gen_init_g51(void)
{
    static union __PST__g__51 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__55 _main_gen_init_g55(void)
{
    static union __PST__g__55 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__59 _main_gen_init_g59(void)
{
    static struct __PST__g__59 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 7);
        x.OMC = bitf;
    }
    return x;
}

union __PST__g__58 _main_gen_init_g58(void)
{
    static union __PST__g__58 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g59();
    return x;
}

union __PST__g__61 _main_gen_init_g61(void)
{
    static union __PST__g__61 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__67 _main_gen_init_g67(void)
{
    static struct __PST__g__67 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 7);
        x.OMS = bitf;
    }
    return x;
}

union __PST__g__65 _main_gen_init_g65(void)
{
    static union __PST__g__65 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g67();
    return x;
}

struct __PST__g__72 _main_gen_init_g72(void)
{
    static struct __PST__g__72 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.FRS = bitf;
    }
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.NRS = bitf;
    }
    return x;
}

union __PST__g__70 _main_gen_init_g70(void)
{
    static union __PST__g__70 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g72();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__75 _main_gen_init_g75(void)
{
    static struct __PST__g__75 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.NRC = bitf;
    }
    return x;
}

union __PST__g__74 _main_gen_init_g74(void)
{
    static union __PST__g__74 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g75();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__108 _main_gen_init_g108(void)
{
    static struct __PST__g__108 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.FND = bitf;
    }
    return x;
}

union __PST__g__106 _main_gen_init_g106(void)
{
    static union __PST__g__106 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g108();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__36 _main_gen_init_g36(void)
{
    __PST__g__36 x;
    /* struct/union type */
    x.TSPC = _main_gen_init_g38();
    x._CC = _main_gen_init_g46();
    x.BRP = _main_gen_init_g51();
    x.IDE = _main_gen_init_g55();
    x.MDC = _main_gen_init_g58();
    x.SPCT = _main_gen_init_g61();
    x.MST = _main_gen_init_g65();
    x.CS = _main_gen_init_g70();
    x.CSC = _main_gen_init_g74();
    x.FRXD = _main_gen_init_g106();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_HwAg1Meas(void)
{
    extern __PST__g__27 Rte_Inst_HwAg1Meas;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_HwAg1Meas _main_gen_tmp_4[ARRAY_NBELEM(struct Rte_CDS_HwAg1Meas)];
            __PST__UINT32 _i_main_gen_tmp_5;
            for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(struct Rte_CDS_HwAg1Meas); _i_main_gen_tmp_5++)
            {
                _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g30();
            }
            Rte_Inst_HwAg1Meas = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(struct Rte_CDS_HwAg1Meas) / 2];
        }
    }
}

static void _main_gen_init_sym_RSENT2(void)
{
    extern __PST__g__36 RSENT2;
    
    /* initialization with random value */
    {
        RSENT2 = _main_gen_init_g36();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_HwAg1Meas */
    _main_gen_init_sym_Rte_Inst_HwAg1Meas();
    
    /* init for variable RSENT2 */
    _main_gen_init_sym_RSENT2();
    
}
