#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__190 _main_gen_init_g190(void);

extern union __PST__g__189 _main_gen_init_g189(void);

extern union __PST__g__187 _main_gen_init_g187(void);

extern union __PST__g__185 _main_gen_init_g185(void);

extern union __PST__g__183 _main_gen_init_g183(void);

extern union __PST__g__181 _main_gen_init_g181(void);

extern union __PST__g__162 _main_gen_init_g162(void);

extern union __PST__g__160 _main_gen_init_g160(void);

extern union __PST__g__158 _main_gen_init_g158(void);

extern union __PST__g__144 _main_gen_init_g144(void);

extern union __PST__g__142 _main_gen_init_g142(void);

extern union __PST__g__140 _main_gen_init_g140(void);

extern union __PST__g__136 _main_gen_init_g136(void);

extern union __PST__g__134 _main_gen_init_g134(void);

extern union __PST__g__132 _main_gen_init_g132(void);

extern union __PST__g__130 _main_gen_init_g130(void);

extern union __PST__g__128 _main_gen_init_g128(void);

extern union __PST__g__126 _main_gen_init_g126(void);

extern union __PST__g__108 _main_gen_init_g108(void);

extern union __PST__g__105 _main_gen_init_g105(void);

extern union __PST__g__102 _main_gen_init_g102(void);

extern struct __PST__g__101 _main_gen_init_g101(void);

extern union __PST__g__100 _main_gen_init_g100(void);

extern struct __PST__g__97 _main_gen_init_g97(void);

extern union __PST__g__96 _main_gen_init_g96(void);

extern union __PST__g__72 _main_gen_init_g72(void);

extern struct __PST__g__68 _main_gen_init_g68(void);

extern union __PST__g__67 _main_gen_init_g67(void);

extern union __PST__g__59 _main_gen_init_g59(void);

extern union __PST__g__42 _main_gen_init_g42(void);

extern union __PST__g__39 _main_gen_init_g39(void);

extern union __PST__g__35 _main_gen_init_g35(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern union __PST__g__30 _main_gen_init_g30(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct Rte_CDS_CDD_TSG31CfgAndUse _main_gen_init_g25(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct Rte_CDS_CDD_TSG31CfgAndUse _main_gen_init_g25(void)
{
    static struct Rte_CDS_CDD_TSG31CfgAndUse x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g8();
        }
        x.Pim_TSG31CfgAndUseAdcStrtOfCnvnPeak = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g8();
        }
        x.Pim_TSG31CfgAndUseMotAg0SPIStart = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g6();
        }
        x.Pim_TSG31CfgAndUseSysStEnaPrev = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

union __PST__g__30 _main_gen_init_g30(void)
{
    static union __PST__g__30 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__35 _main_gen_init_g35(void)
{
    static union __PST__g__35 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__39 _main_gen_init_g39(void)
{
    static union __PST__g__39 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__42 _main_gen_init_g42(void)
{
    static union __PST__g__42 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__59 _main_gen_init_g59(void)
{
    static union __PST__g__59 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

struct __PST__g__68 _main_gen_init_g68(void)
{
    static struct __PST__g__68 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.TS = bitf;
    }
    return x;
}

union __PST__g__67 _main_gen_init_g67(void)
{
    static union __PST__g__67 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g68();
    return x;
}

union __PST__g__72 _main_gen_init_g72(void)
{
    static union __PST__g__72 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

struct __PST__g__97 _main_gen_init_g97(void)
{
    static struct __PST__g__97 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1023);
        x.DTC0 = bitf;
    }
    return x;
}

union __PST__g__96 _main_gen_init_g96(void)
{
    static union __PST__g__96 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g97();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__101 _main_gen_init_g101(void)
{
    static struct __PST__g__101 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1023);
        x.DTC1 = bitf;
    }
    return x;
}

union __PST__g__100 _main_gen_init_g100(void)
{
    static union __PST__g__100 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g101();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__102 _main_gen_init_g102(void)
{
    static union __PST__g__102 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__105 _main_gen_init_g105(void)
{
    static union __PST__g__105 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__108 _main_gen_init_g108(void)
{
    static union __PST__g__108 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__126 _main_gen_init_g126(void)
{
    static union __PST__g__126 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__128 _main_gen_init_g128(void)
{
    static union __PST__g__128 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__130 _main_gen_init_g130(void)
{
    static union __PST__g__130 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__132 _main_gen_init_g132(void)
{
    static union __PST__g__132 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__134 _main_gen_init_g134(void)
{
    static union __PST__g__134 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__136 _main_gen_init_g136(void)
{
    static union __PST__g__136 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__140 _main_gen_init_g140(void)
{
    static union __PST__g__140 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__142 _main_gen_init_g142(void)
{
    static union __PST__g__142 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__144 _main_gen_init_g144(void)
{
    static union __PST__g__144 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__158 _main_gen_init_g158(void)
{
    static union __PST__g__158 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__160 _main_gen_init_g160(void)
{
    static union __PST__g__160 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__162 _main_gen_init_g162(void)
{
    static union __PST__g__162 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__181 _main_gen_init_g181(void)
{
    static union __PST__g__181 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__183 _main_gen_init_g183(void)
{
    static union __PST__g__183 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__185 _main_gen_init_g185(void)
{
    static union __PST__g__185 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__187 _main_gen_init_g187(void)
{
    static union __PST__g__187 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

struct __PST__g__190 _main_gen_init_g190(void)
{
    static struct __PST__g__190 x;
    /* struct/union type */
    {
        __PST__UINT16 bitf;
        bitf = _main_gen_init_g7();
        unchecked_assert(bitf <= 1);
        x.DTCM = bitf;
    }
    return x;
}

union __PST__g__189 _main_gen_init_g189(void)
{
    static union __PST__g__189 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g190();
    x.UINT16 = _main_gen_init_g7();
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* struct/union type */
    x.IOC2 = _main_gen_init_g30();
    x.CTL3 = _main_gen_init_g35();
    x.CTL5 = _main_gen_init_g39();
    x.CTL6 = _main_gen_init_g42();
    x.STC = _main_gen_init_g59();
    x.TRG0 = _main_gen_init_g67();
    x.TRG2 = _main_gen_init_g72();
    x.DTC0W = _main_gen_init_g96();
    x.DTC1W = _main_gen_init_g100();
    x.IOC3 = _main_gen_init_g102();
    x.CTL2 = _main_gen_init_g105();
    x.CTL4 = _main_gen_init_g108();
    x.DCMP2E = _main_gen_init_g126();
    x.DCMP1E = _main_gen_init_g128();
    x.DCMP0E = _main_gen_init_g130();
    x.CMP0E = _main_gen_init_g132();
    x.CMP12E = _main_gen_init_g134();
    x.CMP11E = _main_gen_init_g136();
    x.CMP7E = _main_gen_init_g140();
    x.CMP4E = _main_gen_init_g142();
    x.CMP3E = _main_gen_init_g144();
    x.CMPWE = _main_gen_init_g158();
    x.CMPVE = _main_gen_init_g160();
    x.CMPUE = _main_gen_init_g162();
    x.IOC0 = _main_gen_init_g181();
    x.IOC1 = _main_gen_init_g183();
    x.CTL0 = _main_gen_init_g185();
    x.CTL1 = _main_gen_init_g187();
    x.DTPR = _main_gen_init_g189();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_TSG31CfgAndUse(void)
{
    extern __PST__g__22 Rte_Inst_CDD_TSG31CfgAndUse;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_TSG31CfgAndUse _main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_CDD_TSG31CfgAndUse)];
            __PST__UINT32 _i_main_gen_tmp_1;
            for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(struct Rte_CDS_CDD_TSG31CfgAndUse); _i_main_gen_tmp_1++)
            {
                _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g25();
            }
            Rte_Inst_CDD_TSG31CfgAndUse = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_CDD_TSG31CfgAndUse) / 2];
        }
    }
}

static void _main_gen_init_sym_TSG31(void)
{
    extern __PST__g__28 TSG31;
    
    /* initialization with random value */
    {
        TSG31 = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrEolCalSt(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotCurrEolCalSt;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrEolCalSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPwmPerd(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPwmPerd;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPwmPerd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiA(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPhaOnTiA;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaOnTiA = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiB(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPhaOnTiB;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaOnTiB = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiC(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPhaOnTiC;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaOnTiC = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_CDD_TSG31CfgAndUse */
    _main_gen_init_sym_Rte_Inst_CDD_TSG31CfgAndUse();
    
    /* init for variable TSG31 */
    _main_gen_init_sym_TSG31();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrEolCalSt */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrEolCalSt();
    
    /* init for variable MOTCTRLMGR_MotCtrlPwmPerd */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPwmPerd();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiA */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiA();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiB */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiB();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiC */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiC();
    
    /* init for variable MOTCTRLMGR_MotCtrlTSG31DCMP0E : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlTSG31CMPUE : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlTSG31CMPVE : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlTSG31CMPWE : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlTSG31CMP0E : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlTSG31CMP12E : useless (never read) */

}
