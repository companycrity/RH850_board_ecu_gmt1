/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Rte_Read_CDD_TSG31CfgAndUse_MotCurrEolCalSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_TSG31CfgAndUse_MotCurrEolCalSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_TSG31CfgAndUse_MotCurrEolCalSt_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_TSG31CfgAndUse_MotCurrEolCalSt_Val"
//
// __PST__UINT8 Rte_Read_CDD_TSG31CfgAndUse_MotCurrEolCalSt_Val(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_TSG31CfgAndUse_SysSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_TSG31CfgAndUse_SysSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_TSG31CfgAndUse_SysSt_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_TSG31CfgAndUse_SysSt_Val"
//
// __PST__UINT8 Rte_Read_CDD_TSG31CfgAndUse_SysSt_Val(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaALowrCmd_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaALowrCmd_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaALowrCmd_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaALowrCmd_Oper"
//
// __PST__UINT8 Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaALowrCmd_Oper(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaAUpprCmd_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaAUpprCmd_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaAUpprCmd_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaAUpprCmd_Oper"
//
// __PST__UINT8 Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaAUpprCmd_Oper(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaBLowrCmd_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaBLowrCmd_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaBLowrCmd_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaBLowrCmd_Oper"
//
// __PST__UINT8 Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaBLowrCmd_Oper(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaBUpprCmd_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaBUpprCmd_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaBUpprCmd_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaBUpprCmd_Oper"
//
// __PST__UINT8 Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaBUpprCmd_Oper(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaCLowrCmd_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaCLowrCmd_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaCLowrCmd_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaCLowrCmd_Oper"
//
// __PST__UINT8 Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaCLowrCmd_Oper(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaCUpprCmd_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaCUpprCmd_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaCUpprCmd_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaCUpprCmd_Oper"
//
// __PST__UINT8 Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctGpioPhaCUpprCmd_Oper(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaALowrCmd_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaALowrCmd_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaALowrCmd_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaALowrCmd_Oper"
//
// __PST__UINT8 Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaALowrCmd_Oper(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaAUpprCmd_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaAUpprCmd_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaAUpprCmd_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaAUpprCmd_Oper"
//
// __PST__UINT8 Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaAUpprCmd_Oper(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaBLowrCmd_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaBLowrCmd_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaBLowrCmd_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaBLowrCmd_Oper"
//
// __PST__UINT8 Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaBLowrCmd_Oper(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaBUpprCmd_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaBUpprCmd_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaBUpprCmd_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaBUpprCmd_Oper"
//
// __PST__UINT8 Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaBUpprCmd_Oper(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaCLowrCmd_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaCLowrCmd_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaCLowrCmd_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaCLowrCmd_Oper"
//
// __PST__UINT8 Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaCLowrCmd_Oper(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaCUpprCmd_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaCUpprCmd_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaCUpprCmd_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaCUpprCmd_Oper"
//
// __PST__UINT8 Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetFctPeriphPhaCUpprCmd_Oper(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaALowrCmd_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaALowrCmd_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaALowrCmd_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaALowrCmd_Oper"
//
// __PST__UINT8 Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaALowrCmd_Oper(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaAUpprCmd_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaAUpprCmd_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaAUpprCmd_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaAUpprCmd_Oper"
//
// __PST__UINT8 Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaAUpprCmd_Oper(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaBLowrCmd_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaBLowrCmd_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaBLowrCmd_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaBLowrCmd_Oper"
//
// __PST__UINT8 Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaBLowrCmd_Oper(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaBUpprCmd_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaBUpprCmd_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaBUpprCmd_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaBUpprCmd_Oper"
//
// __PST__UINT8 Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaBUpprCmd_Oper(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaCLowrCmd_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaCLowrCmd_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaCLowrCmd_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaCLowrCmd_Oper"
//
// __PST__UINT8 Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaCLowrCmd_Oper(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaCUpprCmd_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaCUpprCmd_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaCUpprCmd_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaCUpprCmd_Oper"
//
// __PST__UINT8 Rte_Call_CDD_TSG31CfgAndUse_IoHwAb_SetGpioPhaCUpprCmd_Oper(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_TSG31CfgAndUse_CurrMeasEolFixdPwmPerd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_TSG31CfgAndUse_CurrMeasEolFixdPwmPerd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_TSG31CfgAndUse_CurrMeasEolFixdPwmPerd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_TSG31CfgAndUse_CurrMeasEolFixdPwmPerd_Val"
//
// __PST__UINT32 Rte_Prm_CDD_TSG31CfgAndUse_CurrMeasEolFixdPwmPerd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_TSG31CfgAndUse_CurrMeasEolOffsHiCmuOffs_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_TSG31CfgAndUse_CurrMeasEolOffsHiCmuOffs_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_TSG31CfgAndUse_CurrMeasEolOffsHiCmuOffs_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_TSG31CfgAndUse_CurrMeasEolOffsHiCmuOffs_Val"
//
// __PST__UINT32 Rte_Prm_CDD_TSG31CfgAndUse_CurrMeasEolOffsHiCmuOffs_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_TSG31CfgAndUse_CurrMeasEolOffsLoCmuOffs_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_TSG31CfgAndUse_CurrMeasEolOffsLoCmuOffs_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_TSG31CfgAndUse_CurrMeasEolOffsLoCmuOffs_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_TSG31CfgAndUse_CurrMeasEolOffsLoCmuOffs_Val"
//
// __PST__UINT32 Rte_Prm_CDD_TSG31CfgAndUse_CurrMeasEolOffsLoCmuOffs_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseAdcStrtOfCnvn2Offs_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseAdcStrtOfCnvn2Offs_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseAdcStrtOfCnvn2Offs_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseAdcStrtOfCnvn2Offs_Val"
//
// __PST__UINT32 Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseAdcStrtOfCnvn2Offs_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlPeakOffs_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlPeakOffs_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlPeakOffs_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlPeakOffs_Val"
//
// __PST__UINT32 Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlPeakOffs_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlVlyOffs_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlVlyOffs_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlVlyOffs_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlVlyOffs_Val"
//
// __PST__UINT32 Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlVlyOffs_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseMtrAg0SPIStart_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseMtrAg0SPIStart_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseMtrAg0SPIStart_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseMtrAg0SPIStart_Val"
//
// __PST__UINT32 Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUseMtrAg0SPIStart_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUsePwmDbnd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUsePwmDbnd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUsePwmDbnd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUsePwmDbnd_Val"
//
// __PST__UINT32 Rte_Prm_CDD_TSG31CfgAndUse_TSG31CfgAndUsePwmDbnd_Val(__PST__VOID)
// {
//    ...
// }

