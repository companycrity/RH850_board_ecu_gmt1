/* Header file for contract folder of SF040A */


#ifndef CDD_MOTCTRLMGR_DATA_H
#define CDD_MOTCTRLMGR_DATA_H

extern  VAR(uint16,  AUTOMATIC)         MOTCTRLMGR_MotCtrlMotAgMecl;
extern  VAR(uint32,  AUTOMATIC)         MOTCTRLMGR_MotCtrlMotAgMeasTi;
extern  VAR(uint16,  AUTOMATIC)         MOTCTRLMGR_MotCtrlMotAgBuf[8];
extern  VAR(uint32,  AUTOMATIC)         MOTCTRLMGR_MotCtrlMotAgTiBuf[8];
extern  VAR(uint8,   AUTOMATIC)         MOTCTRLMGR_MotCtrlMotAgBufIdx;


#endif
 
 
 
 
 
