#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT32 _main_gen_init_g8(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}


/* Definition of variables init procedures */


/* Definition of functions */

static void _main_gen_call_Test_WrProtdRegPortJ_u32(void)
{
    extern __PST__VOID Test_WrProtdRegPortJ_u32(__PST__UINT32, __PST__g__16);

    __PST__UINT32 __arg__0;
    __PST__g__16 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_1;
        for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_1++)
        {
            _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g8();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    
    /* call it */
    Test_WrProtdRegPortJ_u32(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegPort0_u32(void)
{
    extern __PST__VOID Test_WrProtdRegPort0_u32(__PST__UINT32, __PST__g__16);

    __PST__UINT32 __arg__0;
    __PST__g__16 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g8();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    
    /* call it */
    Test_WrProtdRegPort0_u32(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegPort1_u32(void)
{
    extern __PST__VOID Test_WrProtdRegPort1_u32(__PST__UINT32, __PST__g__16);

    __PST__UINT32 __arg__0;
    __PST__g__16 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g8();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    
    /* call it */
    Test_WrProtdRegPort1_u32(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegPort2_u32(void)
{
    extern __PST__VOID Test_WrProtdRegPort2_u32(__PST__UINT32, __PST__g__16);

    __PST__UINT32 __arg__0;
    __PST__g__16 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g8();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    
    /* call it */
    Test_WrProtdRegPort2_u32(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegPort3_u32(void)
{
    extern __PST__VOID Test_WrProtdRegPort3_u32(__PST__UINT32, __PST__g__16);

    __PST__UINT32 __arg__0;
    __PST__g__16 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g8();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    
    /* call it */
    Test_WrProtdRegPort3_u32(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegPort4_u32(void)
{
    extern __PST__VOID Test_WrProtdRegPort4_u32(__PST__UINT32, __PST__g__16);

    __PST__UINT32 __arg__0;
    __PST__g__16 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g8();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    
    /* call it */
    Test_WrProtdRegPort4_u32(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegPort5_u32(void)
{
    extern __PST__VOID Test_WrProtdRegPort5_u32(__PST__UINT32, __PST__g__16);

    __PST__UINT32 __arg__0;
    __PST__g__16 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g8();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    
    /* call it */
    Test_WrProtdRegPort5_u32(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegSys_u08(void)
{
    extern __PST__VOID Test_WrProtdRegSys_u08(__PST__UINT8, __PST__g__19);

    __PST__UINT8 __arg__0;
    __PST__g__19 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    Test_WrProtdRegSys_u08(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegSys_u32(void)
{
    extern __PST__VOID Test_WrProtdRegSys_u32(__PST__UINT32, __PST__g__16);

    __PST__UINT32 __arg__0;
    __PST__g__16 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g8();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    
    /* call it */
    Test_WrProtdRegSys_u32(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegSysClmac_u32(void)
{
    extern __PST__VOID Test_WrProtdRegSysClmac_u32(__PST__UINT32, __PST__g__16);

    __PST__UINT32 __arg__0;
    __PST__g__16 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_18[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g8();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    
    /* call it */
    Test_WrProtdRegSysClmac_u32(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegClma0_u08(void)
{
    extern __PST__VOID Test_WrProtdRegClma0_u08(__PST__UINT8, __PST__g__19);

    __PST__UINT8 __arg__0;
    __PST__g__19 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_20[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    Test_WrProtdRegClma0_u08(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegClma1_u08(void)
{
    extern __PST__VOID Test_WrProtdRegClma1_u08(__PST__UINT8, __PST__g__19);

    __PST__UINT8 __arg__0;
    __PST__g__19 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    Test_WrProtdRegClma1_u08(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegClma2_u08(void)
{
    extern __PST__VOID Test_WrProtdRegClma2_u08(__PST__UINT8, __PST__g__19);

    __PST__UINT8 __arg__0;
    __PST__g__19 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_25;
        for (_i_main_gen_tmp_25 = 0; _i_main_gen_tmp_25 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_25++)
        {
            _main_gen_tmp_24[_i_main_gen_tmp_25] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    Test_WrProtdRegClma2_u08(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegClma3_u08(void)
{
    extern __PST__VOID Test_WrProtdRegClma3_u08(__PST__UINT8, __PST__g__19);

    __PST__UINT8 __arg__0;
    __PST__g__19 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_27;
        for (_i_main_gen_tmp_27 = 0; _i_main_gen_tmp_27 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_27++)
        {
            _main_gen_tmp_26[_i_main_gen_tmp_27] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    Test_WrProtdRegClma3_u08(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegEcmm_u08(void)
{
    extern __PST__VOID Test_WrProtdRegEcmm_u08(__PST__UINT8, __PST__g__19);

    __PST__UINT8 __arg__0;
    __PST__g__19 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_28[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_29;
        for (_i_main_gen_tmp_29 = 0; _i_main_gen_tmp_29 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_29++)
        {
            _main_gen_tmp_28[_i_main_gen_tmp_29] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_28[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    Test_WrProtdRegEcmm_u08(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegEcmc_u08(void)
{
    extern __PST__VOID Test_WrProtdRegEcmc_u08(__PST__UINT8, __PST__g__19);

    __PST__UINT8 __arg__0;
    __PST__g__19 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_30[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_31;
        for (_i_main_gen_tmp_31 = 0; _i_main_gen_tmp_31 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_31++)
        {
            _main_gen_tmp_30[_i_main_gen_tmp_31] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_30[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    Test_WrProtdRegEcmc_u08(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegEcm_u08(void)
{
    extern __PST__VOID Test_WrProtdRegEcm_u08(__PST__UINT8, __PST__g__19);

    __PST__UINT8 __arg__0;
    __PST__g__19 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_32[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_33;
        for (_i_main_gen_tmp_33 = 0; _i_main_gen_tmp_33 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_33++)
        {
            _main_gen_tmp_32[_i_main_gen_tmp_33] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_32[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    Test_WrProtdRegEcm_u08(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegEcm_u16(void)
{
    extern __PST__VOID Test_WrProtdRegEcm_u16(__PST__UINT16, __PST__g__22);

    __PST__UINT16 __arg__0;
    __PST__g__22 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_34[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_35;
        for (_i_main_gen_tmp_35 = 0; _i_main_gen_tmp_35 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_35++)
        {
            _main_gen_tmp_34[_i_main_gen_tmp_35] = _main_gen_init_g7();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_34[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    
    /* call it */
    Test_WrProtdRegEcm_u16(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegEcm_u32(void)
{
    extern __PST__VOID Test_WrProtdRegEcm_u32(__PST__UINT32, __PST__g__16);

    __PST__UINT32 __arg__0;
    __PST__g__16 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_36[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_37;
        for (_i_main_gen_tmp_37 = 0; _i_main_gen_tmp_37 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_37++)
        {
            _main_gen_tmp_36[_i_main_gen_tmp_37] = _main_gen_init_g8();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_36[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    
    /* call it */
    Test_WrProtdRegEcm_u32(__arg__0, __arg__1);
}

static void _main_gen_call_Test_WrProtdRegFlmd_u32(void)
{
    extern __PST__VOID Test_WrProtdRegFlmd_u32(__PST__UINT32, __PST__g__16);

    __PST__UINT32 __arg__0;
    __PST__g__16 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_38[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_39;
        for (_i_main_gen_tmp_39 = 0; _i_main_gen_tmp_39 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_39++)
        {
            _main_gen_tmp_38[_i_main_gen_tmp_39] = _main_gen_init_g8();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_38[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    
    /* call it */
    Test_WrProtdRegFlmd_u32(__arg__0, __arg__1);
}

static void _main_gen_call_Test_NxtrSwRst(void)
{
    extern __PST__VOID Test_NxtrSwRst(__PST__UINT32, __PST__UINT32);

    __PST__UINT32 __arg__0;
    __PST__UINT32 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    __arg__1 = _main_gen_init_g8();
    
    /* call it */
    Test_NxtrSwRst(__arg__0, __arg__1);
}

static void _main_gen_call_Test_NxtrSwRstFromExcpn(void)
{
    extern __PST__VOID Test_NxtrSwRstFromExcpn(__PST__UINT32, __PST__UINT32);

    __PST__UINT32 __arg__0;
    __PST__UINT32 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    __arg__1 = _main_gen_init_g8();
    
    /* call it */
    Test_NxtrSwRstFromExcpn(__arg__0, __arg__1);
}


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function Test_WrProtdRegPortJ_u32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegPortJ_u32();
        }
        
        /* call of function Test_WrProtdRegPort0_u32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegPort0_u32();
        }
        
        /* call of function Test_WrProtdRegPort1_u32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegPort1_u32();
        }
        
        /* call of function Test_WrProtdRegPort2_u32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegPort2_u32();
        }
        
        /* call of function Test_WrProtdRegPort3_u32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegPort3_u32();
        }
        
        /* call of function Test_WrProtdRegPort4_u32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegPort4_u32();
        }
        
        /* call of function Test_WrProtdRegPort5_u32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegPort5_u32();
        }
        
        /* call of function Test_WrProtdRegSys_u08 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegSys_u08();
        }
        
        /* call of function Test_WrProtdRegSys_u32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegSys_u32();
        }
        
        /* call of function Test_WrProtdRegSysClmac_u32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegSysClmac_u32();
        }
        
        /* call of function Test_WrProtdRegClma0_u08 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegClma0_u08();
        }
        
        /* call of function Test_WrProtdRegClma1_u08 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegClma1_u08();
        }
        
        /* call of function Test_WrProtdRegClma2_u08 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegClma2_u08();
        }
        
        /* call of function Test_WrProtdRegClma3_u08 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegClma3_u08();
        }
        
        /* call of function Test_WrProtdRegEcmm_u08 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegEcmm_u08();
        }
        
        /* call of function Test_WrProtdRegEcmc_u08 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegEcmc_u08();
        }
        
        /* call of function Test_WrProtdRegEcm_u08 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegEcm_u08();
        }
        
        /* call of function Test_WrProtdRegEcm_u16 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegEcm_u16();
        }
        
        /* call of function Test_WrProtdRegEcm_u32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegEcm_u32();
        }
        
        /* call of function Test_WrProtdRegFlmd_u32 */
        if (PST_TRUE())
        {
            _main_gen_call_Test_WrProtdRegFlmd_u32();
        }
        
        /* call of function Test_NxtrSwRst */
        if (PST_TRUE())
        {
            _main_gen_call_Test_NxtrSwRst();
        }
        
        /* call of function Test_NxtrSwRstFromExcpn */
        if (PST_TRUE())
        {
            _main_gen_call_Test_NxtrSwRstFromExcpn();
        }
        
    }
}
