#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern union __PST__g__725 _main_gen_init_g725(void);

extern union __PST__g__722 _main_gen_init_g722(void);

extern __PST__g__718 _main_gen_init_g718(void);

extern union __PST__g__715 _main_gen_init_g715(void);

extern union __PST__g__712 _main_gen_init_g712(void);

extern __PST__g__662 _main_gen_init_g662(void);

extern union __PST__g__657 _main_gen_init_g657(void);

extern union __PST__g__654 _main_gen_init_g654(void);

extern union __PST__g__633 _main_gen_init_g633(void);

extern union __PST__g__630 _main_gen_init_g630(void);

extern union __PST__g__607 _main_gen_init_g607(void);

extern union __PST__g__604 _main_gen_init_g604(void);

extern union __PST__g__581 _main_gen_init_g581(void);

extern union __PST__g__578 _main_gen_init_g578(void);

extern union __PST__g__555 _main_gen_init_g555(void);

extern union __PST__g__552 _main_gen_init_g552(void);

extern union __PST__g__529 _main_gen_init_g529(void);

extern union __PST__g__526 _main_gen_init_g526(void);

extern __PST__g__320 _main_gen_init_g320(void);

extern __PST__g__311 _main_gen_init_g311(void);

extern union __PST__g__185 _main_gen_init_g185(void);

extern union __PST__g__182 _main_gen_init_g182(void);

extern union __PST__g__149 _main_gen_init_g149(void);

extern __PST__g__106 _main_gen_init_g106(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern union __PST__g__82 _main_gen_init_g82(void);

extern union __PST__g__79 _main_gen_init_g79(void);

extern union __PST__g__77 _main_gen_init_g77(void);

extern union __PST__g__75 _main_gen_init_g75(void);

extern __PST__g__54 _main_gen_init_g54(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern union __PST__g__51 _main_gen_init_g51(void);

extern __PST__g__31 _main_gen_init_g31(void);

union __PST__g__51 _main_gen_init_g51(void)
{
    static union __PST__g__51 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__31 _main_gen_init_g31(void)
{
    __PST__g__31 x;
    /* struct/union type */
    x.PCMD0 = _main_gen_init_g51();
    return x;
}

union __PST__g__75 _main_gen_init_g75(void)
{
    static union __PST__g__75 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__77 _main_gen_init_g77(void)
{
    static union __PST__g__77 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__79 _main_gen_init_g79(void)
{
    static union __PST__g__79 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__82 _main_gen_init_g82(void)
{
    static union __PST__g__82 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__54 _main_gen_init_g54(void)
{
    __PST__g__54 x;
    /* struct/union type */
    x.ESSTC0 = _main_gen_init_g75();
    x.ESSTC1 = _main_gen_init_g77();
    x.PCMD1 = _main_gen_init_g79();
    x.PS = _main_gen_init_g82();
    return x;
}

union __PST__g__149 _main_gen_init_g149(void)
{
    static union __PST__g__149 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__182 _main_gen_init_g182(void)
{
    static union __PST__g__182 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__185 _main_gen_init_g185(void)
{
    static union __PST__g__185 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__106 _main_gen_init_g106(void)
{
    __PST__g__106 x;
    /* struct/union type */
    x.RESFC = _main_gen_init_g149();
    x.PROTCMDCVM = _main_gen_init_g182();
    x.PROTSCVM = _main_gen_init_g185();
    x.PROT1PHCMD = _main_gen_init_g182();
    x.PROT1PS = _main_gen_init_g185();
    return x;
}

__PST__g__311 _main_gen_init_g311(void)
{
    __PST__g__311 x;
    /* struct/union type */
    x.PS = _main_gen_init_g82();
    x.PCMD = _main_gen_init_g6();
    return x;
}

union __PST__g__526 _main_gen_init_g526(void)
{
    static union __PST__g__526 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__529 _main_gen_init_g529(void)
{
    static union __PST__g__529 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__552 _main_gen_init_g552(void)
{
    static union __PST__g__552 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__555 _main_gen_init_g555(void)
{
    static union __PST__g__555 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__578 _main_gen_init_g578(void)
{
    static union __PST__g__578 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__581 _main_gen_init_g581(void)
{
    static union __PST__g__581 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__604 _main_gen_init_g604(void)
{
    static union __PST__g__604 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__607 _main_gen_init_g607(void)
{
    static union __PST__g__607 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__630 _main_gen_init_g630(void)
{
    static union __PST__g__630 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__633 _main_gen_init_g633(void)
{
    static union __PST__g__633 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__654 _main_gen_init_g654(void)
{
    static union __PST__g__654 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__657 _main_gen_init_g657(void)
{
    static union __PST__g__657 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__320 _main_gen_init_g320(void)
{
    __PST__g__320 x;
    /* struct/union type */
    x.PPCMD0 = _main_gen_init_g526();
    x.PPROTS0 = _main_gen_init_g529();
    x.PPCMD1 = _main_gen_init_g552();
    x.PPROTS1 = _main_gen_init_g555();
    x.PPCMD2 = _main_gen_init_g578();
    x.PPROTS2 = _main_gen_init_g581();
    x.PPCMD3 = _main_gen_init_g604();
    x.PPROTS3 = _main_gen_init_g607();
    x.PPCMD4 = _main_gen_init_g630();
    x.PPROTS4 = _main_gen_init_g633();
    x.PPCMD5 = _main_gen_init_g654();
    x.PPROTS5 = _main_gen_init_g657();
    return x;
}

union __PST__g__712 _main_gen_init_g712(void)
{
    static union __PST__g__712 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__715 _main_gen_init_g715(void)
{
    static union __PST__g__715 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__662 _main_gen_init_g662(void)
{
    __PST__g__662 x;
    /* struct/union type */
    x.JPPCMD0 = _main_gen_init_g712();
    x.JPPROTS0 = _main_gen_init_g715();
    return x;
}

union __PST__g__722 _main_gen_init_g722(void)
{
    static union __PST__g__722 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__725 _main_gen_init_g725(void)
{
    static union __PST__g__725 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__718 _main_gen_init_g718(void)
{
    __PST__g__718 x;
    /* struct/union type */
    x.PCMD = _main_gen_init_g722();
    x.PS = _main_gen_init_g725();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_ECMM(void)
{
    extern __PST__g__31 ECMM;
    
    /* initialization with random value */
    {
        ECMM = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_ECMC(void)
{
    extern __PST__g__31 ECMC;
    
    /* initialization with random value */
    {
        ECMC = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_ECM(void)
{
    extern __PST__g__54 ECM;
    
    /* initialization with random value */
    {
        ECM = _main_gen_init_g54();
    }
}

static void _main_gen_init_sym_SYS(void)
{
    extern __PST__g__106 SYS;
    
    /* initialization with random value */
    {
        SYS = _main_gen_init_g106();
    }
}

static void _main_gen_init_sym_CLMA0(void)
{
    extern __PST__g__311 CLMA0;
    
    /* initialization with random value */
    {
        CLMA0 = _main_gen_init_g311();
    }
}

static void _main_gen_init_sym_CLMA1(void)
{
    extern __PST__g__311 CLMA1;
    
    /* initialization with random value */
    {
        CLMA1 = _main_gen_init_g311();
    }
}

static void _main_gen_init_sym_CLMA2(void)
{
    extern __PST__g__311 CLMA2;
    
    /* initialization with random value */
    {
        CLMA2 = _main_gen_init_g311();
    }
}

static void _main_gen_init_sym_CLMA3(void)
{
    extern __PST__g__311 CLMA3;
    
    /* initialization with random value */
    {
        CLMA3 = _main_gen_init_g311();
    }
}

static void _main_gen_init_sym_PORT(void)
{
    extern __PST__g__320 PORT;
    
    /* initialization with random value */
    {
        PORT = _main_gen_init_g320();
    }
}

static void _main_gen_init_sym_PORTJ(void)
{
    extern __PST__g__662 PORTJ;
    
    /* initialization with random value */
    {
        PORTJ = _main_gen_init_g662();
    }
}

static void _main_gen_init_sym_FLMD(void)
{
    extern __PST__g__718 FLMD;
    
    /* initialization with random value */
    {
        FLMD = _main_gen_init_g718();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable ECMM */
    _main_gen_init_sym_ECMM();
    
    /* init for variable ECMC */
    _main_gen_init_sym_ECMC();
    
    /* init for variable ECM */
    _main_gen_init_sym_ECM();
    
    /* init for variable SYS */
    _main_gen_init_sym_SYS();
    
    /* init for variable CLMA0 */
    _main_gen_init_sym_CLMA0();
    
    /* init for variable CLMA1 */
    _main_gen_init_sym_CLMA1();
    
    /* init for variable CLMA2 */
    _main_gen_init_sym_CLMA2();
    
    /* init for variable CLMA3 */
    _main_gen_init_sym_CLMA3();
    
    /* init for variable PORT */
    _main_gen_init_sym_PORT();
    
    /* init for variable PORTJ */
    _main_gen_init_sym_PORTJ();
    
    /* init for variable FLMD */
    _main_gen_init_sym_FLMD();
    
}
