#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__SINT8 pst_random_g_2;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct __PST__g__59 _main_gen_init_g59(void);

extern struct Rte_CDS_TunSelnMngt _main_gen_init_g57(void);

struct __PST__g__59 _main_gen_init_g59(void)
{
    static struct __PST__g__59 x;
    /* struct/union type */
    { /* array type */
        __PST__UINT32 _main_gen_tmp_16_0;
        
        for (_main_gen_tmp_16_0 = 0; _main_gen_tmp_16_0 < 3; _main_gen_tmp_16_0++)
        {
            /* struct/union type */
            { /* array type */
                __PST__UINT32 _main_gen_tmp_17_0;
                
                for (_main_gen_tmp_17_0 = 0; _main_gen_tmp_17_0 < 2; _main_gen_tmp_17_0++)
                {
                    /* struct/union type */
                    x.Seg[_main_gen_tmp_16_0].Page[_main_gen_tmp_17_0].PageAcs = _main_gen_init_g6();
                }
            }
        }
    }
    x.CopySts = _main_gen_init_g6();
    x.ActvGroup = _main_gen_init_g6();
    x.ActvInin = _main_gen_init_g6();
    x.ActvRt = _main_gen_init_g6();
    return x;
}

struct Rte_CDS_TunSelnMngt _main_gen_init_g57(void)
{
    static struct Rte_CDS_TunSelnMngt x;
    /* struct/union type */
    /* pointer */
    {
        static struct __PST__g__59 _main_gen_tmp_14[ARRAY_NBELEM(struct __PST__g__59)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(struct __PST__g__59); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g59();
        }
        x.Pim_OnlineCalSts = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(struct __PST__g__59) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_18[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g6();
        }
        x.Pim_PrevActvIninIdx = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_20[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g6();
        }
        x.Pim_PrevActvRtIdx = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g6();
        }
        x.Pim_PrevRamPageAcs = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_25;
        for (_i_main_gen_tmp_25 = 0; _i_main_gen_tmp_25 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_25++)
        {
            _main_gen_tmp_24[_i_main_gen_tmp_25] = _main_gen_init_g6();
        }
        x.Pim_RamTblSwt = PST_TRUE() ? 0 : &_main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_TunSelnMngt(void)
{
    extern __PST__g__54 Rte_Inst_TunSelnMngt;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_TunSelnMngt _main_gen_tmp_12[ARRAY_NBELEM(struct Rte_CDS_TunSelnMngt)];
            __PST__UINT32 _i_main_gen_tmp_13;
            for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(struct Rte_CDS_TunSelnMngt); _i_main_gen_tmp_13++)
            {
                _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g57();
            }
            Rte_Inst_TunSelnMngt = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(struct Rte_CDS_TunSelnMngt) / 2];
        }
    }
}

static void _main_gen_init_sym_RteParameterRefTab(void)
{
    extern __PST__g__64 RteParameterRefTab;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_26_0;
            
            for (_main_gen_tmp_26_0 = 0; _main_gen_tmp_26_0 < 36; _main_gen_tmp_26_0++)
            {
                /* pointer */
                {
                    static __PST__SINT8 _main_gen_tmp_27[ARRAY_NBELEM(__PST__SINT8)];
                    __PST__UINT32 _i_main_gen_tmp_28;
                    for (_i_main_gen_tmp_28 = 0; _i_main_gen_tmp_28 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_28++)
                    {
                        _main_gen_tmp_27[_i_main_gen_tmp_28] = _main_gen_init_g2();
                    }
                    RteParameterRefTab[_main_gen_tmp_26_0] = PST_TRUE() ? 0 : &_main_gen_tmp_27[ARRAY_NBELEM(__PST__SINT8) / 2];
                }
            }
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable RteParameterBase : useless (never read) */

    /* init for variable Rte_Inst_TunSelnMngt */
    _main_gen_init_sym_Rte_Inst_TunSelnMngt();
    
    /* init for variable RteParameterRefTab */
    _main_gen_init_sym_RteParameterRefTab();
    
}
