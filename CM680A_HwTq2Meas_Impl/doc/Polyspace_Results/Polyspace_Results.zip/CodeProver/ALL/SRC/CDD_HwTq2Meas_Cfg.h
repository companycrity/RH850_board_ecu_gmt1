
#ifndef CDD_HWTQ2MEAS_CFG_H     /* Multiple include preventer */
#define CDD_HWTQ2MEAS_CFG_H

#include "Rte_CDD_HwTq2Meas.h"

#define HWTQ2MEAS_HWTQ2MFGNTCNR_ULS_U16                 NTCNR_0X1E2
#define HWTQ2MEAS_HWTQ2PRTCLNTCNR_ULS_U16               NTCNR_0X077


#endif
