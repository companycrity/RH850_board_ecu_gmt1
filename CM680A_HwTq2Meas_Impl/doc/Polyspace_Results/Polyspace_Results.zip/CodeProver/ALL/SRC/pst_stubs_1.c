#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__108 _main_gen_init_g108(void);

extern union __PST__g__106 _main_gen_init_g106(void);

extern union __PST__g__82 _main_gen_init_g82(void);

extern struct __PST__g__75 _main_gen_init_g75(void);

extern union __PST__g__74 _main_gen_init_g74(void);

extern struct __PST__g__72 _main_gen_init_g72(void);

extern union __PST__g__70 _main_gen_init_g70(void);

extern union __PST__g__65 _main_gen_init_g65(void);

extern union __PST__g__61 _main_gen_init_g61(void);

extern union __PST__g__58 _main_gen_init_g58(void);

extern union __PST__g__55 _main_gen_init_g55(void);

extern union __PST__g__51 _main_gen_init_g51(void);

extern union __PST__g__46 _main_gen_init_g46(void);

extern union __PST__g__38 _main_gen_init_g38(void);

extern __PST__g__36 _main_gen_init_g36(void);

extern struct __PST__g__34 _main_gen_init_g34(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct Rte_CDS_CDD_HwTq2Meas _main_gen_init_g31(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

struct __PST__g__34 _main_gen_init_g34(void)
{
    static struct __PST__g__34 x;
    /* struct/union type */
    x.OffsTrim = _main_gen_init_g10();
    x.OffsTrimPrfmdSts = _main_gen_init_g6();
    return x;
}

struct Rte_CDS_CDD_HwTq2Meas _main_gen_init_g31(void)
{
    static struct Rte_CDS_CDD_HwTq2Meas x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g6();
        }
        x.Pim_GearIdn1Avl = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g6();
        }
        x.Pim_GearIdn1Data = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g6();
        }
        x.Pim_HwTq2ComStsErrCntr = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g6();
        }
        x.Pim_HwTq2IntSnsrErrCntr = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_14[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g10();
        }
        x.Pim_HwTq2MeasPrevHwTq2 = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g6();
        }
        x.Pim_HwTq2MeasPrevRollgCntr = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_18[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g8();
        }
        x.Pim_HwTq2MsgMissRxCnt = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__34 _main_gen_tmp_20[ARRAY_NBELEM(struct __PST__g__34)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(struct __PST__g__34); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g34();
        }
        x.Pim_HwTq2Offs = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(struct __PST__g__34) / 2];
    }
    return x;
}

union __PST__g__38 _main_gen_init_g38(void)
{
    static union __PST__g__38 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__46 _main_gen_init_g46(void)
{
    static union __PST__g__46 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__51 _main_gen_init_g51(void)
{
    static union __PST__g__51 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__55 _main_gen_init_g55(void)
{
    static union __PST__g__55 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__58 _main_gen_init_g58(void)
{
    static union __PST__g__58 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__61 _main_gen_init_g61(void)
{
    static union __PST__g__61 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__65 _main_gen_init_g65(void)
{
    static union __PST__g__65 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__72 _main_gen_init_g72(void)
{
    static struct __PST__g__72 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.FRS = bitf;
    }
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.NRS = bitf;
    }
    return x;
}

union __PST__g__70 _main_gen_init_g70(void)
{
    static union __PST__g__70 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g72();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__75 _main_gen_init_g75(void)
{
    static struct __PST__g__75 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.NRC = bitf;
    }
    return x;
}

union __PST__g__74 _main_gen_init_g74(void)
{
    static union __PST__g__74 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g75();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__82 _main_gen_init_g82(void)
{
    static union __PST__g__82 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__108 _main_gen_init_g108(void)
{
    static struct __PST__g__108 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.FND = bitf;
    }
    return x;
}

union __PST__g__106 _main_gen_init_g106(void)
{
    static union __PST__g__106 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g108();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__36 _main_gen_init_g36(void)
{
    __PST__g__36 x;
    /* struct/union type */
    x.TSPC = _main_gen_init_g38();
    x._CC = _main_gen_init_g46();
    x.BRP = _main_gen_init_g51();
    x.IDE = _main_gen_init_g55();
    x.MDC = _main_gen_init_g58();
    x.SPCT = _main_gen_init_g61();
    x.MST = _main_gen_init_g65();
    x.CS = _main_gen_init_g70();
    x.CSC = _main_gen_init_g74();
    x.SRXD = _main_gen_init_g82();
    x.FRXD = _main_gen_init_g106();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_HwTq2Meas(void)
{
    extern __PST__g__28 Rte_Inst_CDD_HwTq2Meas;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_HwTq2Meas _main_gen_tmp_4[ARRAY_NBELEM(struct Rte_CDS_CDD_HwTq2Meas)];
            __PST__UINT32 _i_main_gen_tmp_5;
            for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(struct Rte_CDS_CDD_HwTq2Meas); _i_main_gen_tmp_5++)
            {
                _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g31();
            }
            Rte_Inst_CDD_HwTq2Meas = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(struct Rte_CDS_CDD_HwTq2Meas) / 2];
        }
    }
}

static void _main_gen_init_sym_RSENT3(void)
{
    extern __PST__g__36 RSENT3;
    
    /* initialization with random value */
    {
        RSENT3 = _main_gen_init_g36();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_CDD_HwTq2Meas */
    _main_gen_init_sym_Rte_Inst_CDD_HwTq2Meas();
    
    /* init for variable RSENT3 */
    _main_gen_init_sym_RSENT3();
    
}
