/* Header file for contract folder of CM680A */

#ifndef FLTINJ_H        /* Multiple include preventer */
#define FLTINJ_H


#define FLTINJENA STD_ON /* FLTINJENA is defined as STD_ON in contract folder to let the compiler check the function call */
#define FLTINJ_HWTQ2MEAS_HWTQ2     26U


#endif
