#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern union __PST__g__362 _main_gen_init_g362(void);

extern __PST__g__326 _main_gen_init_g326(void);

extern union __PST__g__321 _main_gen_init_g321(void);

extern struct __PST__g__319 _main_gen_init_g319(void);

extern union __PST__g__317 _main_gen_init_g317(void);

extern struct __PST__g__315 _main_gen_init_g315(void);

extern union __PST__g__313 _main_gen_init_g313(void);

extern struct __PST__g__311 _main_gen_init_g311(void);

extern union __PST__g__310 _main_gen_init_g310(void);

extern __PST__g__295 _main_gen_init_g295(void);

extern union __PST__g__190 _main_gen_init_g190(void);

extern struct __PST__g__187 _main_gen_init_g187(void);

extern union __PST__g__185 _main_gen_init_g185(void);

extern __PST__g__159 _main_gen_init_g159(void);

extern union __PST__g__154 _main_gen_init_g154(void);

extern union __PST__g__141 _main_gen_init_g141(void);

extern __PST__g__139 _main_gen_init_g139(void);

extern union __PST__g__129 _main_gen_init_g129(void);

extern union __PST__g__112 _main_gen_init_g112(void);

extern __PST__g__103 _main_gen_init_g103(void);

extern union __PST__g__79 _main_gen_init_g79(void);

extern union __PST__g__76 _main_gen_init_g76(void);

extern union __PST__g__74 _main_gen_init_g74(void);

extern union __PST__g__72 _main_gen_init_g72(void);

extern __PST__g__51 _main_gen_init_g51(void);

extern union __PST__g__38 _main_gen_init_g38(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct Rte_CDS_CDD_RamMem _main_gen_init_g25(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

struct Rte_CDS_CDD_RamMem _main_gen_init_g25(void)
{
    static struct Rte_CDS_CDD_RamMem x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g6();
        }
        x.Pim_LclRamEccSngBitCntr = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g6();
        }
        x.Pim_LclRamEccSngBitSoftFailr = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g8();
        }
        x.Pim_LclRamFailrAdr = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g8();
        }
        x.Pim_LclRamWordLineRead = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g8();
        }
        x.Pim_dRamMemCanRamDblBitEccErrAdr = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g8();
        }
        x.Pim_dRamMemCanRamSngBitEccErrAdr = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g8();
        }
        x.Pim_dRamMemDtsRamEccErrAdr = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g8();
        }
        x.Pim_dRamMemFrRamDblBitEccErrAdr = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_18[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g8();
        }
        x.Pim_dRamMemFrRamSngBitEccErrAdr = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_20[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g8();
        }
        x.Pim_dRamMemFrRamTmpBufADblBitEccErrAdr = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g8();
        }
        x.Pim_dRamMemFrRamTmpBufBDblBitEccErrAdr = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_25;
        for (_i_main_gen_tmp_25 = 0; _i_main_gen_tmp_25 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_25++)
        {
            _main_gen_tmp_24[_i_main_gen_tmp_25] = _main_gen_init_g8();
        }
        x.Pim_dRamMemSpi0RamEccErrAdr = PST_TRUE() ? 0 : &_main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_27;
        for (_i_main_gen_tmp_27 = 0; _i_main_gen_tmp_27 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_27++)
        {
            _main_gen_tmp_26[_i_main_gen_tmp_27] = _main_gen_init_g8();
        }
        x.Pim_dRamMemSpi1RamEccErrAdr = PST_TRUE() ? 0 : &_main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_28[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_29;
        for (_i_main_gen_tmp_29 = 0; _i_main_gen_tmp_29 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_29++)
        {
            _main_gen_tmp_28[_i_main_gen_tmp_29] = _main_gen_init_g8();
        }
        x.Pim_dRamMemSpi2RamEccErrAdr = PST_TRUE() ? 0 : &_main_gen_tmp_28[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_30[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_31;
        for (_i_main_gen_tmp_31 = 0; _i_main_gen_tmp_31 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_31++)
        {
            _main_gen_tmp_30[_i_main_gen_tmp_31] = _main_gen_init_g8();
        }
        x.Pim_dRamMemSpi3RamEccErrAdr = PST_TRUE() ? 0 : &_main_gen_tmp_30[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_32[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_33;
        for (_i_main_gen_tmp_33 = 0; _i_main_gen_tmp_33 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_33++)
        {
            _main_gen_tmp_32[_i_main_gen_tmp_33] = _main_gen_init_g8();
        }
        x.Pim_dRamMemSpiRamEccErrAdr = PST_TRUE() ? 0 : &_main_gen_tmp_32[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    return x;
}

union __PST__g__38 _main_gen_init_g38(void)
{
    static union __PST__g__38 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* struct/union type */
    x.ESSTR0 = _main_gen_init_g38();
    return x;
}

union __PST__g__72 _main_gen_init_g72(void)
{
    static union __PST__g__72 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__74 _main_gen_init_g74(void)
{
    static union __PST__g__74 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__76 _main_gen_init_g76(void)
{
    static union __PST__g__76 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__79 _main_gen_init_g79(void)
{
    static union __PST__g__79 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__51 _main_gen_init_g51(void)
{
    __PST__g__51 x;
    /* struct/union type */
    x.ESSTC0 = _main_gen_init_g72();
    x.ESSTC1 = _main_gen_init_g74();
    x.PCMD1 = _main_gen_init_g76();
    x.PS = _main_gen_init_g79();
    return x;
}

union __PST__g__112 _main_gen_init_g112(void)
{
    static union __PST__g__112 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__129 _main_gen_init_g129(void)
{
    static union __PST__g__129 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__103 _main_gen_init_g103(void)
{
    __PST__g__103 x;
    /* struct/union type */
    x.IDSTCLR_PE1 = _main_gen_init_g112();
    x.ITSTCLR_PE1 = _main_gen_init_g129();
    return x;
}

union __PST__g__141 _main_gen_init_g141(void)
{
    static union __PST__g__141 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__154 _main_gen_init_g154(void)
{
    static union __PST__g__154 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__139 _main_gen_init_g139(void)
{
    __PST__g__139 x;
    /* struct/union type */
    x.CTL = _main_gen_init_g141();
    x.EAD0 = _main_gen_init_g154();
    return x;
}

struct __PST__g__187 _main_gen_init_g187(void)
{
    static struct __PST__g__187 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 4095);
        x.RAMSECAD = bitf;
    }
    return x;
}

union __PST__g__185 _main_gen_init_g185(void)
{
    static union __PST__g__185 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g187();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__190 _main_gen_init_g190(void)
{
    static union __PST__g__190 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__159 _main_gen_init_g159(void)
{
    __PST__g__159 x;
    /* struct/union type */
    x.DTSER2 = _main_gen_init_g185();
    x.DTSERC = _main_gen_init_g190();
    return x;
}

struct __PST__g__311 _main_gen_init_g311(void)
{
    static struct __PST__g__311 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.STCLR0 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.STCLR1 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.STCLR2 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.STCLR3 = bitf;
    }
    return x;
}

union __PST__g__310 _main_gen_init_g310(void)
{
    static union __PST__g__310 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g311();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__315 _main_gen_init_g315(void)
{
    static struct __PST__g__315 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.ERROVF0 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.ERROVF1 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.ERROVF2 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.ERROVF3 = bitf;
    }
    return x;
}

union __PST__g__313 _main_gen_init_g313(void)
{
    static union __PST__g__313 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g315();
    return x;
}

struct __PST__g__319 _main_gen_init_g319(void)
{
    static struct __PST__g__319 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.SEDF0 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.SEDF1 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.SEDF2 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.SEDF3 = bitf;
    }
    return x;
}

union __PST__g__317 _main_gen_init_g317(void)
{
    static union __PST__g__317 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g319();
    return x;
}

union __PST__g__321 _main_gen_init_g321(void)
{
    static union __PST__g__321 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__295 _main_gen_init_g295(void)
{
    __PST__g__295 x;
    /* struct/union type */
    x.LRSTCLR_PE1 = _main_gen_init_g310();
    x.LROVFSTR_PE1 = _main_gen_init_g313();
    x.LR1STERSTR_PE1 = _main_gen_init_g317();
    x.LR1STEADR0_PE1 = _main_gen_init_g321();
    x.LR1STEADR1_PE1 = _main_gen_init_g321();
    x.LR1STEADR2_PE1 = _main_gen_init_g321();
    x.LR1STEADR3_PE1 = _main_gen_init_g321();
    return x;
}

union __PST__g__362 _main_gen_init_g362(void)
{
    static union __PST__g__362 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__326 _main_gen_init_g326(void)
{
    __PST__g__326 x;
    /* struct/union type */
    x.RESFC = _main_gen_init_g362();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_RamMem(void)
{
    extern __PST__g__22 Rte_Inst_CDD_RamMem;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_RamMem _main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_CDD_RamMem)];
            __PST__UINT32 _i_main_gen_tmp_1;
            for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(struct Rte_CDS_CDD_RamMem); _i_main_gen_tmp_1++)
            {
                _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g25();
            }
            Rte_Inst_CDD_RamMem = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_CDD_RamMem) / 2];
        }
    }
}

static void _main_gen_init_sym_ECMM(void)
{
    extern __PST__g__28 ECMM;
    
    /* initialization with random value */
    {
        ECMM = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ECMC(void)
{
    extern __PST__g__28 ECMC;
    
    /* initialization with random value */
    {
        ECMC = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ECM(void)
{
    extern __PST__g__51 ECM;
    
    /* initialization with random value */
    {
        ECM = _main_gen_init_g51();
    }
}

static void _main_gen_init_sym_ECCIC1(void)
{
    extern __PST__g__103 ECCIC1;
    
    /* initialization with random value */
    {
        ECCIC1 = _main_gen_init_g103();
    }
}

static void _main_gen_init_sym_ECCCSIH0(void)
{
    extern __PST__g__139 ECCCSIH0;
    
    /* initialization with random value */
    {
        ECCCSIH0 = _main_gen_init_g139();
    }
}

static void _main_gen_init_sym_ECCCSIH1(void)
{
    extern __PST__g__139 ECCCSIH1;
    
    /* initialization with random value */
    {
        ECCCSIH1 = _main_gen_init_g139();
    }
}

static void _main_gen_init_sym_ECCCSIH2(void)
{
    extern __PST__g__139 ECCCSIH2;
    
    /* initialization with random value */
    {
        ECCCSIH2 = _main_gen_init_g139();
    }
}

static void _main_gen_init_sym_ECCCSIH3(void)
{
    extern __PST__g__139 ECCCSIH3;
    
    /* initialization with random value */
    {
        ECCCSIH3 = _main_gen_init_g139();
    }
}

static void _main_gen_init_sym_ECCRCAN0(void)
{
    extern __PST__g__139 ECCRCAN0;
    
    /* initialization with random value */
    {
        ECCRCAN0 = _main_gen_init_g139();
    }
}

static void _main_gen_init_sym_ECCFLX0(void)
{
    extern __PST__g__139 ECCFLX0;
    
    /* initialization with random value */
    {
        ECCFLX0 = _main_gen_init_g139();
    }
}

static void _main_gen_init_sym_ECCFLX0T1(void)
{
    extern __PST__g__139 ECCFLX0T1;
    
    /* initialization with random value */
    {
        ECCFLX0T1 = _main_gen_init_g139();
    }
}

static void _main_gen_init_sym_ECCFLX0T0(void)
{
    extern __PST__g__139 ECCFLX0T0;
    
    /* initialization with random value */
    {
        ECCFLX0T0 = _main_gen_init_g139();
    }
}

static void _main_gen_init_sym_DMASS(void)
{
    extern __PST__g__159 DMASS;
    
    /* initialization with random value */
    {
        DMASS = _main_gen_init_g159();
    }
}

static void _main_gen_init_sym_ECCCPU1(void)
{
    extern __PST__g__295 ECCCPU1;
    
    /* initialization with random value */
    {
        ECCCPU1 = _main_gen_init_g295();
    }
}

static void _main_gen_init_sym_SYS(void)
{
    extern __PST__g__326 SYS;
    
    /* initialization with random value */
    {
        SYS = _main_gen_init_g326();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_CDD_RamMem */
    _main_gen_init_sym_Rte_Inst_CDD_RamMem();
    
    /* init for variable ECMM */
    _main_gen_init_sym_ECMM();
    
    /* init for variable ECMC */
    _main_gen_init_sym_ECMC();
    
    /* init for variable ECM */
    _main_gen_init_sym_ECM();
    
    /* init for variable ECCIC1 */
    _main_gen_init_sym_ECCIC1();
    
    /* init for variable ECCCSIH0 */
    _main_gen_init_sym_ECCCSIH0();
    
    /* init for variable ECCCSIH1 */
    _main_gen_init_sym_ECCCSIH1();
    
    /* init for variable ECCCSIH2 */
    _main_gen_init_sym_ECCCSIH2();
    
    /* init for variable ECCCSIH3 */
    _main_gen_init_sym_ECCCSIH3();
    
    /* init for variable ECCRCAN0 */
    _main_gen_init_sym_ECCRCAN0();
    
    /* init for variable ECCFLX0 */
    _main_gen_init_sym_ECCFLX0();
    
    /* init for variable ECCFLX0T1 */
    _main_gen_init_sym_ECCFLX0T1();
    
    /* init for variable ECCFLX0T0 */
    _main_gen_init_sym_ECCFLX0T0();
    
    /* init for variable DMASS */
    _main_gen_init_sym_DMASS();
    
    /* init for variable ECCCPU1 */
    _main_gen_init_sym_ECCCPU1();
    
    /* init for variable SYS */
    _main_gen_init_sym_SYS();
    
}
