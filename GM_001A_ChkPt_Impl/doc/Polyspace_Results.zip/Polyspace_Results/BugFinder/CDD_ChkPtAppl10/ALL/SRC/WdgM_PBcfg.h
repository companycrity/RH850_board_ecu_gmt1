#define CP_0_0 0u
#define CP_0_1 1u
#define SE_0 0u
