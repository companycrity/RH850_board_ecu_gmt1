#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__SINT8 pst_random_g_2;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT16 _main_gen_init_g7(void);

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}


/* Definition of variables init procedures */


/* Definition of functions */

static void _main_gen_call_Calc16BitCrc_u16_Oper(void)
{
    extern __PST__UINT8 Calc16BitCrc_u16_Oper(__PST__g__17, __PST__UINT32, __PST__UINT16, __PST__UINT8, __PST__g__17);

    __PST__UINT8 __ret__;
    __PST__g__17 __arg__0;
    __PST__UINT32 __arg__1;
    __PST__UINT16 __arg__2;
    __PST__UINT8 __arg__3;
    __PST__g__17 __arg__4;
    
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_1;
        for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_1++)
        {
            _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g7();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__1 = _main_gen_init_g8();
    __arg__2 = _main_gen_init_g7();
    __arg__3 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g7();
        }
        __arg__4 = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    
    /* call it */
    __ret__ = Calc16BitCrc_u16_Oper(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4);
}

static void _main_gen_call_Calc32BitCrc_u16_Oper(void)
{
    extern __PST__UINT8 Calc32BitCrc_u16_Oper(__PST__g__17, __PST__UINT32, __PST__UINT32, __PST__UINT8, __PST__g__20);

    __PST__UINT8 __ret__;
    __PST__g__17 __arg__0;
    __PST__UINT32 __arg__1;
    __PST__UINT32 __arg__2;
    __PST__UINT8 __arg__3;
    __PST__g__20 __arg__4;
    
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g7();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__1 = _main_gen_init_g8();
    __arg__2 = _main_gen_init_g8();
    __arg__3 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g8();
        }
        __arg__4 = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    
    /* call it */
    __ret__ = Calc32BitCrc_u16_Oper(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4);
}

static void _main_gen_call_Calc32BitCrc_u32_Oper(void)
{
    extern __PST__UINT8 Calc32BitCrc_u32_Oper(__PST__g__20, __PST__UINT32, __PST__UINT32, __PST__UINT8, __PST__g__20);

    __PST__UINT8 __ret__;
    __PST__g__20 __arg__0;
    __PST__UINT32 __arg__1;
    __PST__UINT32 __arg__2;
    __PST__UINT8 __arg__3;
    __PST__g__20 __arg__4;
    
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g8();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    __arg__1 = _main_gen_init_g8();
    __arg__2 = _main_gen_init_g8();
    __arg__3 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g8();
        }
        __arg__4 = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    
    /* call it */
    __ret__ = Calc32BitCrc_u32_Oper(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4);
}

static void _main_gen_call_ResvCrcHwUnit_Oper(void)
{
    extern __PST__UINT8 ResvCrcHwUnit_Oper(__PST__UINT8, __PST__UINT8, __PST__g__20, __PST__g__20, __PST__UINT32, __PST__g__17);

    __PST__UINT8 __ret__;
    __PST__UINT8 __arg__0;
    __PST__UINT8 __arg__1;
    __PST__g__20 __arg__2;
    __PST__g__20 __arg__3;
    __PST__UINT32 __arg__4;
    __PST__g__17 __arg__5;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g8();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g8();
        }
        __arg__3 = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    __arg__4 = _main_gen_init_g8();
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g7();
        }
        __arg__5 = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    
    /* call it */
    __ret__ = ResvCrcHwUnit_Oper(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4, __arg__5);
}

static void _main_gen_call_NONTRUSTED_NtWrapS_SyncCrc_RelsCrcHwUnit(void)
{
    extern __PST__VOID NONTRUSTED_NtWrapS_SyncCrc_RelsCrcHwUnit(__PST__UINT16, __PST__g__11);

    __PST__UINT16 __arg__0;
    __PST__g__11 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT8 _main_gen_tmp_18[ARRAY_NBELEM(__PST__SINT8)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g2();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(__PST__SINT8) / 2];
    }
    
    /* call it */
    NONTRUSTED_NtWrapS_SyncCrc_RelsCrcHwUnit(__arg__0, __arg__1);
}

static void _main_gen_call_NONTRUSTED_NtWrapS_SyncCrc_GetAvlCrcHwUnit(void)
{
    extern __PST__VOID NONTRUSTED_NtWrapS_SyncCrc_GetAvlCrcHwUnit(__PST__UINT16, __PST__g__11);

    __PST__UINT16 __arg__0;
    __PST__g__11 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT8 _main_gen_tmp_20[ARRAY_NBELEM(__PST__SINT8)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g2();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(__PST__SINT8) / 2];
    }
    
    /* call it */
    NONTRUSTED_NtWrapS_SyncCrc_GetAvlCrcHwUnit(__arg__0, __arg__1);
}

static void _main_gen_call_Crc_CalculateCRC8(void)
{
    extern __PST__UINT8 Crc_CalculateCRC8(__PST__g__28, __PST__UINT32, __PST__UINT8, __PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__g__28 __arg__0;
    __PST__UINT32 __arg__1;
    __PST__UINT8 __arg__2;
    __PST__UINT8 __arg__3;
    
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g6();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    __arg__1 = _main_gen_init_g8();
    __arg__2 = _main_gen_init_g6();
    __arg__3 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = Crc_CalculateCRC8(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_Crc_CalculateCRC8H2F(void)
{
    extern __PST__UINT8 Crc_CalculateCRC8H2F(__PST__g__28, __PST__UINT32, __PST__UINT8, __PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__g__28 __arg__0;
    __PST__UINT32 __arg__1;
    __PST__UINT8 __arg__2;
    __PST__UINT8 __arg__3;
    
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_25;
        for (_i_main_gen_tmp_25 = 0; _i_main_gen_tmp_25 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_25++)
        {
            _main_gen_tmp_24[_i_main_gen_tmp_25] = _main_gen_init_g6();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    __arg__1 = _main_gen_init_g8();
    __arg__2 = _main_gen_init_g6();
    __arg__3 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = Crc_CalculateCRC8H2F(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_Crc_CalculateCRC16(void)
{
    extern __PST__UINT16 Crc_CalculateCRC16(__PST__g__28, __PST__UINT32, __PST__UINT16, __PST__UINT8);

    __PST__UINT16 __ret__;
    __PST__g__28 __arg__0;
    __PST__UINT32 __arg__1;
    __PST__UINT16 __arg__2;
    __PST__UINT8 __arg__3;
    
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_27;
        for (_i_main_gen_tmp_27 = 0; _i_main_gen_tmp_27 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_27++)
        {
            _main_gen_tmp_26[_i_main_gen_tmp_27] = _main_gen_init_g6();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    __arg__1 = _main_gen_init_g8();
    __arg__2 = _main_gen_init_g7();
    __arg__3 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = Crc_CalculateCRC16(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_Crc_CalculateCRC32(void)
{
    extern __PST__UINT32 Crc_CalculateCRC32(__PST__g__28, __PST__UINT32, __PST__UINT32, __PST__UINT8);

    __PST__UINT32 __ret__;
    __PST__g__28 __arg__0;
    __PST__UINT32 __arg__1;
    __PST__UINT32 __arg__2;
    __PST__UINT8 __arg__3;
    
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_28[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_29;
        for (_i_main_gen_tmp_29 = 0; _i_main_gen_tmp_29 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_29++)
        {
            _main_gen_tmp_28[_i_main_gen_tmp_29] = _main_gen_init_g6();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_28[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    __arg__1 = _main_gen_init_g8();
    __arg__2 = _main_gen_init_g8();
    __arg__3 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = Crc_CalculateCRC32(__arg__0, __arg__1, __arg__2, __arg__3);
}


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function Calc16BitCrc_u16_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_Calc16BitCrc_u16_Oper();
        }
        
        /* call of function Calc32BitCrc_u16_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_Calc32BitCrc_u16_Oper();
        }
        
        /* call of function Calc32BitCrc_u32_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_Calc32BitCrc_u32_Oper();
        }
        
        /* call of function ResvCrcHwUnit_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_ResvCrcHwUnit_Oper();
        }
        
        /* call of function SyncCrcInit1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID SyncCrcInit1(__PST__VOID);

            SyncCrcInit1();
        }
        
        /* call of function NONTRUSTED_NtWrapS_SyncCrc_RelsCrcHwUnit */
        if (PST_TRUE())
        {
            _main_gen_call_NONTRUSTED_NtWrapS_SyncCrc_RelsCrcHwUnit();
        }
        
        /* call of function NONTRUSTED_NtWrapS_SyncCrc_GetAvlCrcHwUnit */
        if (PST_TRUE())
        {
            _main_gen_call_NONTRUSTED_NtWrapS_SyncCrc_GetAvlCrcHwUnit();
        }
        
        /* call of function SyncCrcInit0 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID SyncCrcInit0(__PST__VOID);

            SyncCrcInit0();
        }
        
        /* call of function Crc_CalculateCRC8 */
        if (PST_TRUE())
        {
            _main_gen_call_Crc_CalculateCRC8();
        }
        
        /* call of function Crc_CalculateCRC8H2F */
        if (PST_TRUE())
        {
            _main_gen_call_Crc_CalculateCRC8H2F();
        }
        
        /* call of function Crc_CalculateCRC16 */
        if (PST_TRUE())
        {
            _main_gen_call_Crc_CalculateCRC16();
        }
        
        /* call of function Crc_CalculateCRC32 */
        if (PST_TRUE())
        {
            _main_gen_call_Crc_CalculateCRC32();
        }
        
    }
}
