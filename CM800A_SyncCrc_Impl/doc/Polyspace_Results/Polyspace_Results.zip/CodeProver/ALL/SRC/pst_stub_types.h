typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__UINT8 *__PST__g__16;
typedef __PST__UINT16 *__PST__g__17;
typedef __PST__UINT8 __PST__g__15(__PST__g__16, __PST__UINT32, __PST__UINT16, __PST__UINT8, __PST__g__17);
typedef __PST__UINT8 __PST__g__18(__PST__g__17, __PST__UINT32, __PST__UINT16, __PST__UINT8, __PST__g__17);
typedef __PST__UINT32 *__PST__g__20;
typedef __PST__UINT8 __PST__g__19(__PST__g__16, __PST__UINT32, __PST__UINT32, __PST__UINT8, __PST__g__20);
typedef __PST__UINT8 __PST__g__21(__PST__g__17, __PST__UINT32, __PST__UINT32, __PST__UINT8, __PST__g__20);
typedef __PST__UINT8 __PST__g__22(__PST__g__20, __PST__UINT32, __PST__UINT32, __PST__UINT8, __PST__g__20);
typedef __PST__UINT8 __PST__g__23(__PST__g__16, __PST__UINT32, __PST__UINT8, __PST__UINT8, __PST__g__16);
typedef __PST__UINT8 __PST__g__24(__PST__UINT8, __PST__UINT8, __PST__g__20, __PST__g__20, __PST__UINT32, __PST__g__17);
typedef __PST__VOID __PST__g__25(void);
typedef __PST__VOID __PST__g__26(__PST__UINT16, __PST__g__11);
typedef const __PST__UINT8 __PST__g__29;
typedef __PST__g__29 *__PST__g__28;
typedef __PST__UINT8 __PST__g__27(__PST__g__28, __PST__UINT32, __PST__UINT8, __PST__UINT8);
typedef __PST__UINT16 __PST__g__30(__PST__g__28, __PST__UINT32, __PST__UINT16, __PST__UINT8);
typedef __PST__UINT32 __PST__g__31(__PST__g__28, __PST__UINT32, __PST__UINT32, __PST__UINT8);
typedef __PST__FLOAT64 __PST__g__32(void);
typedef __PST__g__11 *__PST__g__34;
typedef volatile __PST__FLOAT64 __PST__g__35;
typedef __PST__SINT8 *__PST__g__37;
typedef volatile __PST__g__37 __PST__g__36;
typedef const struct Rte_CDS_CDD_SyncCrc __PST__g__40;
typedef __PST__g__40 *__PST__g__39;
typedef const __PST__g__39 __PST__g__38;
typedef struct __PST__g__44 __PST__g__43[4];
typedef __PST__g__43 *__PST__g__42;
struct Rte_CDS_CDD_SyncCrc
  {
    __PST__g__42 Pim_CrcHwSts;
  };
typedef __PST__SINT8 __PST__g__45[1];
struct __PST__g__44
  {
    __PST__UINT16 TaskId;
    __PST__UINT8 CrcHwSts;
    __PST__g__45 __pst_unused_field___pstfiller;
  };
typedef __PST__SINT8 __PST__g__103[24];
struct __PST__g__51
  {
    __PST__UINT8 POL : 2;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 ISZ : 2;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 2;
  };
union __PST__g__50
  {
    struct __PST__g__51 BIT;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef __PST__SINT8 __PST__g__104[4063];
struct __PST__g__48
  {
    __PST__UINT32 CIN;
    __PST__UINT32 COUT;
    __PST__g__103 __pst_unused_field_2;
    union __PST__g__50 CTL;
    __PST__g__104 __pst_unused_field_4;
  };
typedef volatile struct __PST__g__48 __PST__g__47;
typedef __PST__g__47 __PST__g__46[4];
typedef __PST__UINT8 __PST__g__49[24];
typedef __PST__UINT8 __PST__g__53[4063];
typedef __PST__VOID __PST__g__54(__PST__SINT32);
typedef __PST__UINT8 __PST__g__55(__PST__UINT16, __PST__UINT8, __PST__UINT8, __PST__UINT8);
typedef __PST__VOID __PST__g__56(__PST__g__17);
typedef __PST__UINT8 __PST__g__57(void);
typedef const __PST__UINT16 __PST__g__58;
typedef __PST__g__58 __PST__g__59[4];
struct __PST__g__60
  {
    __PST__UINT8 CrcHwIdx;
  };
struct __PST__g__61
  {
    __PST__UINT8 ResvCall;
  };
typedef __PST__g__56 *__PST__g__62;
typedef __PST__VOID __PST__g__63(__PST__UINT8);
typedef __PST__g__63 *__PST__g__64;
typedef struct __PST__g__61 *__PST__g__65;
typedef __PST__g__26 *__PST__g__66;
typedef __PST__g__57 *__PST__g__67;
typedef const __PST__g__42 __PST__g__68;
typedef __PST__g__68 *__PST__g__69;
typedef struct __PST__g__44 *__PST__g__70;
typedef __PST__g__46 *__PST__g__71;
typedef __PST__g__47 *__PST__g__72;
typedef volatile union __PST__g__50 __PST__g__73;
typedef __PST__g__73 *__PST__g__74;
typedef volatile struct __PST__g__51 __PST__g__75;
typedef __PST__g__75 *__PST__g__76;
typedef volatile __PST__UINT32 __PST__g__79;
typedef __PST__g__79 *__PST__g__80;
typedef __PST__g__54 *__PST__g__81;
typedef struct __PST__g__60 *__PST__g__82;
typedef __PST__g__55 *__PST__g__83;
typedef __PST__g__59 *__PST__g__84;
typedef __PST__g__58 *__PST__g__85;
typedef __PST__VOID __PST__g__86(__PST__UINT8, __PST__UINT8, __PST__UINT32);
typedef __PST__g__86 *__PST__g__87;
typedef __PST__g__25 *__PST__g__88;
typedef __PST__g__23 *__PST__g__89;
typedef __PST__g__15 *__PST__g__90;
typedef __PST__g__19 *__PST__g__91;
typedef volatile __PST__SINT32 __PST__g__92;
typedef __PST__SINT8 __PST__g__98(void);
typedef volatile __PST__SINT8 __PST__g__99;
typedef volatile __PST__UINT8 __PST__g__100;
typedef __PST__SINT32 __PST__g__101(void);
typedef __PST__UINT32 __PST__g__102(void);
