#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct __PST__g__51 _main_gen_init_g51(void);

extern union __PST__g__50 _main_gen_init_g50(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern struct Rte_CDS_CDD_SyncCrc _main_gen_init_g41(void);

struct Rte_CDS_CDD_SyncCrc _main_gen_init_g41(void)
{
    static struct Rte_CDS_CDD_SyncCrc x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__g__43 _main_gen_tmp_32[ARRAY_NBELEM(__PST__g__43)];
        __PST__UINT32 _i_main_gen_tmp_33;
        for (_i_main_gen_tmp_33 = 0; _i_main_gen_tmp_33 < ARRAY_NBELEM(__PST__g__43); _i_main_gen_tmp_33++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_34_0;
                
                for (_main_gen_tmp_34_0 = 0; _main_gen_tmp_34_0 < 4; _main_gen_tmp_34_0++)
                {
                    /* struct/union type */
                    _main_gen_tmp_32[_i_main_gen_tmp_33][_main_gen_tmp_34_0].TaskId = _main_gen_init_g7();
                    _main_gen_tmp_32[_i_main_gen_tmp_33][_main_gen_tmp_34_0].CrcHwSts = _main_gen_init_g6();
                }
            }
        }
        x.Pim_CrcHwSts = PST_TRUE() ? 0 : &_main_gen_tmp_32[ARRAY_NBELEM(__PST__g__43) / 2];
    }
    return x;
}

struct __PST__g__51 _main_gen_init_g51(void)
{
    static struct __PST__g__51 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 3);
        x.POL = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 3);
        x.ISZ = bitf;
    }
    return x;
}

union __PST__g__50 _main_gen_init_g50(void)
{
    static union __PST__g__50 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g51();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_SyncCrc(void)
{
    extern __PST__g__38 Rte_Inst_CDD_SyncCrc;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_SyncCrc _main_gen_tmp_30[ARRAY_NBELEM(struct Rte_CDS_CDD_SyncCrc)];
            __PST__UINT32 _i_main_gen_tmp_31;
            for (_i_main_gen_tmp_31 = 0; _i_main_gen_tmp_31 < ARRAY_NBELEM(struct Rte_CDS_CDD_SyncCrc); _i_main_gen_tmp_31++)
            {
                _main_gen_tmp_30[_i_main_gen_tmp_31] = _main_gen_init_g41();
            }
            Rte_Inst_CDD_SyncCrc = PST_TRUE() ? 0 : &_main_gen_tmp_30[ARRAY_NBELEM(struct Rte_CDS_CDD_SyncCrc) / 2];
        }
    }
}

static void _main_gen_init_sym_NROFACTVCRCHWUNIT_CNT_U08(void)
{
    extern __PST__UINT8 NROFACTVCRCHWUNIT_CNT_U08;
    
    /* initialization with random value */
    {
        NROFACTVCRCHWUNIT_CNT_U08 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DCRA(void)
{
    extern __PST__g__46 DCRA;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_35_0;
            
            for (_main_gen_tmp_35_0 = 0; _main_gen_tmp_35_0 < 4; _main_gen_tmp_35_0++)
            {
                /* struct/union type */
                DCRA[_main_gen_tmp_35_0].CTL = _main_gen_init_g50();
                DCRA[_main_gen_tmp_35_0].CIN = _main_gen_init_g8();
                DCRA[_main_gen_tmp_35_0].COUT = _main_gen_init_g8();
            }
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_CDD_SyncCrc */
    _main_gen_init_sym_Rte_Inst_CDD_SyncCrc();
    
    /* init for variable NROFACTVCRCHWUNIT_CNT_U08 */
    _main_gen_init_sym_NROFACTVCRCHWUNIT_CNT_U08();
    
    /* init for variable DCRA */
    _main_gen_init_sym_DCRA();
    
}
