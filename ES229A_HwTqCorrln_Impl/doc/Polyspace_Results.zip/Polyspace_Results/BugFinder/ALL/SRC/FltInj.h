
#ifndef FLTINJ_H
#define FLTINJ_H

#define FLTINJ_HWTQCORRLN_HWTQIDPTSIG           (27U)

#endif
