#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern union __PST__g__261 _main_gen_init_g261(void);

extern __PST__g__221 _main_gen_init_g221(void);

extern union __PST__g__197 _main_gen_init_g197(void);

extern union __PST__g__193 _main_gen_init_g193(void);

extern union __PST__g__191 _main_gen_init_g191(void);

extern union __PST__g__189 _main_gen_init_g189(void);

extern __PST__g__167 _main_gen_init_g167(void);

extern union __PST__g__164 _main_gen_init_g164(void);

extern union __PST__g__151 _main_gen_init_g151(void);

extern union __PST__g__146 _main_gen_init_g146(void);

extern union __PST__g__142 _main_gen_init_g142(void);

extern union __PST__g__138 _main_gen_init_g138(void);

extern __PST__g__126 _main_gen_init_g126(void);

extern struct __PST__g__119 _main_gen_init_g119(void);

extern union __PST__g__118 _main_gen_init_g118(void);

extern struct __PST__g__117 _main_gen_init_g117(void);

extern union __PST__g__116 _main_gen_init_g116(void);

extern struct __PST__g__110 _main_gen_init_g110(void);

extern union __PST__g__109 _main_gen_init_g109(void);

extern struct __PST__g__96 _main_gen_init_g96(void);

extern union __PST__g__95 _main_gen_init_g95(void);

extern union __PST__g__93 _main_gen_init_g93(void);

extern union __PST__g__91 _main_gen_init_g91(void);

extern union __PST__g__89 _main_gen_init_g89(void);

extern union __PST__g__70 _main_gen_init_g70(void);

extern union __PST__g__37 _main_gen_init_g37(void);

extern __PST__g__34 _main_gen_init_g34(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct Rte_CDS_CDD_FlsMem _main_gen_init_g27(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

struct Rte_CDS_CDD_FlsMem _main_gen_init_g27(void)
{
    static struct Rte_CDS_CDD_FlsMem x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g8();
        }
        x.Pim_CodFlsCrcChkStrtTi = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g6();
        }
        x.Pim_CodFlsSngBitErr = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g6();
        }
        x.Pim_CrcChkCmpl = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g7();
        }
        x.Pim_CrcHwIdxKey = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g6();
        }
        x.Pim_PwrOnRstCrcChkCmpl = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    return x;
}

union __PST__g__37 _main_gen_init_g37(void)
{
    static union __PST__g__37 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__70 _main_gen_init_g70(void)
{
    static union __PST__g__70 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__34 _main_gen_init_g34(void)
{
    __PST__g__34 x;
    /* struct/union type */
    x.PINT0 = _main_gen_init_g37();
    x.PINTCLR0 = _main_gen_init_g70();
    return x;
}

union __PST__g__89 _main_gen_init_g89(void)
{
    static union __PST__g__89 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__91 _main_gen_init_g91(void)
{
    static union __PST__g__91 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__93 _main_gen_init_g93(void)
{
    static union __PST__g__93 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__96 _main_gen_init_g96(void)
{
    static struct __PST__g__96 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.TCE = bitf;
    }
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 3);
        x.CHNE = bitf;
    }
    return x;
}

union __PST__g__95 _main_gen_init_g95(void)
{
    static union __PST__g__95 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g96();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__110 _main_gen_init_g110(void)
{
    static struct __PST__g__110 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.REQEN = bitf;
    }
    return x;
}

union __PST__g__109 _main_gen_init_g109(void)
{
    static union __PST__g__109 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g110();
    return x;
}

struct __PST__g__117 _main_gen_init_g117(void)
{
    static struct __PST__g__117 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.DRQS = bitf;
    }
    return x;
}

union __PST__g__116 _main_gen_init_g116(void)
{
    static union __PST__g__116 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g117();
    return x;
}

struct __PST__g__119 _main_gen_init_g119(void)
{
    static struct __PST__g__119 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.DRQC = bitf;
    }
    return x;
}

union __PST__g__118 _main_gen_init_g118(void)
{
    static union __PST__g__118 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g119();
    return x;
}

union __PST__g__138 _main_gen_init_g138(void)
{
    static union __PST__g__138 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__142 _main_gen_init_g142(void)
{
    static union __PST__g__142 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__146 _main_gen_init_g146(void)
{
    static union __PST__g__146 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__151 _main_gen_init_g151(void)
{
    static union __PST__g__151 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__126 _main_gen_init_g126(void)
{
    __PST__g__126 x;
    /* struct/union type */
    x.CFSTCLR_VCI = _main_gen_init_g138();
    x.CFOVFSTR_VCI = _main_gen_init_g142();
    x.CF1STERSTR_VCI = _main_gen_init_g146();
    x.CF1STEADR0_VCI = _main_gen_init_g151();
    x.CFSTCLR_PE1 = _main_gen_init_g138();
    x.CFOVFSTR_PE1 = _main_gen_init_g142();
    x.CF1STERSTR_PE1 = _main_gen_init_g146();
    x.CF1STEADR0_PE1 = _main_gen_init_g151();
    return x;
}

union __PST__g__164 _main_gen_init_g164(void)
{
    static union __PST__g__164 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__189 _main_gen_init_g189(void)
{
    static union __PST__g__189 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__191 _main_gen_init_g191(void)
{
    static union __PST__g__191 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__193 _main_gen_init_g193(void)
{
    static union __PST__g__193 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__197 _main_gen_init_g197(void)
{
    static union __PST__g__197 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__167 _main_gen_init_g167(void)
{
    __PST__g__167 x;
    /* struct/union type */
    x.ESSTC0 = _main_gen_init_g189();
    x.ESSTC1 = _main_gen_init_g191();
    x.PCMD1 = _main_gen_init_g193();
    x.PS = _main_gen_init_g197();
    return x;
}

union __PST__g__261 _main_gen_init_g261(void)
{
    static union __PST__g__261 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__221 _main_gen_init_g221(void)
{
    __PST__g__221 x;
    /* struct/union type */
    x.RESFC = _main_gen_init_g261();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_FlsMem(void)
{
    extern __PST__g__24 Rte_Inst_CDD_FlsMem;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_FlsMem _main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_CDD_FlsMem)];
            __PST__UINT32 _i_main_gen_tmp_1;
            for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(struct Rte_CDS_CDD_FlsMem); _i_main_gen_tmp_1++)
            {
                _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g27();
            }
            Rte_Inst_CDD_FlsMem = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_CDD_FlsMem) / 2];
        }
    }
}

static void _main_gen_init_sym_FlsCfgTbl(void)
{
    extern __PST__g__31 FlsCfgTbl;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_12_0;
            
            for (_main_gen_tmp_12_0 = 0; _main_gen_tmp_12_0 < pst_random_g_8; _main_gen_tmp_12_0++)
            {
                /* struct/union type */
                /* pointer */
                {
                    static __PST__UINT32 _main_gen_tmp_13[ARRAY_NBELEM(__PST__UINT32)];
                    __PST__UINT32 _i_main_gen_tmp_14;
                    for (_i_main_gen_tmp_14 = 0; _i_main_gen_tmp_14 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_14++)
                    {
                        _main_gen_tmp_13[_i_main_gen_tmp_14] = _main_gen_init_g8();
                    }
                    FlsCfgTbl[_main_gen_tmp_12_0].PreCalcnCrcFlsAdr = PST_TRUE() ? 0 : &_main_gen_tmp_13[ARRAY_NBELEM(__PST__UINT32) / 2];
                }
                FlsCfgTbl[_main_gen_tmp_12_0].CrcFlsBlkStrtAdr = _main_gen_init_g8();
                FlsCfgTbl[_main_gen_tmp_12_0].CrcFlsBlkLen = _main_gen_init_g8();
            }
        }
    }
}

static void _main_gen_init_sym_INTIF(void)
{
    extern __PST__g__34 INTIF;
    
    /* initialization with random value */
    {
        INTIF = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_DTSCfg(void)
{
    extern __PST__g__86 DTSCfg;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_15_0;
            
            for (_main_gen_tmp_15_0 = 0; _main_gen_tmp_15_0 < 128; _main_gen_tmp_15_0++)
            {
                /* struct/union type */
                DTSCfg[_main_gen_tmp_15_0].DMASSDTSA = _main_gen_init_g89();
                DTSCfg[_main_gen_tmp_15_0].DMASSDTDA = _main_gen_init_g91();
                DTSCfg[_main_gen_tmp_15_0].DMASSDTTC = _main_gen_init_g93();
                DTSCfg[_main_gen_tmp_15_0].DMASSDTTCT = _main_gen_init_g95();
                DTSCfg[_main_gen_tmp_15_0].DMASSDTFSL = _main_gen_init_g109();
                DTSCfg[_main_gen_tmp_15_0].DMASSDTFSS = _main_gen_init_g116();
                DTSCfg[_main_gen_tmp_15_0].DMASSDTFSC = _main_gen_init_g118();
            }
        }
    }
}

static void _main_gen_init_sym_ECCFLI(void)
{
    extern __PST__g__126 ECCFLI;
    
    /* initialization with random value */
    {
        ECCFLI = _main_gen_init_g126();
    }
}

static void _main_gen_init_sym_DTSMstrCfg(void)
{
    extern __PST__g__161 DTSMstrCfg;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_16_0;
            
            for (_main_gen_tmp_16_0 = 0; _main_gen_tmp_16_0 < 128; _main_gen_tmp_16_0++)
            {
                /* struct/union type */
                DTSMstrCfg[_main_gen_tmp_16_0].DTSnnnCM = _main_gen_init_g164();
            }
        }
    }
}

static void _main_gen_init_sym_ECM(void)
{
    extern __PST__g__167 ECM;
    
    /* initialization with random value */
    {
        ECM = _main_gen_init_g167();
    }
}

static void _main_gen_init_sym_SYS(void)
{
    extern __PST__g__221 SYS;
    
    /* initialization with random value */
    {
        SYS = _main_gen_init_g221();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_CDD_FlsMem */
    _main_gen_init_sym_Rte_Inst_CDD_FlsMem();
    
    /* init for variable FlsCfgTbl */
    _main_gen_init_sym_FlsCfgTbl();
    
    /* init for variable INTIF */
    _main_gen_init_sym_INTIF();
    
    /* init for variable DTSCfg */
    _main_gen_init_sym_DTSCfg();
    
    /* init for variable ECCFLI */
    _main_gen_init_sym_ECCFLI();
    
    /* init for variable DTSMstrCfg */
    _main_gen_init_sym_DTSMstrCfg();
    
    /* init for variable ECM */
    _main_gen_init_sym_ECM();
    
    /* init for variable SYS */
    _main_gen_init_sym_SYS();
    
}
